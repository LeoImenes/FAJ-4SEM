package com.br.cienciascomputacao.faj.Cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
