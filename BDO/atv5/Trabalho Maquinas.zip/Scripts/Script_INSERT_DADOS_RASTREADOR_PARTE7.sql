﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 00:03:21', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 00:33:21', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 01:03:22', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 01:33:22', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 02:03:22', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 02:33:23', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 03:03:23', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 03:33:24', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 04:03:24', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 04:33:25', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 05:03:25', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 05:33:26', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 06:03:26', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 06:33:26', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 07:03:27', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 07:33:27', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 08:03:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 08:33:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 09:03:29', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 09:33:29', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 10:03:30', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 10:33:30', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 11:03:30', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 11:33:31', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 12:03:32', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 12:33:32', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 13:03:32', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 13:33:33', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 14:03:33', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 14:33:34', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 15:03:34', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 15:33:35', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 16:03:35', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 16:33:35', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 17:03:36', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 17:33:36', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 18:03:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 18:33:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 19:03:38', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 19:33:38', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 20:03:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 20:33:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 21:03:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 21:33:40', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 22:03:40', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 22:33:41', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 23:03:41', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('19-09-2021 23:33:42', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 00:08:25', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 00:38:26', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 01:08:27', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 01:38:27', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 02:08:28', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 02:38:28', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 03:08:28', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 03:38:29', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 04:08:29', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 04:38:30', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 05:08:30', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 05:38:31', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 06:08:31', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 06:38:31', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 07:08:32', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 07:38:32', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 08:08:33', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 08:38:33', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 09:08:34', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 09:38:34', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 10:08:35', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 10:38:35', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 11:08:35', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 11:38:36', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 12:08:36', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 12:38:37', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 13:08:37', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 13:38:38', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 14:08:38', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 14:38:39', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 15:08:39', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 15:38:39', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 16:08:40', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 16:38:40', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 17:08:41', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 17:38:41', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 18:08:42', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 18:38:42', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 19:08:43', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 19:38:43', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 20:08:43', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 20:38:44', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 21:08:44', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 21:38:45', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 22:08:45', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 22:38:46', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 23:08:46', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('19-09-2021 23:38:47', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 00:16:58', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 00:46:59', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 01:16:59', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 01:47:00', 'dd-mm-yyyy hh24:mi:ss'), 1474);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 02:17:00', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 02:47:01', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 03:17:01', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 03:47:01', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 04:17:02', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 04:47:02', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 05:17:03', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 05:47:03', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 06:17:04', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 06:47:04', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 07:17:05', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 07:47:05', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 08:17:05', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 08:47:06', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 09:17:06', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 09:47:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 10:17:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 10:47:08', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 11:17:08', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 11:47:08', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 12:17:09', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 12:47:09', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 13:17:10', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 13:47:10', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 14:17:11', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 14:47:11', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 15:17:12', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 15:47:12', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 16:17:12', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 16:47:13', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 17:17:13', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 17:47:14', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 18:17:14', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 18:47:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 19:17:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 19:47:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 20:17:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 20:47:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 21:17:17', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 21:47:17', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 22:17:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 22:47:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 23:17:19', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('19-09-2021 23:47:19', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 00:15:48', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 00:45:49', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 01:15:49', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 01:45:50', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 02:15:50', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 02:45:51', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 03:15:51', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 03:45:51', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 04:15:52', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 04:45:52', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 05:15:53', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 05:45:53', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 06:15:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 06:45:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 07:15:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 07:45:55', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 08:15:55', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 08:45:56', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 09:15:56', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 09:45:57', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 10:15:57', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 10:45:58', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 11:15:58', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 11:45:59', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 12:15:59', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 12:45:59', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 13:16:00', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 13:46:00', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 14:16:01', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 14:46:01', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 15:16:02', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 15:46:02', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 16:16:03', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 16:46:03', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 17:16:03', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 17:46:04', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 18:16:04', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 18:46:05', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 19:16:05', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 19:46:06', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 20:16:06', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 20:46:06', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 21:16:07', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 21:46:07', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 22:16:08', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 22:46:08', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 23:16:09', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('19-09-2021 23:46:09', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 00:20:51', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 00:50:52', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 01:20:52', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 01:50:53', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 02:20:53', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 02:50:54', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 03:20:54', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 03:50:55', 'dd-mm-yyyy hh24:mi:ss'), 2053);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 04:20:55', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 04:50:56', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 05:20:56', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 05:50:56', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 06:20:57', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 06:50:57', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 07:20:58', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 07:50:58', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 08:20:59', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 08:50:59', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 09:20:59', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 09:51:00', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 10:21:00', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 10:51:01', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 11:21:01', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 11:51:02', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 12:21:02', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 12:51:03', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 13:21:03', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 13:51:03', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 14:21:04', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 14:51:04', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 15:21:05', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 15:51:05', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 16:21:06', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 16:51:06', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 17:21:07', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 17:51:07', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 18:21:08', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 18:51:08', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 19:21:08', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 19:51:09', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 20:21:09', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 20:51:10', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 21:21:10', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 21:51:11', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 22:21:11', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 22:51:12', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 23:21:12', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('19-09-2021 23:51:13', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 19:57:51', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 20:27:51', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 20:57:51', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 21:27:52', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 21:57:52', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 22:27:53', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 22:57:53', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 23:27:54', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 23:57:54', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 00:19:10', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 00:49:10', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 01:19:11', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 01:49:11', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 02:19:12', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 02:49:12', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 03:19:13', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 03:49:13', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 04:19:14', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 04:49:14', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 05:19:14', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 05:49:15', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 06:19:15', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 06:49:16', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 06:59:54', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:00:38', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:01:18', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:01:22', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:01:24', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:03:04', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:10:14', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:18:04', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:19:21', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:24:54', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:32:00', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:32:27', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:32:29', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:32:36', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:32:38', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:33:04', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 07:45:30', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 08:10:39', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 08:40:40', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:10:40', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:22:37', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:23:06', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:23:20', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:23:25', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:23:27', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:27:52', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:33:40', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:33:43', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:33:50', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:33:52', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:33:54', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:38:43', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:48:43', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 09:50:45', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:15:54', 'dd-mm-yyyy hh24:mi:ss'), 1429);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:45:55', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:49:06', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:49:08', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:49:22', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:49:24', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 10:59:24', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:03:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:13:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:14:20', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:18:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:28:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:29:23', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:33:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:43:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:44:50', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:48:04', 'dd-mm-yyyy hh24:mi:ss'), 1430);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:54:37', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 11:56:06', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:03:04', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:04:54', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:12:47', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:18:04', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:21:26', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:31:26', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 12:58:38', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 13:28:38', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 13:58:39', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 14:28:39', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 14:58:40', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 15:28:40', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 15:58:40', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 16:28:41', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 16:58:41', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 17:28:42', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 17:58:42', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 18:28:43', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 18:58:43', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 19:28:44', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 19:58:44', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 20:28:44', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 20:58:45', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 21:28:45', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 21:58:46', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 22:28:46', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 22:58:47', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 23:28:47', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('19-09-2021 23:58:47', 'dd-mm-yyyy hh24:mi:ss'), 1431);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 00:27:33', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 00:57:34', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 01:27:34', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 01:57:35', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 02:27:35', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 02:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 03:27:36', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 03:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 04:27:37', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 04:57:37', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 05:27:38', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 05:57:38', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 06:27:39', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 06:57:39', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 07:27:39', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 07:57:40', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 08:27:40', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 08:57:41', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 09:27:41', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 09:57:42', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 10:27:42', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 10:57:43', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 11:27:43', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 11:57:44', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 12:27:44', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 12:57:44', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 13:27:45', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 13:57:45', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 14:27:46', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 14:57:46', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 15:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 15:57:47', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 16:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 16:57:48', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 17:27:48', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 17:57:49', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 18:27:49', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 18:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('19-09-2021 19:27:50', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:06:56', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:08:25', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:11:48', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:12:10', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:22:10', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:26:48', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:32:02', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:41:48', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:42:41', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:47:26', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:56:48', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4934);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 00:58:51', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:04:37', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:06:40', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:09:46', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:19:15', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:19:22', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:19:24', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:24:40', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:26:48', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:36:48', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:41:48', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:41:53', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:51:53', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 01:53:54', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 02:19:03', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 02:49:03', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 03:19:04', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 03:49:04', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 04:19:05', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 04:49:05', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 05:19:06', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 05:49:06', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 06:19:06', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 06:49:07', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 07:19:07', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 07:49:08', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 08:19:08', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 08:49:09', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 09:19:09', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 09:49:10', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 10:19:10', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 10:49:10', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 11:19:11', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 11:49:11', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 12:19:12', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 12:49:12', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 13:19:13', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 13:49:13', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 14:19:14', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 14:49:14', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 15:19:14', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 15:49:15', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 16:19:15', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 16:49:16', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 17:19:16', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 17:49:17', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 18:19:17', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 18:49:17', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 19:19:18', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 19:49:18', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 20:19:19', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 20:49:19', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 21:19:20', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 21:49:20', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 22:19:20', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 22:49:21', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 23:19:21', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('19-09-2021 23:49:22', 'dd-mm-yyyy hh24:mi:ss'), 4934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 00:24:08', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 00:54:08', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 01:24:08', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 01:54:09', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 02:24:09', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 02:54:10', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 03:24:10', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 03:54:11', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 04:24:11', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 04:54:12', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 05:24:12', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 05:54:12', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 06:24:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 06:54:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 07:24:14', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 07:54:14', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 08:24:15', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 08:54:15', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 09:24:16', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 09:54:17', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 10:24:17', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 10:54:18', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 11:24:18', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 11:54:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 12:24:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 12:54:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 13:24:20', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 13:54:20', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 14:24:21', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 14:54:21', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 15:24:22', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 15:54:22', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 16:24:23', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 16:54:23', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 17:24:23', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 17:54:24', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 18:24:24', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 18:54:25', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 19:24:25', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 19:54:26', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 20:24:26', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 20:54:27', 'dd-mm-yyyy hh24:mi:ss'), 2098);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 21:24:27', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 21:54:27', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 22:24:28', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 22:54:28', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 23:24:29', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('19-09-2021 23:54:29', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:13:59', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:22:47', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:32:47', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:33:41', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:43:51', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 00:59:24', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:11:45', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:19:46', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:29:46', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:31:48', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 01:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 02:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 02:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 03:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 03:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 04:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 04:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 05:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 05:57:01', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 06:27:01', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 06:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 07:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 07:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 08:27:03', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 08:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 09:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 09:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 10:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 10:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 11:27:06', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 11:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 12:27:07', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 12:57:07', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 13:27:07', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 13:57:08', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 14:27:08', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 14:57:09', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 15:27:09', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 15:57:10', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 16:27:10', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 16:57:10', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 17:27:11', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 17:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 18:27:12', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 18:57:12', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 19:27:13', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 19:57:13', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 20:27:14', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 20:57:14', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 21:27:14', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 21:57:15', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 22:27:15', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 22:57:16', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 23:27:16', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('19-09-2021 23:57:17', 'dd-mm-yyyy hh24:mi:ss'), 4098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 00:10:27', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 00:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 01:10:28', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 01:40:29', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 02:10:29', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 02:40:30', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 03:10:30', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 03:40:31', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 04:10:31', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 04:40:32', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 05:10:32', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 05:40:32', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 06:10:33', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 06:40:33', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 07:10:34', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 07:40:34', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 08:10:35', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 08:40:35', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 09:10:35', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 09:40:36', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 10:10:36', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 10:40:37', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 11:10:37', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 11:40:38', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 12:10:38', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 12:40:39', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 13:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 13:40:39', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 14:10:40', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 14:40:40', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 15:10:41', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 15:40:41', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 16:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 16:40:42', 'dd-mm-yyyy hh24:mi:ss'), 3859);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 17:10:43', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 17:41:48', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 18:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 19:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 19:41:50', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 20:11:50', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 20:41:51', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 21:11:51', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 21:41:52', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 22:11:52', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 22:41:53', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 23:11:53', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('19-09-2021 23:41:54', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 00:14:06', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 00:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 01:14:07', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 01:44:07', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 02:14:08', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 02:44:08', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 03:14:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 03:44:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 04:14:10', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 04:44:10', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 05:14:10', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 05:44:11', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 06:14:11', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 06:44:12', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 07:14:12', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 07:44:13', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 08:14:13', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 08:44:14', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 09:14:14', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 09:44:14', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 10:14:15', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 10:44:15', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 11:14:16', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 11:44:16', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 12:14:17', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 12:44:17', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 13:14:17', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 13:44:18', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 14:14:18', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 14:44:19', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 15:14:19', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 15:44:20', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 16:14:20', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 16:44:21', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 17:14:21', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 17:44:21', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 18:14:22', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 18:44:22', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 19:14:23', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 19:44:23', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 20:14:24', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 20:44:24', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 21:14:25', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 21:44:25', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 22:14:26', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 22:44:26', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 23:14:26', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('19-09-2021 23:44:27', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 00:15:16', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 00:45:16', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 01:15:17', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 01:45:17', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 02:15:18', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 02:45:18', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 03:15:19', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 03:45:19', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 04:15:20', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 04:45:20', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 05:15:21', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 05:45:21', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 06:15:21', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 06:45:22', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 07:15:22', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 07:45:23', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 08:15:23', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 08:45:24', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 09:15:24', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 09:45:25', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 10:15:25', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 10:45:25', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 11:15:26', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 11:45:26', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 12:15:27', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 12:45:27', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 13:15:28', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 13:45:28', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 14:15:28', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 14:45:29', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 15:15:29', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 15:45:30', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 16:15:30', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 16:45:31', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 17:15:31', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 17:45:32', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 18:15:32', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 18:45:32', 'dd-mm-yyyy hh24:mi:ss'), 5152);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 19:15:33', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 19:45:33', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 20:15:34', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 20:45:34', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 21:15:35', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 21:45:35', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 22:15:35', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 22:45:36', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 23:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('19-09-2021 23:45:37', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 00:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 00:57:31', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 01:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 01:57:32', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 02:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 02:57:33', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 03:27:33', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 03:57:34', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 04:27:34', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 04:57:35', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 05:27:35', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 05:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 06:27:36', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 06:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 07:27:37', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 07:57:37', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 08:27:38', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 08:57:38', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 09:27:39', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 09:57:39', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 10:27:40', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 10:57:40', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 11:27:40', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 11:57:41', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 12:27:41', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 12:57:42', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 13:27:42', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 13:57:43', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 14:27:43', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 14:57:44', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 15:27:44', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 15:57:44', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 16:27:45', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 16:57:45', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 17:27:46', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 17:57:46', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 18:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 18:57:47', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 19:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 19:57:48', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 20:27:48', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 20:57:49', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 21:27:49', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 21:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 22:27:50', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 22:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 23:27:51', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('19-09-2021 23:57:51', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 00:14:19', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 00:44:19', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 01:14:20', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 01:44:20', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 02:14:21', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 02:44:21', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 03:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 03:44:22', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 04:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 04:44:23', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 05:14:23', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 05:44:24', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 06:14:24', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 06:44:25', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 07:14:25', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 07:44:25', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 08:14:26', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 08:44:26', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 09:14:27', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 09:44:27', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 10:14:28', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 10:44:28', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 11:14:29', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 11:44:29', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 12:14:29', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 12:44:30', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 13:14:30', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 13:44:31', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 14:14:31', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 14:44:32', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 15:14:32', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 15:44:33', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 16:14:33', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 16:44:33', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 17:14:34', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 17:44:34', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 18:14:35', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 18:45:40', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 19:15:40', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 19:45:41', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 20:15:41', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 20:45:42', 'dd-mm-yyyy hh24:mi:ss'), 1798);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 21:15:42', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 21:45:43', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 22:15:43', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 22:45:43', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 23:15:44', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('19-09-2021 23:45:44', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 00:25:22', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 00:55:22', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 01:25:22', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 01:55:23', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 02:25:23', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 02:55:24', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 03:25:24', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 03:55:25', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 04:25:25', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 04:55:26', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 05:25:26', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 05:55:26', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 06:25:27', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 06:55:27', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 07:25:28', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 07:55:28', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 08:25:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 08:55:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 09:25:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 09:55:30', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 10:25:30', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 10:55:31', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 11:25:31', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 11:55:32', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 12:25:32', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 12:55:33', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 13:25:33', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 13:55:33', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 14:25:34', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 14:55:34', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 15:25:35', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 15:55:35', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 16:25:36', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 16:55:36', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 17:25:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 17:55:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 18:25:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 18:56:40', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 19:26:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 19:56:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 20:26:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 20:56:42', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 21:26:42', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 21:56:43', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 22:26:43', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 22:56:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 23:26:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('19-09-2021 23:56:45', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 00:03:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 00:33:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 01:03:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 01:33:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 02:03:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 02:33:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 03:03:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 03:33:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 04:03:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 04:33:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 05:03:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 05:33:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 06:03:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 06:33:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 07:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 07:33:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 08:03:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 08:33:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 09:03:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 09:33:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 10:03:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 10:33:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 11:03:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 11:33:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 12:03:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 12:33:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 13:03:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 13:33:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 14:03:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 14:33:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 15:03:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 15:33:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 16:03:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 16:33:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 17:03:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 17:33:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 18:03:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 18:33:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 19:03:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 19:33:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 20:03:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 20:33:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 21:03:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 21:33:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 22:03:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 22:33:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 23:03:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('19-09-2021 23:33:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:03:31', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:04:26', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:12:30', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:12:59', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:13:27', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:14:13', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:14:59', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:15:40', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:16:40', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:20:51', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:23:23', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:24:55', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:25:29', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:27:08', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:28:16', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:36:13', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:41:39', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:42:11', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:43:11', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:46:01', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:47:00', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:47:44', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:48:36', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:49:56', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:50:29', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:51:30', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:53:18', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 00:58:39', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 01:08:39', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 01:10:40', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 01:35:49', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 02:05:49', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 02:35:50', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 03:05:50', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 03:35:51', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 04:05:51', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 04:35:52', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 05:05:52', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 05:35:53', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 06:05:53', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 06:35:54', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 07:05:54', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 07:35:54', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 08:05:55', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 08:35:55', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 09:05:56', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 09:35:56', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 10:05:57', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 10:35:57', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 11:05:58', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 11:35:58', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 12:05:59', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 12:35:59', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 13:05:59', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 13:36:00', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 14:06:00', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 14:36:01', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 15:06:01', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 15:36:02', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 16:06:02', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 16:36:03', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 17:06:03', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 17:36:03', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 18:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 18:37:04', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 19:07:04', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 19:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 20:07:05', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 20:37:06', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 21:07:06', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 21:37:07', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 22:07:07', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 22:37:08', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 23:07:08', 'dd-mm-yyyy hh24:mi:ss'), 3157);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('19-09-2021 23:37:08', 'dd-mm-yyyy hh24:mi:ss'), 3157);
commit;
prompt 981 records loaded
set feedback on
set define on
prompt Done.
