CREATE TABLE DADOS_DIA (
    ID_VEICULO             NUMBER NOT NULL,
    DATA                   DATE NOT NULL,
    TEMPO_LIGADO           NUMBER NOT NULL,
    TEMPO_MOVIMENTO        NUMBER NOT NULL,
    TEMPO_HIDRAULICO       NUMBER NOT NULL,
    TEMPO_MOV_HIDRAULICO   NUMBER NOT NULL,
    TEMPO_PARADO_LIGADO    NUMBER NOT NULL
);

ALTER TABLE DADOS_DIA ADD CONSTRAINT PK_DADOS_DIA PRIMARY KEY ( ID_VEICULO, DATA );

COMMENT ON TABLE DADOS_DIA is 'Tabela para armazenar os dados trabalho de um veículo em determinado dia. Armazenamos os dados em colunas separadas, mas o TRABALHO é formado pela SOMA das colunas TEMPO_MOVIMENTO, TEMPO_HIDRAULICO, TEMPO_MOV_HIDRAULICO e PARADO_LIGADO. A coluna TEMPO_LIGADO não entra como trabalho por ser apenas um tempo que indica que o equipamento de telemetria esteve ligado, não que o veículo / máquina tenha efetivamente trabalhado. ATENÇÃO: por causa da forma que os dados são armazenados, os dados nessa tabela não são, necessariamente, IDÊNTICOS se  somarmos os trabalhos de cada HORA para um mesmo veículo em um DIA! Mas não devem existir diferenças muito grandes também!';

COMMENT ON COLUMN DADOS_DIA.ID_VEICULO IS'ID do Veículo, indicando para qual veículo é o registro de trabalho para o dia.';
COMMENT ON COLUMN DADOS_DIA.DATA IS 'Data de registro do trabalho para o Veículo. ATENÇÃO: armazenamos a DATA com hora 00:00, por ser um campo DATA / HORA, mas não fazemos referência às horas para essa tabela.';
COMMENT ON COLUMN DADOS_DIA.TEMPO_LIGADO IS 'Tempo, em horas (fração de horas) em que o equipamento de telemetria ficou LIGADO. Não representa o trabalho, apenas tempo em que o equipamento ficou evetivamente ligado.';
COMMENT ON COLUMN DADOS_DIA.TEMPO_MOVIMENTO IS 'Tempo, em horas (fração de horas)  em que o veículo ficou em MOVIMENTO, para compor o trabalho do DIA. Não é computado para todos os tipos de máquinas e, quando não computado, possui valor 0 ZERO.';
COMMENT ON COLUMN DADOS_DIA.TEMPO_HIDRAULICO IS 'Tempo, em horas (fração de horas),  em que o veículo ficou ACIONANDO HIDRÁULICO (subndo / descendo, deslodano frente / tras ou lateral) para compor o trabalho do DIA. Não é computado para todos os tipos de máquinas e, quando não computado, possui valor 0 ZERO.';
COMMENT ON COLUMN DADOS_DIA.TEMPO_MOV_HIDRAULICO IS 'Tempo, em horas (fração de horas),  em que o veículo ficou MOVENDO e, simultaneamente, ACIONANDO HIDRÁULICO), para compor o trabalho do DIA.';
COMMENT ON COLUMN DADOS_DIA.TEMPO_PARADO_LIGADO IS 'Tempo, em horas (fração de horas),  em que o veículo estava com um Operador PRESENTE, porém não estava executando MOVIMENTO ou ACIONAMENTO HIDRAULICO, para compor o trabalho do DIA.';

CREATE TABLE DADOS_HORA (
    ID_VEICULO             NUMBER NOT NULL,
    DATA                   DATE NOT NULL,
    TEMPO_LIGADO           NUMBER NOT NULL,
    TEMPO_MOVIMENTO        NUMBER NOT NULL,
    TEMPO_HIDRAULICO       NUMBER NOT NULL,
    TEMPO_MOV_HIDRAULICO   NUMBER NOT NULL,
    TEMPO_PARADO_LIGADO    NUMBER NOT NULL
);

ALTER TABLE DADOS_HORA ADD CONSTRAINT PK_DADOS_HORA PRIMARY KEY ( ID_VEICULO, DATA );

COMMENT ON TABLE DADOS_HORA is 'Tabela para armazenar os dados trabalho de um veículo em determinada HORA de um dia. Armazenamos os dados em colunas separadas, mas o TRABALHO é formado pela SOMA das colunas TEMPO_MOVIMENTO, TEMPO_HIDRAULICO, TEMPO_MOV_HIDRAULICO e PARADO_LIGADO. A coluna TEMPO_LIGADO não entra como trabalho por ser apenas um tempo que indica que o equipamento de telemetria esteve ligado, não que o veículo / máquina tenha efetivamente trabalhado. ATENÇÃO: por causa da forma que os dados são armazenados, é NORMAL que, se somarmos os trabalhos de cada HORA para um mesmo veículo, o valor não seja IDÊNTICO ao valor equivalente armazenado na tabela DADOS_DIA! Mas não devem existir diferenças muito grandes também!';

COMMENT ON COLUMN DADOS_HORA.ID_VEICULO IS 'ID do Veículo, indicando para qual veículo é o registro de trabalho para a HORA.';
COMMENT ON COLUMN DADOS_HORA.DATA IS 'Data/hora de registro do trabalho para o Veículo.';
COMMENT ON COLUMN DADOS_HORA.TEMPO_LIGADO IS 'Tempo, em horas (fração de horas), em que o equipamento de telemetria ficou LIGADO. Não representa o trabalho, apenas tempo em que o equipamento ficou evetivamente ligado.';
COMMENT ON COLUMN DADOS_HORA.TEMPO_MOVIMENTO IS 'Tempo, em horas (fração de horas)  em que o veículo ficou em MOVIMENTO, para compor o trabalho da HORA.';
COMMENT ON COLUMN DADOS_HORA.TEMPO_HIDRAULICO IS 'Tempo, em horas (fração de horas),  em que o veículo ficou ACIONANDO HIDRÁULICO (subndo / descendo, deslodano frente / tras ou lateral) para compor o trabalho da HORA. Não é computado para todos os tipos de máquinas e, quando não computado, possui valor 0 ZERO.';
COMMENT ON COLUMN DADOS_HORA.TEMPO_MOV_HIDRAULICO IS 'Tempo, em horas (fração de horas),  em que o veículo ficou MOVENDO e, simultaneamente, ACIONANDO HIDRÁULICO), para compor o trabalho da HORA. Não é computado para todos os tipos de máquinas e, quando não computado, possui valor 0 ZERO.';
COMMENT ON COLUMN DADOS_HORA.TEMPO_PARADO_LIGADO IS 'Tempo, em horas (fração de horas),  em que o veículo estava com um Operador PRESENTE, porém não estava executando MOVIMENTO ou ACIONAMENTO HIDRAULICO, para compor o trabalho da HORA.';

CREATE TABLE DADOS_RASTREADOR (
    ID_VEICULO   NUMBER NOT NULL,
    DATA         DATE,
    HORIMETRO    NUMBER NOT NULL
);

ALTER TABLE DADOS_RASTREADOR ADD CONSTRAINT PK_DADOS_RASTREADOR PRIMARY KEY ( ID_VEICULO, DATA);


COMMENT ON TABLE DADOS_RASTREADOR is 'Tabela para armazenar os dados referentes aos equipamentos transmissores de dados. Por questões de simplificação do problema, foram retirados os dados de posicionamento e outros não relevantes para solução do problema, ficando apenas o valor do HORÍMETRO (ver descrição das colunas).'; 
COMMENT ON COLUMN DADOS_RASTREADOR.ID_VEICULO IS 'ID do Veículo para o qual foi feita a gravação do registro de horímetro do rastreador.';
COMMENT ON COLUMN DADOS_RASTREADOR.DATA IS 'Data/HORA em que foi feito o registro do horímetro do Rastreador.';
COMMENT ON COLUMN DADOS_RASTREADOR.HORIMETRO IS 'Valor, em HORAS "CHEIAS", em que o rastreador permaneceu ligado.';


CREATE TABLE VEICULO (
    ID_VEICULO     NUMBER NOT NULL,
    NUMERO_FROTA   VARCHAR2(15) NOT NULL,
    MODELO         VARCHAR2(30) NOT NULL
);

ALTER TABLE VEICULO ADD CONSTRAINT PK_VEICULO PRIMARY KEY ( ID_VEICULO );

CREATE UNIQUE INDEX AK_NUMERO_FROTA ON  VEICULO (NUMERO_FROTA ASC );

COMMENT ON TABLE VEICULO is 'Tabela para armazenar os dados dos diversos veículos que compõe a frota da empresa, para os quais se deseja medir "trabalho" usando Sistema de Telemetria.';

COMMENT ON COLUMN VEICULO.ID_VEICULO IS 'ID do Veículo, formado por um número sequencial.';
COMMENT ON COLUMN VEICULO.NUMERO_FROTA IS 'Código de identificação do veículo para o Cliente. Ou, em outras palavras, a forma como o cliente identifica unicamente cada veículo.';
COMMENT ON COLUMN VEICULO.MODELO IS 'Modelo do veículo, definido pelo fabricante do mesmo.';



ALTER TABLE DADOS_DIA ADD CONSTRAINT FK_VEICULO_DADOS_DIA FOREIGN KEY ( ID_VEICULO ) REFERENCES VEICULO ( ID_VEICULO );

ALTER TABLE DADOS_HORA ADD CONSTRAINT FK_VEICULO_DADOS_HORA FOREIGN KEY ( ID_VEICULO ) REFERENCES VEICULO ( ID_VEICULO );

ALTER TABLE DADOS_RASTREADOR ADD CONSTRAINT FK_VEICULO_DADOS_RASTREADOR FOREIGN KEY ( ID_VEICULO ) REFERENCES VEICULO ( ID_VEICULO );