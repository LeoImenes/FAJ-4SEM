﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 00:19:59', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 00:50:00', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 01:20:00', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 01:50:01', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 02:20:01', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 02:50:02', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 03:20:02', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 03:50:03', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 04:20:03', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 04:50:03', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 05:20:04', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 05:50:04', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 06:20:05', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 06:50:05', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:20:06', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:20:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:21:15', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:21:33', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:21:37', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:21:39', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:21:42', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:26:46', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:27:19', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:27:21', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:30:33', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:40:33', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:42:37', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:49:49', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:49:59', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:50:01', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 07:59:44', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 08:09:44', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 08:11:47', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 08:36:56', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:06:57', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:36:57', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:41:53', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:42:04', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:42:06', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:42:54', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:52:54', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 09:54:57', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:00:02', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:00:16', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:00:18', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:01:24', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:05:00', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:09:01', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:09:17', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:09:19', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:12:13', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:18:12', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:18:21', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:20:13', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:24:36', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:24:43', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:24:45', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:31:04', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:41:04', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 10:43:07', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 11:08:17', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 11:38:17', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:00:24', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:00:26', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:05:40', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:07:20', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:08:59', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:09:09', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:09:11', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:16:25', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:26:25', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:31:25', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:32:16', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:42:16', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 12:44:20', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 13:09:30', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 13:39:30', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:09:31', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:12:16', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:12:26', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:12:28', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:16:25', 'dd-mm-yyyy hh24:mi:ss'), 1468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:23:40', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:37:13', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:37:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:37:20', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:46:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:53:16', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:53:23', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 14:53:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:06:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:16:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:17:39', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1469);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:17:50', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:23:36', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:33:36', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 15:35:39', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:00:48', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:17:13', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:17:23', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:17:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:19:00', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:29:00', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:31:03', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 16:56:12', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 17:26:13', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 17:56:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 18:26:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 18:56:14', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 19:26:15', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 19:56:15', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 20:26:16', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 20:56:16', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 21:26:17', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 21:56:17', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 22:26:18', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 22:56:18', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 23:26:18', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('14-09-2021 23:56:19', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 00:13:42', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 00:43:43', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 01:13:43', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 01:43:44', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 02:13:44', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 02:43:44', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 03:13:45', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 03:43:45', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 04:13:46', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 04:43:46', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 05:13:47', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 05:43:47', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 06:13:48', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 06:43:48', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 07:13:48', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 07:43:49', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:13:49', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:41:53', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:42:39', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:42:51', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:42:56', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:42:58', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:43:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:53:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:55:08', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:58:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 08:58:13', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:03:06', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:13:06', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:15:09', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:16:43', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:17:10', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:17:12', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:21:28', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:28:11', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:30:53', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:31:25', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:41:25', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 09:43:27', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:08:36', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:38:36', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:52:48', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:53:00', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:53:03', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:54:03', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:54:16', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 10:55:02', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 11:05:02', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 11:06:06', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 11:31:15', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:01:16', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:31:16', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:50:52', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:51:00', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:51:02', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:58:11', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 12:59:05', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:01:26', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:11:10', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:13:11', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:15:05', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:25:05', 'dd-mm-yyyy hh24:mi:ss'), 252);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:28:11', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:38:11', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:43:11', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:45:30', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 13:52:26', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:02:09', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:02:18', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:02:20', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:02:37', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:03:15', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:05:30', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:05:38', 'dd-mm-yyyy hh24:mi:ss'), 253);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:06:43', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:15:40', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:15:53', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:15:55', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:19:18', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:19:37', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:29:37', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:31:38', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 14:56:47', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 15:26:48', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 15:56:48', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 16:26:48', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 16:56:49', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 17:26:49', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 17:56:50', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 18:26:50', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 18:56:51', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 19:26:51', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 19:56:52', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 20:26:52', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 20:56:52', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 21:26:53', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 21:56:53', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 22:26:54', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 22:56:54', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 23:26:55', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('14-09-2021 23:56:55', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 00:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 00:33:30', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 01:03:30', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 01:33:31', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 02:03:31', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 02:33:32', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 03:03:32', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 03:33:32', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 04:03:33', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 04:33:33', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 05:03:34', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 05:33:34', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 06:03:35', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 06:33:35', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:03:36', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:33:36', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:41:46', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:42:26', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:42:51', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:42:55', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:42:57', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:50:09', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:50:30', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:56:09', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:56:32', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:56:34', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:57:03', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:57:04', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:57:13', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:57:15', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:58:46', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:58:50', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:58:52', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:59:21', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 07:59:35', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:00:03', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:00:05', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:02:39', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:05:50', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:08:39', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:08:50', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:08:52', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:17:39', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:27:39', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:30:53', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:40:44', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:43:21', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:50:52', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:50:58', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 08:51:00', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:01:01', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:02:11', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:03:20', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:03:31', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:13:31', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:20:34', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:23:21', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:23:23', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:23:30', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:32:38', 'dd-mm-yyyy hh24:mi:ss'), 1307);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:39:42', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:40:57', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:47:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:48:22', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 09:58:20', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:02:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:10:53', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:16:45', 'dd-mm-yyyy hh24:mi:ss'), 1308);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:17:23', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:17:25', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:27:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:32:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:42:38', 'dd-mm-yyyy hh24:mi:ss'), 1308);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:44:59', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:47:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:49:37', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 10:59:37', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 11:01:39', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 11:26:48', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:39:17', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:39:40', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:39:42', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:47:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 12:55:58', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:02:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:12:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:19:27', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:24:49', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:25:51', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:26:00', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:26:02', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:30:47', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:32:38', 'dd-mm-yyyy hh24:mi:ss'), 1309);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:42:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:43:40', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:45:10', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:45:50', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:47:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:48:21', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:49:10', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:49:25', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:49:27', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 13:52:01', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:02:01', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:04:01', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:16:28', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:16:36', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:16:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:19:50', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:25:20', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:25:42', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:25:44', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:27:41', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:28:06', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:29:35', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:39:35', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:41:52', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:55:41', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:55:48', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:55:50', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 14:58:42', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:08:42', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:10:45', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:27:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:27:46', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:27:48', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:32:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:42:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:47:38', 'dd-mm-yyyy hh24:mi:ss'), 1310);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 15:57:38', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 16:02:38', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 16:16:49', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 16:19:08', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 16:44:17', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 17:14:18', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 17:44:18', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 18:14:19', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 18:44:19', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 19:14:19', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 19:44:20', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 20:14:20', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 20:44:21', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 21:14:21', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 21:44:22', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 22:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 22:44:23', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 23:14:23', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('14-09-2021 23:44:23', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:01:41', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:04:18', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:04:35', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:04:37', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:11:19', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:26:31', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:36:31', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:38:32', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:41:10', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:41:16', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:41:18', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 00:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:01:54', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:23:10', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:24:26', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:34:26', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 01:36:28', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 02:01:37', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 02:31:38', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 03:01:38', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 03:31:39', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 04:01:39', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 04:31:39', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 05:01:40', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 05:31:40', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 06:01:41', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 06:31:41', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:01:42', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:09:26', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:10:30', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:11:03', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:11:08', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:11:10', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:15:26', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:25:26', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:27:28', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:29:43', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:30:06', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:30:08', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:30:35', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:30:37', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:31:47', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:31:58', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:01', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:03', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:27', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:40', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:52', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:32:54', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:42:54', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 07:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:03:28', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:13:28', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:13:53', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:14:01', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:14:03', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:43:56', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:44:03', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:45:16', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:45:23', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:45:25', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 08:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:20:44', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:21:29', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:21:37', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:21:39', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:32:02', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:37:27', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:38:53', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:39:00', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:39:02', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:46:01', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 09:58:08', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:05:59', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:06:16', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:06:18', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:16:19', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:32:57', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:42:57', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:44:59', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:46:42', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:46:51', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:46:53', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:46:55', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 10:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:11:33', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:17:38', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:27:38', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:40:20', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4999);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 11:53:07', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:02:19', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:02:27', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:02:29', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:02:30', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:12:30', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:24:43', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:27:47', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:30:37', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:30:47', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:30:49', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:41:26', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:42:03', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:46:52', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 12:58:37', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 13:08:37', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 13:10:38', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 13:35:47', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:00:25', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:00:38', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:00:40', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:21:10', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:21:55', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:23:04', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:23:10', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:23:12', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:23:40', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:28:44', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:28:50', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:28:52', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:54:33', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 14:57:19', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:01:31', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:01:44', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:01:46', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:01:47', 'dd-mm-yyyy hh24:mi:ss'), 5000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:09:40', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:14:03', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:44:14', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:50:07', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:50:14', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 15:50:16', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:00:17', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5001);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:25:21', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:25:57', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:35:57', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:37:59', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:55:01', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:55:29', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:55:42', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:55:47', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 16:55:49', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:10:01', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:20:01', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:22:02', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:24:35', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:24:58', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:25:00', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:25:43', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:27:07', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:27:11', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:27:13', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:28:00', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:28:14', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:28:28', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:28:30', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:46:15', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 17:56:48', 'dd-mm-yyyy hh24:mi:ss'), 5002);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:10:00', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:10:15', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:14:37', 'dd-mm-yyyy hh24:mi:ss'), 5003);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:14:46', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:14:48', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 18:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5003);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:12:05', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:15:41', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:16:22', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:16:39', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:16:44', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:16:46', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:16:49', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:23:56', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 19:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:03:17', 'dd-mm-yyyy hh24:mi:ss'), 5004);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:10:58', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:16:11', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:38:35', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 20:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5005);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:16:29', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:30:22', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:35:21', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:35:23', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:41:22', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:51:22', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 21:53:24', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:18:33', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:36:46', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:37:21', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:37:35', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:37:40', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:37:42', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:44:30', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 22:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5006);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:23:27', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:33:38', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:34:02', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:34:04', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('14-09-2021 23:52:58', 'dd-mm-yyyy hh24:mi:ss'), 5007);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 00:03:24', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 00:33:24', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 01:03:25', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 01:33:25', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 02:03:26', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 02:33:26', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 03:03:27', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 03:33:27', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 04:03:27', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 04:33:28', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 05:03:28', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 05:33:29', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 06:03:29', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 06:33:30', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:03:30', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:12:41', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:14:04', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:14:47', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:14:51', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:14:53', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:18:27', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:27:15', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:28:23', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:33:00', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:36:41', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:36:43', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:36:50', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:36:52', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:38:13', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:38:17', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:38:19', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:38:41', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:40:10', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:40:20', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:40:22', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:43:23', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:44:59', 'dd-mm-yyyy hh24:mi:ss'), 934);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:54:59', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 07:57:01', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:15:53', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:15:59', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:16:01', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:22:53', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:27:29', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:28:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:38:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:43:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:53:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:56:04', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 08:58:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:01:53', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:11:53', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:13:23', 'dd-mm-yyyy hh24:mi:ss'), 935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:23:23', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:24:50', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:28:23', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:29:53', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:34:35', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:42:11', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:42:25', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:42:27', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:43:23', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:52:33', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:53:19', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:53:26', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:53:28', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:58:24', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 09:59:39', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:09:17', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:11:56', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:21:56', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:24:25', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:28:20', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:28:29', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:28:31', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:28:32', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:38:32', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:39:02', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:48:27', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:48:38', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:48:40', 'dd-mm-yyyy hh24:mi:ss'), 936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 10:56:26', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 11:06:26', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 11:08:28', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 11:33:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:03:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:33:39', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:47:25', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:47:36', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:47:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:48:26', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 12:58:26', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 13:00:28', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 13:25:37', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 13:55:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:07:28', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:07:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:07:37', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:13:23', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:15:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:25:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:27:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 14:52:44', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 15:22:44', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 15:52:45', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:03:51', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:03:59', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:04:01', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:13:23', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:13:25', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:14:34', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:24:34', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:26:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 16:51:44', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 17:21:45', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 17:51:45', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 18:21:46', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 18:51:46', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 19:21:46', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 19:51:47', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 19:59:47', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:01:11', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:01:55', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:02:00', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:02:02', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:07:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:17:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:19:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:44:44', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:51:45', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:51:52', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:51:54', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 20:57:18', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 21:07:18', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 21:09:20', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 21:34:30', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 22:04:30', 'dd-mm-yyyy hh24:mi:ss'), 937);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 22:34:30', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 23:04:31', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('14-09-2021 23:34:31', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 00:25:22', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 00:55:22', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 01:25:23', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 01:55:24', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 02:25:24', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 02:55:25', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 03:25:25', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 03:55:26', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 04:25:26', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 04:55:27', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 05:25:27', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 05:55:28', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 06:25:28', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 06:55:29', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:25:29', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:50:52', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:52:13', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:52:40', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:52:44', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 07:52:46', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:02:39', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:12:39', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:14:42', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:16:24', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:16:34', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:16:36', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:45:10', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:46:19', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:51:22', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:51:28', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:51:30', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 08:53:07', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:03:07', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:11:20', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:11:27', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:11:29', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:23:55', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:33:55', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:35:13', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:35:19', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 09:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:10:06', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:20:06', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:22:07', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:22:40', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:23:03', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:23:05', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:23:51', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:28:34', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:29:29', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:29:51', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:29:55', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:29:57', 'dd-mm-yyyy hh24:mi:ss'), 2034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:44:52', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:48:26', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 10:58:26', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 11:00:27', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 11:25:36', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 11:55:37', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:23:16', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:23:24', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:23:26', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:33:29', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:45:09', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:46:13', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:47:30', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:57:30', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 12:59:32', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:24:42', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:30:43', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:30:51', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:30:53', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:45:09', 'dd-mm-yyyy hh24:mi:ss'), 2035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:56:41', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:58:41', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:58:50', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 13:58:52', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:04:29', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:07:32', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:07:39', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:07:41', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:15:01', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:25:01', 'dd-mm-yyyy hh24:mi:ss'), 2036);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:27:03', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 14:52:12', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:21:08', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:21:15', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:21:17', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:28:57', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:34:48', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:34:55', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:34:57', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:39:42', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:43:15', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:43:21', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:43:23', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:46:01', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:51:11', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 15:58:23', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 16:08:23', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 16:10:25', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 16:35:35', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 17:07:48', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 17:37:49', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 18:07:49', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 18:37:50', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 19:07:50', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 19:37:51', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 20:07:51', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 20:37:51', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 21:07:52', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 21:37:52', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 22:07:53', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 22:37:53', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 23:07:54', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('14-09-2021 23:37:54', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:03:07', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:03:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:10:08', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:20:08', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:22:10', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 00:47:19', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 01:17:20', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 01:47:20', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:17:21', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:47:21', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:04', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:05', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:37', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:52', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:56', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:51:58', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 02:57:06', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:00:31', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:00:33', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:00:48', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:00:50', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:02:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:12:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:14:13', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 03:39:22', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 04:09:23', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 04:39:23', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 05:09:24', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 05:39:24', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 06:09:25', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 06:39:25', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 07:09:26', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 07:39:26', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:09:26', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:39:27', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:44:59', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:46:14', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:47:10', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:47:15', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:47:17', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:52:37', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:55:15', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:55:17', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:55:37', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 08:55:39', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:02:06', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:03:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:05:48', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:13:49', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:28:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:33:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:34:21', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:44:21', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 09:46:23', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:11:33', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:14:16', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:14:18', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:15:19', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:15:57', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:16:02', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:16:04', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:19:25', 'dd-mm-yyyy hh24:mi:ss'), 1425);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:25:20', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:27:58', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:37:16', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:37:17', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:37:27', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:37:29', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:44:39', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:49:41', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 10:59:41', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:01:43', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:26:52', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:46:19', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:47:26', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:47:45', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:47:49', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:47:51', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 11:51:20', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:01:20', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:03:22', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:06:15', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:06:27', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:06:29', 'dd-mm-yyyy hh24:mi:ss'), 1425);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:15:46', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:28:11', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:29:15', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:30:23', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:32:30', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:32:32', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:32:45', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:32:47', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:33:11', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:51:49', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 12:53:51', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 13:19:00', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 13:49:00', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 14:19:01', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 14:49:01', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 15:19:02', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 15:49:02', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 16:19:03', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 16:49:03', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 17:19:04', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 17:49:04', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 18:19:05', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 18:49:05', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 19:19:05', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 19:49:06', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 20:19:06', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 20:49:07', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 21:19:07', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 21:49:08', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 22:19:08', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 22:49:09', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 23:19:09', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('14-09-2021 23:49:09', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:34:21', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:43:49', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:44:01', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:44:03', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:44:25', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:45:58', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:46:22', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:46:24', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:47:10', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:47:12', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:48:43', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:48:47', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:48:49', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:49:03', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:49:14', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:49:45', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:49:57', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:07:02', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:20:19', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:22:54', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:36:57', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:43:24', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:49:01', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:49:09', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:49:11', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:50:35', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:56:09', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:56:20', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:56:22', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 08:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:07:02', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:07:52', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:13:46', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:23:46', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4862);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:33:18', 'dd-mm-yyyy hh24:mi:ss'), 4862);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:44:33', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:48:48', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 09:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:00:21', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:02:35', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:06:56', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:06:58', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:07:43', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:22:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:31:08', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:31:41', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:41:41', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4863);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:51:54', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:59:50', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 10:59:59', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:07:33', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:10:55', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:11:23', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:11:25', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:16:25', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:26:25', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:32:39', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:38:37', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:51:03', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:51:12', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:51:14', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 11:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4864);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:04:11', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:06:42', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:14:44', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:15:09', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:15:11', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:16:33', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:16:43', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:16:53', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:16:56', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:16:58', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:17:07', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:27:07', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:28:35', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 12:53:44', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:23:45', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:28:06', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:32:52', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:32:54', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 13:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:00:04', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:01:07', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:01:31', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:01:33', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:01:57', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:08:41', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:08:56', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:08:58', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:09:20', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:19:20', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:21:21', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:48:13', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:48:32', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:48:34', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 14:49:36', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:00:34', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:00:47', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:00:49', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:01:27', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:11:27', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:12:24', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:12:31', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:12:35', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:12:37', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:12:39', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:13:01', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:16:23', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:19:53', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:19:55', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:20:22', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:23:35', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:25:34', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:26:17', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:26:30', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:26:35', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:26:37', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:33:10', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:33:28', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:34:28', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:34:43', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:34:45', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4865);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:52:02', 'dd-mm-yyyy hh24:mi:ss'), 4866);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 15:58:55', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:03:00', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:03:10', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:03:12', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:14:26', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:24:26', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:26:28', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:51:38', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:57:01', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:57:58', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:58:22', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:58:27', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 16:58:29', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:02:00', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:02:22', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:09:07', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:09:31', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:09:33', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:10:06', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:10:09', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:11:22', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:11:25', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:11:27', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:12:27', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:12:46', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:12:59', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:13:01', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:15:12', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:15:33', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:25:26', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:27:02', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:34:12', 'dd-mm-yyyy hh24:mi:ss'), 4866);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:51:56', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:56:27', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 17:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:00:15', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:04:16', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:11:04', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:15:40', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:25:40', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:27:45', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:29:40', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:39:41', 'dd-mm-yyyy hh24:mi:ss'), 4867);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:47:48', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:54:11', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:54:34', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:54:37', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:55:47', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 18:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:06:50', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:10:13', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:12:42', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:17:34', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:21:08', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:27:39', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:37:39', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:40:19', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4868);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:52:00', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:56:17', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:56:26', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 19:57:08', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:01:10', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:09:52', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:11:15', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:13:18', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:17:24', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:20:47', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:20:53', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:31:39', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:31:43', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:38:11', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:38:27', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:41:40', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4869);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:49:09', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 20:59:09', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:01:11', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:20:21', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:20:42', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:20:44', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:37:00', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:42:50', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:47:25', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:47:59', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:48:37', 'dd-mm-yyyy hh24:mi:ss'), 4870);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:52:03', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 21:58:18', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:08:18', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:09:26', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:11:07', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:15:55', 'dd-mm-yyyy hh24:mi:ss'), 4870);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:25:29', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:28:13', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:29:39', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:34:47', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:35:14', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:49:19', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 22:59:19', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:01:21', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:01:26', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:02:01', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:02:17', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:02:21', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:02:23', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:10:44', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:14:48', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:24:48', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4871);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:34:50', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:52:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 23:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:02:02', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:04:01', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:05:37', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:05:50', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:05:52', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:08:46', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:09:21', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:12:58', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:17:56', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:18:36', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:21:14', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:21:36', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:22:27', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:37:04', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:37:14', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:41:36', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:49:42', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:50:56', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:52:47', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:52:49', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:54:29', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:54:31', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:56:09', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:56:11', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:58:15', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:58:18', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 00:59:51', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:02:08', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:03:32', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:05:08', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:06:39', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:09:13', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:12:03', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:12:19', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:16:24', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:16:26', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:17:44', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:24:07', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:25:16', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:26:10', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:26:13', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:27:24', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:31:10', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:31:44', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:31:48', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:39:37', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:41:48', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:43:15', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:44:48', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:47:20', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:48:05', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:50:36', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:51:31', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:51:33', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:54:27', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 01:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4860);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 02:07:03', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 02:09:14', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 02:19:14', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 02:21:15', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 02:46:24', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 03:16:24', 'dd-mm-yyyy hh24:mi:ss'), 4861);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 03:46:25', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 04:16:25', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 04:46:26', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 05:16:26', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 05:46:27', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 06:16:27', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 06:46:28', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:16:28', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:17:45', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:17:47', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:17:53', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:19:52', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:20:09', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:20:14', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:20:16', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:22:19', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('14-09-2021 07:32:19', 'dd-mm-yyyy hh24:mi:ss'), 4861);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:03:56', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:03:58', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:11:21', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:14:48', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:18:45', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:26:38', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:26:48', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:26:50', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:26:52', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:36:52', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3818);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 09:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:25:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:34:41', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:34:43', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:51:50', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:55:03', 'dd-mm-yyyy hh24:mi:ss'), 3819);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:42:09', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:46:52', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:47:04', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:47:06', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3820);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 12:54:10', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 13:04:10', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 13:06:11', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 13:31:20', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:01:21', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:09:37', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:09:44', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:09:46', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3821);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 14:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3822);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:05:25', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:11:44', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:43:15', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:44:00', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:44:19', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:44:24', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:44:26', 'dd-mm-yyyy hh24:mi:ss'), 3823);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:44:36', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:54:36', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:58:01', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:58:09', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 16:58:11', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:01:18', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:02:53', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:03:04', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:03:06', 'dd-mm-yyyy hh24:mi:ss'), 3823);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:09:56', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:15:30', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:15:52', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:15:54', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:16:34', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:16:36', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:17:57', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:18:01', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:18:03', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:18:35', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:28:35', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:30:38', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:36:03', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:36:14', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:36:16', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 17:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:08:36', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3824);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:42:10', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:42:44', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:42:54', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:42:56', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:52:56', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 18:58:58', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:07:39', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:07:47', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:07:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:11:21', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:20:17', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:20:26', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:20:28', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:29:54', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:32:18', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:32:25', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:32:27', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:32:38', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:42:38', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 19:44:39', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 20:09:48', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 20:39:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 21:09:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 21:39:50', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 22:09:50', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 22:39:51', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 23:09:51', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 23:39:52', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 00:16:14', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 00:46:14', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 01:16:15', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 01:46:15', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 02:16:16', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 02:46:16', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:04:42', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:05:57', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:06:27', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:06:31', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:06:33', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:16:40', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 03:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:08:22', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:18:22', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 04:45:32', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 05:15:33', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 05:45:33', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 06:15:34', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 06:45:34', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 06:59:34', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:00:07', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:10:07', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:12:48', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:17:22', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:18:14', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:18:18', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:18:20', 'dd-mm-yyyy hh24:mi:ss'), 2075);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:18:23', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:19:38', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:29:39', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:31:39', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:32:45', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:08', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:10', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:33', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:34', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:42', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:33:45', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:35:22', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:35:26', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:35:28', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:35:30', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:35:48', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:36:06', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:36:15', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:36:17', 'dd-mm-yyyy hh24:mi:ss'), 2075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:39:57', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:42:31', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:42:38', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:42:40', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:44:02', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 07:53:57', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:03:57', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:43:34', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:44:27', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:44:36', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:44:38', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:49:38', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:54:17', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:54:25', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 08:54:27', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:00:01', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:04:06', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:14:06', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:16:07', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:41:16', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:47:14', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:48:02', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:48:04', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 09:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:06:39', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:09:41', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:09:49', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:09:51', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:13:17', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:13:20', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:15:31', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:15:38', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:15:40', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:28:16', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:38:16', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:40:18', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:44:38', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:44:45', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:44:47', 'dd-mm-yyyy hh24:mi:ss'), 2077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 10:56:21', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:03:49', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:40:46', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:45:45', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:45:53', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:45:55', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:47:36', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:57:36', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 11:59:38', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:15:17', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:15:27', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:15:29', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:21:19', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:21:23', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:26:26', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:29:04', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:46:01', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 12:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:24:13', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:24:22', 'dd-mm-yyyy hh24:mi:ss'), 2079);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:24:24', 'dd-mm-yyyy hh24:mi:ss'), 2079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:26:26', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 13:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:05:13', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:34:32', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:38:06', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:38:45', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:38:47', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:47:48', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:49:19', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:49:30', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:49:32', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 14:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:01:53', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:16:01', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:24:48', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:34:48', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:01:58', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:31:59', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:32:32', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:32:41', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:32:43', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:32:58', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:33:02', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:33:20', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:43:20', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:45:00', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:59:19', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 16:59:30', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:05:57', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:06:26', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:06:39', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:06:44', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:06:46', 'dd-mm-yyyy hh24:mi:ss'), 2081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:13:10', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:13:12', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:14:30', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:14:34', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:14:36', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:15:06', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:15:35', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:15:41', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:15:43', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:20:51', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:41:04', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:43:48', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 17:57:41', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 18:53:34', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 19:03:34', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 19:05:35', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 19:30:44', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 20:00:44', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 20:30:45', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 21:00:45', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 21:30:46', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 22:00:46', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 22:30:47', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 23:00:47', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('14-09-2021 23:30:47', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 00:27:42', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 00:57:43', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 01:27:43', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 01:57:44', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:03:50', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:04:20', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:04:38', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:04:43', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:04:45', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:35:34', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:36:58', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:39:04', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:40:21', 'dd-mm-yyyy hh24:mi:ss'), 3813);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:40:30', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:53:50', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 02:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:09:37', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3814);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 03:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:00:53', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:10:53', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:12:55', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:14:30', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:14:45', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:14:47', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:24:52', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:56:29', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 04:58:18', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:08:18', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:10:20', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:16:03', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:16:17', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:16:19', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:22:48', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:32:48', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:34:50', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:37:25', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:37:35', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:37:37', 'dd-mm-yyyy hh24:mi:ss'), 3815);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:49:14', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:57:31', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:57:39', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:57:41', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 05:57:43', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:00:39', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:03:37', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:03:44', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:03:46', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:23:53', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:26:10', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:26:20', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:26:22', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:28:17', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:30:07', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:30:14', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:30:16', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:31:55', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:41:55', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 06:43:56', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:09:05', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:17:54', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:18:59', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:19:36', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:19:40', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:19:42', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:34:59', 'dd-mm-yyyy hh24:mi:ss'), 3816);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 07:59:44', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:00:43', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:00:45', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:02:27', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:02:30', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:02:32', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:03:01', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('14-09-2021 08:03:50', 'dd-mm-yyyy hh24:mi:ss'), 3817);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:03:01', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:07:27', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:08:12', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:10:24', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:10:52', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:12:33', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:13:51', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:14:18', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:18:54', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:24:28', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:34:28', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:40:10', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:46:45', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:48:34', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2962);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:50:46', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 00:54:38', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:02:38', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:03:39', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:05:38', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:11:22', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:16:22', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:19:02', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:19:27', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:24:29', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:25:21', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 01:37:22', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:01:03', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:01:10', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:01:12', 'dd-mm-yyyy hh24:mi:ss'), 2962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:07:37', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:08:11', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:14:46', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:24:46', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:26:48', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 02:51:57', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 03:21:58', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 03:51:58', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 04:21:58', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 04:51:59', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 05:21:59', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 05:52:00', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 06:22:00', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 06:52:01', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 07:17:44', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 07:18:39', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 07:28:39', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 07:30:42', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 07:55:52', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 08:25:52', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 08:55:52', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 09:15:02', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 09:16:23', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 09:26:23', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 09:28:25', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 09:53:34', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 10:23:35', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 10:53:35', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 11:23:36', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 11:53:36', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 12:23:36', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 12:53:37', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 13:23:37', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 13:53:38', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 14:23:38', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 14:53:39', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:23:39', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:23:49', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:24:15', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:25:11', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:25:17', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:28:37', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:29:20', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:33:53', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:35:02', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:35:49', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:36:16', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:36:18', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:36:23', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:46:23', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:48:03', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:53:05', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:53:24', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:54:23', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:55:08', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:55:13', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 15:55:15', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:04:33', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:11:24', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:21:24', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:23:26', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:48:35', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:57:35', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:57:46', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 16:57:48', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:01:29', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:01:31', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:02:01', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:12:01', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:14:03', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:28:54', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:29:02', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:29:04', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:45:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:45:45', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 17:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:00:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:15:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:30:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:45:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 18:55:31', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:05:31', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:07:33', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:32:43', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:34:49', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:34:53', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:34:55', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:35:30', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:35:51', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:35:55', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:35:57', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:36:00', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:45:11', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:48:39', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:55:50', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:56:55', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:58:22', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:58:48', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 19:59:12', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:15:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:18:09', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:20:06', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:21:36', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:21:56', 'dd-mm-yyyy hh24:mi:ss'), 2965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:24:40', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:26:39', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:27:21', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:29:52', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:31:21', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:43:52', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:44:40', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:44:59', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:48:00', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:56:02', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:56:56', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:57:53', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 20:59:52', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:03:43', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:06:43', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:07:24', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:11:54', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:12:28', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:13:25', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:22:06', 'dd-mm-yyyy hh24:mi:ss'), 2966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:31:14', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:36:31', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:39:01', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:40:41', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:46:49', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:47:27', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:48:51', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:49:19', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:51:34', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:52:54', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:54:19', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:54:41', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:55:01', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:55:16', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 21:56:51', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:03:34', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:11:19', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:11:31', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:21:31', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:23:33', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:25:55', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:26:04', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:26:06', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:36:41', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:46:41', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 22:48:42', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:13:51', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:41:33', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:41:41', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:41:43', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:43:38', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:45:13', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:45:37', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:46:05', 'dd-mm-yyyy hh24:mi:ss'), 2967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:49:01', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:49:17', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:50:26', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:52:55', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:54:53', 'dd-mm-yyyy hh24:mi:ss'), 2968);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:55:20', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('14-09-2021 23:55:59', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 00:19:51', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 00:49:51', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 01:19:52', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 01:49:52', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 02:19:53', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 02:49:53', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 03:19:54', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 03:49:54', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 04:19:55', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 04:49:55', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 05:19:55', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 05:49:56', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 06:19:56', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 06:49:57', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:19:13', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:20:04', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:25:27', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:26:18', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:26:22', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:26:24', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:33:16', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:44:27', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:49:56', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:50:17', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:50:19', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:50:21', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:50:53', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:50:55', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:52:19', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:52:22', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:52:24', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:52:46', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:54:58', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:55:19', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 07:55:21', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:40:30', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 08:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:00:17', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:01:59', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:08:25', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:12:47', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:12:49', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:19:02', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:42:48', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 09:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:00:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:25:21', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:45:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 10:58:01', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:04:31', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:04:38', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:04:40', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:18:27', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:38:29', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:48:29', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 11:50:30', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:15:39', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:45:40', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:53:41', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:54:15', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:54:17', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 12:58:43', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:17:19', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:42:20', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:47:44', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:47:53', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:47:55', 'dd-mm-yyyy hh24:mi:ss'), 4028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 13:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:00:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:12:08', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:20:54', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:30:54', 'dd-mm-yyyy hh24:mi:ss'), 4029);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:45:03', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:46:23', 'dd-mm-yyyy hh24:mi:ss'), 4029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 14:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:05:30', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:14:35', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:30:23', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:37:33', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:37:41', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:37:43', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:47:46', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:49:22', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 15:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:00:03', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:01:23', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:04:48', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:14:39', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:24:39', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:26:41', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:51:51', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:58:59', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:59:33', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:59:47', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:59:51', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 16:59:53', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:09:49', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:19:49', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:33:35', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:40:20', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:40:27', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:40:29', 'dd-mm-yyyy hh24:mi:ss'), 4031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 17:56:09', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:02:18', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:11:15', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:42:34', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:52:34', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 18:54:36', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:19:46', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:32:53', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:33:29', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:33:48', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:33:53', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:33:55', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:34:34', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:44:34', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 19:46:36', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 20:11:46', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 20:41:46', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:11:47', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:27:19', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:27:30', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:27:32', 'dd-mm-yyyy hh24:mi:ss'), 4032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:39:49', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:49:49', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 21:59:40', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:03:39', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:15:02', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:19:54', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:31:32', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:45:03', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 22:51:48', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:01:48', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:02:55', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:08:24', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:18:24', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:31:56', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:45:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:51:51', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('14-09-2021 23:53:51', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:00:28', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:01:32', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:01:47', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:01:55', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:05:35', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5098);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:10:13', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:15:39', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:16:14', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:18:04', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:18:12', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:19:36', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:19:57', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:29:57', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:31:59', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:34:21', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:34:28', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:34:30', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:36:49', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:39:54', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:44:46', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:46:18', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:50:15', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:53:40', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:54:04', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 00:58:47', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:00:42', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:04:32', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:05:05', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:05:29', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:07:06', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:07:46', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:07:49', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:11:18', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:12:30', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:13:43', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:13:47', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:16:59', 'dd-mm-yyyy hh24:mi:ss'), 5098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:23:16', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:23:36', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:24:17', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:26:06', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:36:06', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:38:07', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:46:40', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:46:48', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:46:50', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:50:37', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:52:49', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:53:23', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:55:34', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:55:44', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:55:56', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:56:05', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 01:57:20', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 02:07:20', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 02:09:22', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 02:34:32', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 03:04:32', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 03:34:32', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 04:04:33', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 04:34:33', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 05:04:34', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 05:34:34', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 06:04:35', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 06:34:35', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:04:36', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:16:33', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:17:56', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:18:13', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:18:17', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:18:19', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:21:57', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:22:02', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:30:02', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:37:47', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:40:07', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:42:23', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:42:49', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:42:51', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:43:33', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:43:35', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:44:57', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:45:00', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:45:02', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:45:39', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:46:06', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:46:16', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:46:18', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:49:46', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 07:56:42', 'dd-mm-yyyy hh24:mi:ss'), 5099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:04:18', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:04:51', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:09:21', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:09:26', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5100);
commit;
prompt 2400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:10:41', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:11:06', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:11:14', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:12:50', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:13:27', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:13:45', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:19:16', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:23:15', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:23:23', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:27:26', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:31:52', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:32:10', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:34:13', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:38:08', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:39:41', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:40:03', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:42:37', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:44:21', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:45:10', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:45:26', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:47:03', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:53:27', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:54:41', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:55:02', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:56:09', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 08:57:24', 'dd-mm-yyyy hh24:mi:ss'), 5100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:01:52', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:03:03', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:15:09', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:18:14', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:18:23', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:30:22', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:31:10', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:32:53', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:33:54', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:34:13', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:35:08', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:40:43', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:41:55', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:44:34', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:45:21', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:45:34', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:47:04', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:47:19', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:48:27', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:54:23', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:54:31', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:54:33', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:55:04', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:55:27', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:55:30', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:56:47', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:57:04', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:57:15', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:57:22', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:58:08', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:58:19', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:58:38', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:58:52', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 09:59:19', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:01:07', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:01:12', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:01:37', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:03:09', 'dd-mm-yyyy hh24:mi:ss'), 5101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:04:14', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:04:35', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:05:32', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:06:13', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:06:29', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:07:22', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:08:49', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:09:23', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:09:56', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:12:46', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:12:51', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:13:17', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:19:11', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:19:50', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:22:47', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:27:45', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:28:51', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:29:09', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:29:11', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:29:15', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:29:27', 'dd-mm-yyyy hh24:mi:ss'), 5102);
commit;
prompt 2500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:29:59', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:31:24', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:34:32', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:36:11', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:37:42', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:41:18', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:41:59', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:42:47', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:43:47', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:44:02', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:44:07', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:47:59', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:48:06', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:48:08', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:49:55', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:53:00', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 10:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:01:53', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:03:17', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:06:33', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:06:40', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:07:18', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:07:52', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:08:16', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:08:20', 'dd-mm-yyyy hh24:mi:ss'), 5102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:11:48', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:14:35', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:14:40', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:14:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:16:39', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:18:54', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:19:48', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:20:21', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:20:29', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:21:43', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:23:40', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:23:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:25:36', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:29:07', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:30:03', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:30:50', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:33:31', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:37:07', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:37:15', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:45:04', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:45:52', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:50:47', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:50:56', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:51:06', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:51:16', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:51:25', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:54:21', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:57:34', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:57:46', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:58:23', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 11:58:55', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:00:55', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:01:21', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:02:41', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:04:39', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:05:15', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:06:12', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:07:52', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:08:31', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:08:54', 'dd-mm-yyyy hh24:mi:ss'), 5103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:09:09', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:11:29', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:11:43', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:13:39', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:14:30', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:15:42', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:20:06', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:20:14', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:25:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:27:12', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:27:23', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:27:33', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:12', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:29', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:33', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:44', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:54', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:29:56', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:39:56', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 12:41:58', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 13:07:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 13:37:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:00:36', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:00:51', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:00:53', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:01:25', 'dd-mm-yyyy hh24:mi:ss'), 5104);
commit;
prompt 2600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:02:21', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:02:42', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:02:49', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:04:00', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:05:02', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:07:33', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:08:24', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:08:52', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:09:01', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:09:10', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:10:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:11:09', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:11:36', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:11:58', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:12:53', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:14:39', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:14:46', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:15:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:15:11', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:15:14', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:15:26', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:17:58', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:18:05', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:18:10', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:18:36', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:21:40', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:25:43', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:26:23', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:29:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:29:22', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:29:51', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:30:14', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:30:30', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:31:08', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:32:05', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:32:15', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:34:07', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:34:11', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:34:38', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:37:59', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:38:11', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:38:26', 'dd-mm-yyyy hh24:mi:ss'), 5104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:39:16', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:39:41', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:40:23', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:42:45', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:44:37', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:44:54', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:45:37', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:46:00', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:47:24', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:47:47', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:48:05', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:51:12', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:52:47', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:56:44', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:58:35', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 14:59:40', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:00:32', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:03:58', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:04:08', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:04:19', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:04:54', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:07:51', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:09:31', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:11:50', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:12:09', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:13:01', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:14:35', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:23:19', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:23:50', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:33:50', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:35:54', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:46:22', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:46:29', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:46:31', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:46:39', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:46:56', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:47:02', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:47:25', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:48:00', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:50:49', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:56:00', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:56:05', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 15:59:36', 'dd-mm-yyyy hh24:mi:ss'), 5105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:00:44', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:07:12', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:10:15', 'dd-mm-yyyy hh24:mi:ss'), 5106);
commit;
prompt 2700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:10:47', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:14:04', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:14:43', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:26:44', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:51:53', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:53:10', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:53:39', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:53:52', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:53:57', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:53:59', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:58:49', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 16:58:53', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:00:40', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:00:44', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:05:46', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:06:09', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:06:11', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:06:45', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:06:47', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:08:10', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:08:13', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:08:15', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:08:42', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:10:00', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:10:02', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:10:04', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:12:47', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:15:29', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:16:37', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:17:01', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:21:12', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:21:31', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:23:04', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:23:14', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:23:28', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:24:25', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:24:34', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:25:15', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:25:51', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:27:00', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:28:53', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:29:20', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:30:30', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:33:44', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:33:53', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:34:10', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:34:30', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:37:07', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:41:39', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:42:17', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:43:13', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:43:18', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:43:51', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:43:55', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:44:12', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:44:34', 'dd-mm-yyyy hh24:mi:ss'), 5106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:45:35', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:45:40', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:46:04', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:46:14', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:46:50', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:48:07', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:49:04', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 17:56:07', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:00:31', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:00:33', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:00:35', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:02:09', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:02:55', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:03:52', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:04:09', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:04:18', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:04:41', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:04:57', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:01', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:06', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:09', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:12', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:27', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:05:30', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:06:14', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:06:19', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:13:49', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:14:14', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:15:49', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:15:57', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:16:42', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:17:26', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:18:39', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:19:37', 'dd-mm-yyyy hh24:mi:ss'), 5107);
commit;
prompt 2800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:20:15', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:20:23', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:20:53', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:21:21', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:22:13', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:22:18', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:23:11', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:24:17', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:24:23', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:25:07', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:25:45', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:28:17', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:29:33', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:29:53', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:30:26', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:31:13', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:31:28', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:37:51', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:38:18', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:43:10', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:44:00', 'dd-mm-yyyy hh24:mi:ss'), 5107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:45:31', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:47:56', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:48:18', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:49:09', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:51:19', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:55:03', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:59:17', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:59:24', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:59:26', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 18:59:45', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:08:48', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:10:48', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:19:56', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:20:29', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:23:10', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:23:19', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:29:15', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:29:52', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:30:09', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:30:25', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:31:07', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:32:11', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:32:45', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:34:17', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:34:25', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:35:09', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:35:15', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:35:38', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:36:14', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:36:47', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:37:07', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:37:18', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:37:53', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:38:38', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:38:54', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:39:22', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:41:53', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:43:01', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:44:01', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:45:56', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:47:57', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:48:05', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:48:17', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:48:27', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:48:33', 'dd-mm-yyyy hh24:mi:ss'), 5108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:51:52', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:52:34', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:52:51', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:53:12', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:53:17', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 19:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:01:02', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:08:01', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:09:26', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:09:41', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:12:26', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:13:02', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:13:20', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:13:36', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:13:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:15:57', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:18:29', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:34:28', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:44:41', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:44:49', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:48:23', 'dd-mm-yyyy hh24:mi:ss'), 5109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:51:26', 'dd-mm-yyyy hh24:mi:ss'), 5109);
commit;
prompt 2900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:52:53', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:53:06', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 20:55:58', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:00:00', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:01:04', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:01:18', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:01:41', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:02:00', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:08:04', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:08:10', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:08:28', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:08:31', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:09:49', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:10:26', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:11:41', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:24:31', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:30:19', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:30:26', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:30:28', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:33:17', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:33:56', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:34:53', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:39:49', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:39:53', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:45:11', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:45:17', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 21:56:19', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 22:00:48', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 22:10:48', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 22:12:50', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 22:38:00', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:08:00', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:16:46', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:16:53', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:16:55', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:18:04', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:18:06', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:18:29', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:21:40', 'dd-mm-yyyy hh24:mi:ss'), 5110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:27:21', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:27:52', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:29:43', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:30:14', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:30:25', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:34:14', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:35:32', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:37:01', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:37:40', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:38:12', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:39:00', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:39:53', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:41:01', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:41:17', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:42:10', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:48:18', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:48:43', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:49:12', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:49:58', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:51:13', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:51:27', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('14-09-2021 23:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:46:57', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:56:57', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 21:58:58', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:24:07', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:50:05', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:50:19', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:50:21', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 22:55:26', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:05:26', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:10:38', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:20:38', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 23:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
commit;
prompt 3000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 00:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:24:16', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:32:25', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:32:33', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:32:35', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:39:37', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:49:37', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:51:37', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:51:44', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:51:46', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 01:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:09:02', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:19:02', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:21:34', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 02:46:43', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 03:16:44', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 03:46:44', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 04:16:45', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 04:46:45', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 05:16:46', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 05:46:46', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 06:16:46', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 06:46:47', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:10:13', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:10:43', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:10:56', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:11:01', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:11:03', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:15:32', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:25:32', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:26:25', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:26:49', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:26:51', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:27:16', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:27:18', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:28:53', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:28:56', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:28:58', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:29:18', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:29:32', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:29:40', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:29:42', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 07:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 08:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:09:04', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:11:51', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:11:58', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:12:00', 'dd-mm-yyyy hh24:mi:ss'), 5927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:19:39', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 09:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:37:36', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:47:36', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 10:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:05:03', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:50:33', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 11:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
commit;
prompt 3100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:42:37', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 12:50:10', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 13:00:10', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 13:02:12', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 13:27:22', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 13:57:22', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:02:17', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:02:35', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:02:37', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:23:27', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:26:00', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:26:32', 'dd-mm-yyyy hh24:mi:ss'), 5931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:29:55', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 14:55:11', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:05:11', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:31:08', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 15:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:06:47', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:11:21', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:21:21', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:28:25', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:38:25', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:40:26', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:45:30', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:46:00', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:46:17', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:46:21', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:46:23', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 16:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:00:25', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:02:59', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:03:01', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:03:25', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:03:27', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:04:48', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:04:51', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:04:53', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:05:24', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:05:47', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:06:12', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:06:14', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 17:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5935);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 18:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5936);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 19:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('14-09-2021 20:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 00:07:53', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 00:37:54', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:07:54', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:37:55', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:56:41', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:56:50', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:56:52', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:57:08', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 01:57:21', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 02:07:21', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 02:09:23', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 02:34:33', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 03:03:34', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 03:03:46', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 03:13:46', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 03:38:55', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 04:08:56', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 04:38:56', 'dd-mm-yyyy hh24:mi:ss'), 3108);
commit;
prompt 3200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 05:08:57', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 05:38:57', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:08:57', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:37:18', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:37:38', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:37:39', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:38:58', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:39:16', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:39:20', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:39:22', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:39:41', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:49:41', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 06:51:43', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:16:52', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:25:47', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:25:57', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:37:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:39:42', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:52:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:53:00', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:53:37', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:53:39', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:55:09', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:55:12', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:55:14', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:55:46', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:55:56', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:56:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:56:09', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 07:57:07', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:03:19', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:03:34', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:04:43', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:06:34', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:09:40', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:12:06', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:12:09', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:20:14', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:28:42', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:29:41', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:30:11', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:32:15', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:42:15', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:44:16', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:52:53', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:53:02', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:53:04', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 08:56:53', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:06:53', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:08:57', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:28:21', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:28:32', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:28:34', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:29:35', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:33:15', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:34:40', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:34:58', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:41:34', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:46:29', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:50:59', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:51:15', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:51:17', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:53:48', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:59:01', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:59:14', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 09:59:16', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:02:23', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:05:42', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:06:57', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:07:18', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:11:27', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:21:27', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:23:28', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:31:26', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:31:46', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:31:48', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:32:34', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:34:18', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:37:19', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:37:26', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:37:49', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:38:33', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:39:06', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:40:45', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:41:58', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:43:03', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:43:20', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:43:41', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:44:27', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:45:31', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:45:52', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:52:29', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:53:15', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:55:35', 'dd-mm-yyyy hh24:mi:ss'), 3110);
commit;
prompt 3300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:56:29', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:56:42', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:57:07', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 10:57:15', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:00:16', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:00:47', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:01:19', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:03:05', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:04:06', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:04:37', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:04:59', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:05:44', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:07:31', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:08:04', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:09:44', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:10:14', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:11:51', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:12:07', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:12:15', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:12:52', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:13:16', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:15:12', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:15:29', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:15:49', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:17:15', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:17:22', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:18:20', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:19:13', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:21:24', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:36:27', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:36:35', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:36:37', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:42:34', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:42:56', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:43:05', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:48:14', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:48:50', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:56:14', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:57:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 11:57:23', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:01:20', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:01:24', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:02:24', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:03:19', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:04:16', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:04:24', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:05:39', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:08:37', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:08:51', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:10:11', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:12:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:16:20', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:19:57', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:20:15', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:20:16', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:20:24', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:20:26', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:20:42', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:25:55', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:26:05', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:26:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:29:34', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:34:52', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:37:37', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:37:58', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:40:02', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:43:16', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:44:27', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:46:31', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:47:06', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:47:57', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:48:17', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:48:47', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:49:14', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:49:36', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 12:59:36', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 13:01:39', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 13:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 13:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:07:08', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:07:31', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:07:33', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:10:45', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:12:06', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:12:31', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:14:34', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:15:37', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:15:49', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:17:04', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:18:04', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:18:33', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:20:42', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:22:26', 'dd-mm-yyyy hh24:mi:ss'), 3112);
commit;
prompt 3400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:23:53', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:25:09', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:25:27', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:27:06', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:32:54', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:35:03', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:36:38', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:37:17', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:42:07', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:46:59', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:48:51', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:56:52', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:57:07', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 14:57:50', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:07:50', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:09:52', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:12:28', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:12:38', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:12:40', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:12:42', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:15:18', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:16:19', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:16:36', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:17:16', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:17:30', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:18:17', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:18:30', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:18:57', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:19:19', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:20:23', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:20:48', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:21:08', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:24:19', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:27:14', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:27:35', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:30:53', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:32:56', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:33:17', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:34:22', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:34:39', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:34:46', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:34:58', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:35:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:37:13', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:37:29', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:38:26', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:38:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:38:42', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:40:40', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:41:15', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:42:06', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:42:23', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:42:39', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:43:13', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:43:26', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:43:50', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:44:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:45:17', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:46:44', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:47:09', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:47:19', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:48:41', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:49:24', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:50:02', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:50:27', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:50:45', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:51:00', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:52:35', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:56:45', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:57:08', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:57:48', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:58:06', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 15:59:17', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:00:04', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:00:53', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:02:25', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:03:36', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:03:50', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:03:57', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:05:11', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:05:35', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:05:49', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:06:22', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:06:36', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:07:03', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:07:19', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:07:44', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:07:59', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:08:48', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:18:48', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:20:50', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:45:59', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:53:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:54:13', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:54:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:54:38', 'dd-mm-yyyy hh24:mi:ss'), 3113);
commit;
prompt 3500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:54:40', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 16:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:07:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:08:52', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:09:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:19:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:20:53', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:21:17', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:21:19', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:22:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:22:08', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:23:37', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:23:41', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:23:43', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:24:11', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:24:25', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:24:35', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:24:37', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:26:59', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:36:59', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 17:39:00', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 18:04:09', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 18:34:10', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:02:52', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:03:23', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:03:25', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:06:28', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:07:14', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:09:11', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:09:49', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:11:07', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:11:28', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:12:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:13:09', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:17:59', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:21:21', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:23:26', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:25:05', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:26:12', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:27:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:27:10', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:27:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:28:57', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:29:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:31:23', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:32:48', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:34:04', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:34:50', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:35:34', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:35:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:36:30', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:37:46', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:39:08', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:42:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:49:00', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:49:20', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:51:08', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:52:57', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:54:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:54:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 19:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:00:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:10:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:12:09', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:37:19', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:44:40', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:44:48', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:44:50', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:45:57', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:46:51', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:47:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:47:32', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:49:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:50:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:51:19', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:52:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:53:55', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:55:17', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:56:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 20:58:34', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:00:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:01:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:03:03', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:03:57', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:04:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:05:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:06:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:07:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:08:49', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:09:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:19:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:21:15', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 21:46:24', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:16:25', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:28:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:28:35', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:28:37', 'dd-mm-yyyy hh24:mi:ss'), 3115);
commit;
prompt 3600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:29:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:30:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:30:48', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:31:30', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:31:52', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:32:35', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:33:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:34:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:36:05', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:37:57', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:40:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:42:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:43:34', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:47:39', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:50:01', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:51:09', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:54:29', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:56:06', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:57:07', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:58:12', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 22:59:16', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:00:26', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:03:41', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:04:20', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:08:35', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:08:58', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:09:59', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:11:44', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:12:06', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:13:40', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:17:19', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:20:46', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:21:55', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:23:22', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:24:00', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:24:26', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:25:07', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:25:22', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:26:12', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:27:05', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:38:30', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:40:21', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:44:57', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:49:04', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:53:03', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('14-09-2021 23:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 00:16:44', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 00:46:44', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 01:16:45', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 01:46:45', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 02:16:46', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 02:46:46', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 03:16:47', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 03:46:47', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 04:16:48', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 04:46:48', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 05:16:48', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 05:46:49', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 06:16:49', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 06:46:50', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 07:16:50', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 07:46:51', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 08:16:51', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 08:46:52', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 09:16:52', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 09:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 10:16:53', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 10:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 11:16:54', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 11:46:54', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 12:16:55', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 12:46:55', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 13:16:56', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 13:46:56', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 14:16:57', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 14:46:57', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 15:16:58', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 15:48:54', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 16:18:54', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 16:48:55', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 17:18:55', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 17:48:56', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 18:18:56', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 18:48:56', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 19:18:57', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 19:48:57', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 20:18:58', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 20:48:58', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 21:18:59', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 21:48:59', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 22:19:00', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 22:49:00', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 23:19:00', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('14-09-2021 23:49:01', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 00:04:04', 'dd-mm-yyyy hh24:mi:ss'), 457);
commit;
prompt 3700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 00:34:05', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 01:04:05', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 01:34:06', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 02:04:06', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 02:34:06', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 03:04:07', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 03:34:07', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 04:04:08', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 04:34:08', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 05:04:09', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 05:34:09', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 06:04:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 06:34:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:04:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:21:52', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:22:53', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:23:18', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:23:23', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:23:25', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:23:27', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:33:27', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:34:18', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:34:27', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:34:29', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:35:11', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:35:30', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:37:38', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:38:48', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:40:30', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:40:38', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:40:40', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:44:01', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:47:12', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:49:40', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 07:59:40', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:00:27', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:00:36', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:00:38', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:05:11', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:05:14', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:06:38', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:06:39', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:06:49', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:06:51', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:08:32', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:08:35', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:08:37', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:09:00', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:09:18', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:09:25', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:09:27', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:14:36', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:19:07', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:19:21', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:20:11', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:20:29', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:20:34', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:21:06', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:27:00', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:27:27', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:35:11', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:35:50', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:36:10', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:37:02', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:39:17', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:48:21', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:50:11', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:52:07', 'dd-mm-yyyy hh24:mi:ss'), 458);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 08:54:24', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:02:30', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:05:26', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:05:41', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:05:43', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:05:45', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:07:07', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:07:43', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:14:23', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:20:11', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:30:11', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:35:11', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:36:22', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:40:24', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:40:29', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:40:31', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:41:37', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:43:33', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:43:40', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:43:42', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:44:31', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:50:09', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:59:04', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 09:59:35', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:09:35', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:11:39', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:32:09', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:32:15', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:32:17', 'dd-mm-yyyy hh24:mi:ss'), 459);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:35:09', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:40:25', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:50:09', 'dd-mm-yyyy hh24:mi:ss'), 460);
commit;
prompt 3800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:50:57', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:54:06', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:54:40', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:54:47', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 10:54:49', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:01:03', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:01:52', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:02:00', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:02:02', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:03:10', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:05:09', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:10:19', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:11:51', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:12:01', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:12:03', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:17:16', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:20:09', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:30:09', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:33:16', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:37:03', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:37:12', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:37:14', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:39:56', 'dd-mm-yyyy hh24:mi:ss'), 460);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:44:49', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:46:08', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:46:58', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:56:58', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 11:59:01', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:15:38', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:17:30', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:27:30', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:32:58', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:33:04', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:33:06', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:35:09', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:40:15', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:43:43', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:46:46', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:49:28', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 12:59:29', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:01:32', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:26:41', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:56:41', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:59:08', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:59:16', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:59:18', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 13:59:44', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:02:47', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:05:09', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:07:53', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:07:58', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:08:08', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:08:10', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:11:48', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:21:48', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:23:52', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:49:02', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:52:46', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 14:53:09', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:03:09', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:06:35', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:06:43', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:06:45', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:07:53', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:08:07', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:17:08', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:17:16', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:24:06', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:24:47', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:25:01', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:25:05', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:25:07', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:25:29', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:26:44', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:27:54', 'dd-mm-yyyy hh24:mi:ss'), 461);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:35:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:45:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:47:03', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:50:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:52:36', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 15:53:54', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:03:54', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:04:29', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:05:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:06:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:11:45', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:13:36', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:13:46', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:16:46', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:26:46', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:28:50', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 16:54:00', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:23:22', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:23:29', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:23:31', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:33:34', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:35:09', 'dd-mm-yyyy hh24:mi:ss'), 462);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:45:09', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:45:57', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:50:09', 'dd-mm-yyyy hh24:mi:ss'), 463);
commit;
prompt 3900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:52:36', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 17:57:03', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:03:21', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:05:09', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:14:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:24:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:26:39', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:34:15', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:34:27', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:34:29', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:35:09', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:42:33', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:44:44', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:44:51', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:44:53', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:46:14', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:56:14', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 18:58:17', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 19:23:26', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 19:53:26', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 20:23:27', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 20:53:27', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 21:23:28', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 21:53:28', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 22:23:29', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 22:53:29', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 23:23:30', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('14-09-2021 23:53:30', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:04:38', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:11:12', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:12:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:22:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:24:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:49:41', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:51:06', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:51:13', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:51:15', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:52:58', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:53:49', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:55:37', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:05:11', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:05:21', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:05:23', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:05:25', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:07:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:08:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:20:18', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 02:45:27', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 03:15:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 03:45:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 04:15:29', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 04:45:29', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 05:15:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 05:45:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 06:15:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 06:45:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:15:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:17:39', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:19:09', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:19:26', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:19:33', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:19:36', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:22:46', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:32:46', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:33:20', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:33:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:33:34', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:34:22', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:39:01', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:39:24', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:39:26', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:39:52', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:39:55', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:40:02', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:40:05', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:41:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:41:31', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:41:33', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:42:39', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:42:47', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:42:49', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:46:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:56:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 07:58:18', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 08:23:27', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 08:53:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:23:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:42:59', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:43:17', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:43:19', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:47:49', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:49:16', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:50:33', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:52:29', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:55:39', 'dd-mm-yyyy hh24:mi:ss'), 3108);
commit;
prompt 4000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:56:14', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:57:35', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 09:58:10', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:00:32', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:01:45', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:03:36', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:06:34', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:08:08', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:11:16', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:13:00', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:16:08', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:20:30', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:20:42', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:20:44', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:24:12', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:24:44', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:26:21', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:27:44', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:28:35', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:32:50', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:34:45', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:35:22', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:43:00', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:44:54', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:46:19', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:47:57', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:50:16', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:52:16', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:54:23', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 10:58:49', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:06:41', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:07:29', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:08:07', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:08:44', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:09:33', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:09:51', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:10:16', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:12:01', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:12:55', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:13:35', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:16:48', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:17:24', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:17:58', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:20:13', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:21:19', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:31:19', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:33:09', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:36:09', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:44:05', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:44:21', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:44:42', 'dd-mm-yyyy hh24:mi:ss'), 3109);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:49:12', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 11:59:12', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 12:01:14', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 12:26:23', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 12:56:23', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:21:47', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:21:55', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:21:57', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:23:47', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:24:58', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:27:31', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:28:56', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:33:05', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:44:32', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:45:06', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:45:44', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:48:58', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:52:11', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:53:54', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:58:34', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 13:59:37', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:10:08', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:13:44', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:20:55', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:21:12', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:21:16', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), 3110);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:27:18', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:28:59', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:32:40', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:42:40', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:44:41', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:47:41', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:47:47', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:47:49', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3111);
commit;
prompt 4100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:51:36', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 14:51:47', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:01:27', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:04:28', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:11:39', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:16:34', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:17:47', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:19:34', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:23:02', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:23:48', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:24:08', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:25:06', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:28:02', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:28:20', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:28:37', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:31:47', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:32:25', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:34:13', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:35:21', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:36:57', 'dd-mm-yyyy hh24:mi:ss'), 3111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:40:27', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:49:33', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:49:41', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:51:36', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 15:56:37', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:00:22', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:00:57', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:03:24', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:04:05', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:04:22', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:05:17', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:06:29', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:07:38', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:09:32', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:12:42', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:14:42', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:15:15', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:15:51', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:21:08', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:21:15', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:21:17', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:23:04', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:26:10', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:36:10', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 16:38:12', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:03:05', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:03:20', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:03:22', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:05:37', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:06:08', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:06:38', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:10:05', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:12:01', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:12:34', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:13:47', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:14:26', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:17:36', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:18:27', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:19:39', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:22:03', 'dd-mm-yyyy hh24:mi:ss'), 3112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:32:03', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:32:38', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:32:47', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:33:45', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:37:49', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:39:13', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:39:48', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:43:38', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:46:54', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:47:42', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:50:09', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:53:38', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:55:21', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 17:58:53', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:04:17', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:04:31', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:07:37', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:07:51', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:08:21', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:08:28', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:11:58', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:12:38', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:13:23', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:15:26', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:16:34', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:18:29', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:21:04', 'dd-mm-yyyy hh24:mi:ss'), 3113);
commit;
prompt 4200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:22:23', 'dd-mm-yyyy hh24:mi:ss'), 3113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:25:26', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:29:11', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:30:11', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:31:05', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:31:37', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:32:46', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:33:15', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:34:22', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:35:28', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:37:10', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:37:51', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:39:01', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:40:24', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:42:18', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:52:18', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:54:20', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:56:04', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:56:12', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:56:14', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 18:58:21', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:08:21', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:10:23', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:29:25', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:30:13', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:30:18', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:30:20', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:31:34', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:32:20', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:33:32', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:34:24', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:35:00', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:35:24', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:35:50', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:36:42', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:37:46', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:38:41', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:42:06', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:42:41', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:47:45', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:48:45', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:55:02', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 19:56:47', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:06:47', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:08:48', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:33:57', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:43:17', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:43:23', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:43:25', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:43:55', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:44:36', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:44:57', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:45:09', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:45:34', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:45:58', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:46:10', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:46:35', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:47:22', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:47:36', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:48:09', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:48:32', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:48:42', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:49:14', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:49:40', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:50:07', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:50:29', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:50:59', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:51:35', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:52:05', 'dd-mm-yyyy hh24:mi:ss'), 3114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:52:24', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:52:45', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:53:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:53:42', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:54:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:55:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:55:42', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:57:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:57:44', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:58:39', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 20:59:24', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:00:15', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:00:45', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:02:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:03:39', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:04:20', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:04:31', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:04:39', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:05:05', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:06:59', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:08:34', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:09:55', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:19:55', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:21:56', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 21:47:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:17:06', 'dd-mm-yyyy hh24:mi:ss'), 3115);
commit;
prompt 4300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:26:43', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:26:51', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:26:53', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:28:51', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:29:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:30:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:30:44', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:31:17', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:32:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:36:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:46:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 22:48:02', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 23:13:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 23:43:11', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:00:39', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:01:20', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:01:41', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:01:52', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:02:30', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:03:17', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:04:13', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:05:04', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:05:17', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:05:57', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:06:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:08:09', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:16:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:17:20', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:29:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:31:20', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:41:20', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 00:43:21', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('14-09-2021 01:04:36', 'dd-mm-yyyy hh24:mi:ss'), 3107);
commit;
prompt 4339 records loaded
set feedback on
set define on
prompt Done.
