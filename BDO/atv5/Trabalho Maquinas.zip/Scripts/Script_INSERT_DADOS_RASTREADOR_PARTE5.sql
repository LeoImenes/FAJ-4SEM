﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 00:02:38', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 00:32:38', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 01:02:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 01:32:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 02:02:40', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 02:32:40', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 03:02:41', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 03:32:41', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 04:02:42', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 04:32:42', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 05:02:42', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 05:32:43', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 06:02:43', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 06:32:44', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 07:02:44', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 07:32:45', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 08:02:45', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 08:32:46', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 09:02:46', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 09:32:47', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 10:02:47', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 10:32:47', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 11:02:48', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 11:32:48', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 12:02:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 12:32:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 13:02:50', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 13:32:50', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 14:02:51', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 14:32:51', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 15:02:52', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 15:32:52', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 16:02:52', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 16:32:53', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 17:02:53', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 17:32:54', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 18:02:54', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 18:32:55', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 19:02:55', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 19:32:56', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 20:02:56', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 20:32:56', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 21:02:57', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 21:32:57', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 22:02:58', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 22:32:58', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 23:02:59', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('17-09-2021 23:32:59', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 00:09:05', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 00:39:05', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 01:09:06', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 01:39:06', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 02:09:07', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 02:39:07', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 03:09:08', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 03:39:08', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 04:09:08', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 04:39:09', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 05:09:09', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 05:39:10', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 06:09:10', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 06:39:11', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:09:11', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:32:19', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:33:02', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:33:19', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:33:23', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:33:25', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:37:25', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:47:25', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:47:34', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:51:44', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:55:06', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:55:16', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:55:18', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 07:58:13', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:01:55', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:02:02', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:02:04', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:02:35', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:09:42', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:12:32', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:12:41', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:12:43', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:07', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:11', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:20', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:22', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:29', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:13:31', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:17:35', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:22:57', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:31:49', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:43:51', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:53:36', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:53:43', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:53:45', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 08:55:18', 'dd-mm-yyyy hh24:mi:ss'), 1318);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:04:10', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:04:28', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:04:30', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:07:22', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:10:55', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:20:55', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:22:56', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 09:48:05', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:18:05', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:48:06', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:56:52', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:57:04', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:57:06', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:57:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:58:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 10:58:55', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:01:19', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:02:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:08:24', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:08:51', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:16:45', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:17:01', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:17:03', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:17:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:22:14', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:32:14', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:34:17', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 11:59:27', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 12:29:27', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 12:59:27', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:09:38', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:09:59', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:10:01', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:13:01', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:23:01', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:25:03', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:50:12', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:57:59', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:58:11', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 13:58:13', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:02:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:12:35', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:14:10', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:23:18', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:23:26', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:23:28', 'dd-mm-yyyy hh24:mi:ss'), 1318);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:32:23', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:32:35', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:40:31', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:50:31', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 14:52:33', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:12:06', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:12:38', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:12:40', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:17:36', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:27:36', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:30:49', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:31:54', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:32:35', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:42:35', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:47:35', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 15:53:51', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 16:03:51', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 16:05:53', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 16:31:03', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 17:01:03', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 17:31:04', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 18:01:04', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 18:31:05', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 19:01:05', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 19:31:06', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 20:01:06', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 20:31:07', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 21:01:07', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 21:31:07', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 22:01:08', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 22:31:08', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 23:01:09', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('17-09-2021 23:31:09', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 00:04:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 00:34:33', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 01:04:33', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 01:34:34', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 02:04:34', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 02:34:34', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 03:04:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 03:34:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 04:04:36', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 04:34:36', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 05:04:37', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 05:34:37', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 06:04:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 06:34:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:04:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:31:06', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:31:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:32:04', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:32:09', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:32:11', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:34:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:44:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 07:46:10', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:11:19', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:13:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:13:39', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:13:41', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:14:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:24:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:26:20', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 08:51:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:21:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:46:19', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:46:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:46:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:46:33', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:49:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 09:59:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 10:01:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 10:26:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 10:56:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 11:26:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:37:46', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:37:56', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:37:58', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:41:04', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:51:04', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 12:53:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 13:18:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 13:48:17', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 14:18:17', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 14:48:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 15:18:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 15:48:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:07:40', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:08:13', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:08:36', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:08:41', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:08:43', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:09:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:19:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:21:21', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 16:46:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 17:16:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 17:46:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 18:16:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 18:46:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 19:16:33', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 19:46:33', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 20:16:34', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 20:46:34', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 21:16:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 21:46:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 22:16:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 22:46:36', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 23:16:36', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('17-09-2021 23:46:37', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:21:46', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:44:55', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:46:11', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:46:45', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:46:50', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:46:52', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 00:55:34', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 01:05:34', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 01:07:36', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 01:32:46', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 02:02:46', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 02:32:47', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 03:02:47', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 03:32:48', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 04:02:48', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 04:32:49', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 05:02:49', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 05:32:49', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 06:02:50', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 06:32:50', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:02:51', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:32:39', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:33:57', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:34:32', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:34:37', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:34:39', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:40:01', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:41:39', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:42:06', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:42:08', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:42:38', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:42:41', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:43:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:44:10', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:44:13', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:44:15', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:44:39', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:49:21', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:49:37', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:49:39', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 07:54:20', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 08:05:00', 'dd-mm-yyyy hh24:mi:ss'), 944);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 08:06:22', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 08:31:32', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 09:01:32', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 09:31:33', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:01:33', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:31:33', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:41:58', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:42:04', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:42:06', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:43:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:46:33', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 10:52:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:02:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:04:20', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:09:03', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:09:15', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:09:17', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:13:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:15:13', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:25:13', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:27:15', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:37:48', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:37:56', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:37:58', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:43:18', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:48:34', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:58:11', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:58:20', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:58:27', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:58:29', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 11:58:31', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:08:31', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:08:57', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:18:57', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:19:13', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:19:29', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:19:31', 'dd-mm-yyyy hh24:mi:ss'), 944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:28:18', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:30:00', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:32:35', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:35:34', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:35:42', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:35:44', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:38:37', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:48:37', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 12:50:39', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 13:15:49', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 13:45:49', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:11:34', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:11:41', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:11:43', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:13:18', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:17:04', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:27:04', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:28:18', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:28:28', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:28:58', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:29:06', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:29:08', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:36:19', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:39:41', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:49:41', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:51:43', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:53:17', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:53:26', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:53:28', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 14:58:18', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:05:26', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:09:22', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:09:58', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:10:00', 'dd-mm-yyyy hh24:mi:ss'), 945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:13:18', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:16:42', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:26:42', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:28:43', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:32:09', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:32:24', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:32:26', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:42:26', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:43:18', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:53:04', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 15:58:18', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:08:18', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:13:17', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:23:18', 'dd-mm-yyyy hh24:mi:ss'), 946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:28:18', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:29:33', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:30:26', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:38:02', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:39:28', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:40:19', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:40:23', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:40:25', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:43:18', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:48:42', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 16:58:42', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 17:00:44', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 17:25:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 17:55:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 18:25:54', 'dd-mm-yyyy hh24:mi:ss'), 947);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 18:55:55', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 19:25:55', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 19:55:56', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 20:25:56', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 20:55:57', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 21:25:57', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 21:55:58', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 22:25:58', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 22:55:58', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:25:59', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:27:42', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:29:08', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:30:13', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:30:17', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:30:19', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:38:15', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:48:15', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('17-09-2021 23:50:17', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 00:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 00:30:25', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 01:00:25', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 01:30:26', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 02:00:26', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 02:30:27', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 03:00:27', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 03:30:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 04:00:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 04:30:29', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 05:00:29', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 05:30:30', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 06:00:30', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 06:30:31', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:00:31', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:30:32', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:42:15', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:43:29', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:43:57', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:44:01', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:44:03', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:46:31', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:52:41', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:53:03', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:53:05', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:53:35', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:53:37', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:54:58', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:55:02', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:55:04', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:55:39', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:59:45', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:59:55', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 07:59:57', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:09:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:19:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:21:31', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:41:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:41:35', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:41:37', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:49:54', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 08:59:54', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:01:55', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:03:15', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:03:21', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:03:23', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:09:00', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:10:03', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:10:10', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:10:12', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:11:17', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:12:58', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:13:05', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:13:07', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:17:58', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:20:12', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:20:18', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:20:20', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:20:22', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:30:22', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:35:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:45:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 09:50:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:00:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:09:35', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:15:23', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:15:29', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:15:31', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:20:06', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:30:06', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:35:06', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:42:22', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:43:31', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:43:37', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:43:39', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:45:46', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:55:46', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 10:57:49', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 11:22:59', 'dd-mm-yyyy hh24:mi:ss'), 2048);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 11:52:59', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 12:23:00', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 12:53:00', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:23:01', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:44:41', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:44:47', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:44:49', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:50:06', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 13:52:17', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:02:17', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:03:02', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:03:09', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:03:11', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:13:01', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:19:05', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:19:34', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:19:36', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:26:41', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:36:41', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:38:17', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:38:23', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:38:25', 'dd-mm-yyyy hh24:mi:ss'), 2048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:48:27', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:50:06', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 14:51:55', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:01:45', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:01:51', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:01:53', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:04:27', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:06:13', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:06:19', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:06:21', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:16:21', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:20:05', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:30:05', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:35:06', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:45:06', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 15:50:06', 'dd-mm-yyyy hh24:mi:ss'), 2049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:00:06', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:13:28', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:23:28', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:25:30', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 16:50:40', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 17:20:40', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 17:50:41', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 18:20:41', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 18:50:41', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 19:20:42', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 19:50:42', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 20:20:43', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 20:50:43', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 21:20:44', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 21:50:44', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 22:20:44', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 22:50:45', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 23:20:45', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('17-09-2021 23:50:46', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 00:28:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 00:58:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:28:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:31:07', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:31:09', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:31:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:31:55', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:32:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:32:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:33:06', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:41:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:51:34', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 01:53:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 02:18:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 02:48:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 03:18:43', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 03:48:43', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 04:18:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 04:48:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:18:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:48:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:53:18', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:53:20', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:53:32', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:53:34', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 05:57:48', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 06:07:48', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 06:09:50', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 06:34:59', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 07:05:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 07:35:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 08:05:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 08:35:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 09:05:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 09:35:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:05:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:07:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:07:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:08:38', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:09:07', 'dd-mm-yyyy hh24:mi:ss'), 1427);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:09:11', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:09:13', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:11:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:16:32', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:18:06', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:23:54', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:24:29', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:34:29', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 10:36:31', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 11:01:40', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 11:31:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 12:01:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 12:31:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 13:01:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 13:31:42', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 14:01:43', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 14:31:43', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 15:01:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 15:31:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 16:01:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 16:31:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:01:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:09:47', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:10:17', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:10:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:10:37', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:10:39', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:15:08', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:17:16', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:17:18', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:17:43', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:17:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:18:06', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:18:31', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:18:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:19:50', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:19:54', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:19:56', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:21:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:21:14', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:21:16', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:21:23', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:21:25', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:27:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:37:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 17:39:35', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:04:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:34:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:49:29', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:49:48', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:49:53', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:49:55', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 18:58:58', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:03:06', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:07:54', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:09:08', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:19:08', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:21:10', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 19:46:19', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 20:16:20', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 20:46:20', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 21:16:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 21:46:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 22:16:22', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 22:46:22', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:05:12', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:05:51', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:06:14', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:06:19', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:06:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:16:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:18:06', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:22:56', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:32:56', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('17-09-2021 23:34:58', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 00:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:12:16', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:22:16', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:24:18', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 01:49:27', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 02:19:28', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 02:49:28', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 03:19:29', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 03:49:29', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 04:19:29', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 04:49:30', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 05:19:30', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 05:49:31', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 06:19:31', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 06:49:32', 'dd-mm-yyyy hh24:mi:ss'), 5036);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:19:32', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:29:38', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:30:33', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:30:57', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:31:01', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:31:03', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:35:51', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:38:35', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:38:58', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:39:00', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:39:17', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:39:21', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:39:29', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:39:31', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:40:50', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:40:54', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:40:56', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:41:15', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:41:39', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:41:47', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:41:49', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 07:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 08:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:07:37', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 09:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:02:40', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:10:12', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:10:21', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:10:23', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:31:19', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:42:16', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:44:46', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:52:37', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 10:52:39', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:04:49', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:06:37', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:06:45', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:06:47', 'dd-mm-yyyy hh24:mi:ss'), 5039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:32:41', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:42:41', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 11:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:00:45', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:06:15', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:06:22', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:06:24', 'dd-mm-yyyy hh24:mi:ss'), 5040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:16:26', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:18:32', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:24:55', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:31:32', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:31:39', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:31:41', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:31:43', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:41:43', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:53:25', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 12:57:09', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 13:07:09', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 13:09:11', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 13:34:21', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:02:35', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:02:42', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:02:44', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:07:22', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:32:42', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:42:42', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:45:17', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 14:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5042);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:14:11', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:17:58', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:18:04', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:18:06', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:27:30', 'dd-mm-yyyy hh24:mi:ss'), 5042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 15:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:11:38', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:15:57', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:25:57', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:27:59', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:53:08', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:54:54', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:55:22', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:55:35', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:55:39', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 16:55:41', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:08:13', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:10:27', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:10:52', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:10:54', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:11:12', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:11:14', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:12:24', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:12:27', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:12:42', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:13:11', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:13:28', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:13:30', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:18:58', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:28:58', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 17:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:28:22', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:30:47', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:30:57', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:30:59', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 18:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:03:53', 'dd-mm-yyyy hh24:mi:ss'), 5045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:13:53', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:46:53', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:56:53', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 19:58:54', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:04:23', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:04:38', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:04:40', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:14:40', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:17:20', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:25:14', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:25:21', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:25:23', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:41:25', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:51:16', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:51:32', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 20:51:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:02:43', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:12:43', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:13:23', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:29:51', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:30:00', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:40:00', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 21:42:02', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:07:11', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:37:12', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:43:21', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:43:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:43:36', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 22:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:09:56', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('17-09-2021 23:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 00:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 00:08:17', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 00:18:17', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 00:20:19', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 00:45:29', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 01:15:29', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 01:45:30', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 02:15:30', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 02:45:31', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 03:15:31', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 03:45:31', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 04:15:32', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 04:45:32', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 05:15:33', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 05:45:33', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 06:15:34', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 06:45:34', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:15:35', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:35:15', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:36:12', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:36:35', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:36:39', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:36:41', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:41:50', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:51:50', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 07:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:31:25', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:41:25', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:41:47', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:41:54', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:41:56', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:41:58', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:51:58', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 08:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:06:55', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:14:36', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:14:45', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:14:47', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:44:39', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:54:39', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 09:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:50:38', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:55:35', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:55:45', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:55:47', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:44:27', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:50:44', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:51:15', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:51:17', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 11:56:50', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:06:50', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:40:43', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:50:43', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 12:52:45', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 13:17:55', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 13:47:55', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:17:55', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:18:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:23:43', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:23:45', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:23:53', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 14:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 16:08:41', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 16:18:41', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 16:20:43', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 16:45:53', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 17:15:53', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 17:45:54', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 18:15:54', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 18:45:54', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 19:15:55', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 19:45:55', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 20:15:56', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 20:45:56', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:15:57', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:22:44', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:23:07', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:23:52', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:26:21', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:26:39', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:26:42', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:07', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:11', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:53', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:27:55', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:28:26', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:37:30', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:37:49', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:40:08', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 21:50:08', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 22:15:18', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 22:45:18', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 23:15:19', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('17-09-2021 23:45:19', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:03:24', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:10:59', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:26:54', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:30:15', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:40:15', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:41:54', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:45:22', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:54:46', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 00:59:15', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:00:47', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:02:21', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:04:03', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:08:35', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:12:55', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:13:26', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:15:36', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:16:31', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:17:11', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:18:32', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:26:54', 'dd-mm-yyyy hh24:mi:ss'), 4906);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:28:51', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:38:51', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:41:54', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:43:12', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:44:54', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:44:57', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:52:21', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 01:59:03', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:00:59', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:07:12', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:09:53', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:10:06', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:12:47', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:13:20', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:13:36', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:13:41', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:13:43', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:13:59', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:23:59', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:26:04', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:26:31', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:26:54', 'dd-mm-yyyy hh24:mi:ss'), 4907);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:36:54', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:41:53', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:49:50', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:56:53', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 02:57:49', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:01:00', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:08:21', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:08:40', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:08:44', 'dd-mm-yyyy hh24:mi:ss'), 4908);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:15:13', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:18:03', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:26:53', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:29:45', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:30:12', 'dd-mm-yyyy hh24:mi:ss'), 4908);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:32:30', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:34:59', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:36:49', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:39:54', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:41:53', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:51:53', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:55:03', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:55:50', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 03:56:53', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 04:03:13', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 04:13:13', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 04:15:15', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 04:40:25', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 05:10:25', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 05:40:26', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 06:10:26', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 06:40:26', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:10:27', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:40:27', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:44:01', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:45:25', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:45:41', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:45:45', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:45:47', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:47:52', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:49:23', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:55:59', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:56:27', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:56:29', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:57:02', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:57:13', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:58:52', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:58:56', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:58:58', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 07:59:24', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:01:19', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:01:33', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:01:35', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:09:51', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4909);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:21:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:33:11', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:43:29', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:53:29', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 08:55:31', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:14:38', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:14:50', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:14:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:24:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:36:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:41:18', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:48:11', 'dd-mm-yyyy hh24:mi:ss'), 4910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 09:57:56', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:07:56', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:21:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:34:24', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:45:42', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:53:24', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:53:32', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:53:34', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:55:48', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 10:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:06:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:11:35', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:21:47', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:36:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:51:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 11:58:55', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:08:55', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:20:40', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:30:40', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:32:41', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:33:05', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:33:36', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:33:51', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:33:55', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:33:57', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:34:29', 'dd-mm-yyyy hh24:mi:ss'), 4913);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:46:04', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:56:04', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 12:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:04:48', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:07:45', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:17:45', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:19:47', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:28:00', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:28:34', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:28:47', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:28:51', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:28:53', 'dd-mm-yyyy hh24:mi:ss'), 4913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:34:07', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:37:31', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:49:52', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:58:36', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:58:46', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 13:58:48', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:08:48', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:11:01', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:15:15', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:17:27', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:17:35', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:17:37', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:35:29', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:37:07', 'dd-mm-yyyy hh24:mi:ss'), 4914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:51:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 14:58:10', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:07:35', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:07:44', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:07:46', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:08:46', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:18:07', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:19:36', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:23:18', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:26:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:36:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:41:52', 'dd-mm-yyyy hh24:mi:ss'), 4915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:51:15', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:55:24', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 15:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:06:52', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:06:54', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:10:00', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:10:18', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:10:20', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:17:14', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:27:14', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:29:16', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 16:54:26', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:24:26', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:44:22', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:44:59', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:45:21', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:45:26', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:45:28', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:45:58', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:55:06', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 17:56:52', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:02:17', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:10:43', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:14:11', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:19:03', 'dd-mm-yyyy hh24:mi:ss'), 4916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:19:39', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:19:55', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:21:11', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:23:48', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:30:24', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:38:40', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:45:41', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:50:12', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:50:48', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:53:29', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:54:21', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:56:38', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 18:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:00:43', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:02:37', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:02:47', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:02:49', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:12:32', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:22:32', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:23:40', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:23:52', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:23:54', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:25:39', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4917);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:30:04', 'dd-mm-yyyy hh24:mi:ss'), 4917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:40:04', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:44:21', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:45:05', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:45:12', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:45:14', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:55:14', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:55:18', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 19:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:06:51', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:22:12', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:23:33', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:24:09', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:24:44', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:24:46', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:25:31', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:25:53', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:25:57', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:25:59', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:28:27', 'dd-mm-yyyy hh24:mi:ss'), 4918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:38:27', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:51:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 20:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:00:29', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:10:29', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:21:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:34:08', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:51:51', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:52:43', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 21:57:01', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:00:53', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:03:11', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:03:31', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:03:36', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:03:38', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:05:52', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:13:18', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:23:18', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:23:25', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:25:07', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:26:31', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:36:51', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:46:40', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:56:28', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:56:39', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 22:59:52', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:02:14', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:16:58', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:17:01', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:17:05', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:17:14', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:17:19', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:19:56', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:20:04', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:20:06', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:21:01', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:22:18', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:29:24', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:40:01', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:41:14', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:41:46', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:51:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:52:21', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('17-09-2021 23:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 00:20:34', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 00:50:34', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 01:20:35', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 01:50:35', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:20:36', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:50:36', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:54:15', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:55:53', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:56:39', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:56:43', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 02:56:45', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:15:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:20:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:34:02', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:45:21', 'dd-mm-yyyy hh24:mi:ss'), 2093);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:50:21', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 03:55:53', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 04:05:53', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 04:07:55', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 04:33:05', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 05:03:05', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 05:33:06', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:03:06', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:29:57', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:30:19', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:32:37', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:35:26', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:35:44', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:45:44', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:47:38', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:50:00', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 06:50:06', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:00:06', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:25:15', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:32:05', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:39:52', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:40:06', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:40:11', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:40:13', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:40:15', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:40:57', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:41:43', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:41:53', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:41:55', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:49:49', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:50:21', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:50:33', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:50:35', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:51:52', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:51:56', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:51:58', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:52:25', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:52:36', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:52:54', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 07:52:56', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:02:56', 'dd-mm-yyyy hh24:mi:ss'), 2093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:07:43', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:16:43', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:20:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:34:24', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:34:36', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:34:45', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:34:47', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:43:18', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:53:18', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 08:55:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 09:20:31', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 09:50:31', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:20:31', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:34:12', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:34:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:34:23', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:41:07', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:51:07', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 10:53:08', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:03:49', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:04:01', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:04:03', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:15:21', 'dd-mm-yyyy hh24:mi:ss'), 2094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:19:54', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:29:54', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:31:56', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:32:03', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:32:05', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:45:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:46:38', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:56:38', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 11:58:41', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 12:23:51', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 12:53:51', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:16:37', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:16:45', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:16:47', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:17:33', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:19:18', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:29:18', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:31:20', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 13:56:29', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 14:26:30', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 14:56:30', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 15:26:31', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 15:56:31', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 16:26:31', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 16:56:32', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:26:32', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:28:38', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:29:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:29:40', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:29:45', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:29:47', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:45:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 17:50:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:00:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:15:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:20:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:43:58', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:53:58', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 18:55:59', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 19:21:08', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 19:51:09', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 20:21:09', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 20:51:10', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 21:21:10', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 21:51:10', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 22:21:11', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 22:51:11', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 23:21:12', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('17-09-2021 23:51:12', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 00:01:14', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 00:31:15', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 01:01:15', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 01:31:16', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 02:01:16', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 02:31:17', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 03:01:17', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 03:31:18', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 04:01:18', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 04:31:18', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 05:01:19', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 05:31:19', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 06:01:20', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 06:31:20', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:01:21', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:31:21', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:33:56', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:37:30', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:43:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:43:24', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 07:53:24', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:04:55', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:05:00', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:05:02', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:05:31', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:05:34', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:06:09', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:06:17', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:08:06', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:08:22', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:08:26', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:08:28', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:14:29', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:18:23', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:30:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:33:34', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:34:58', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:35:50', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:39:04', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:48:55', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:50:12', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 08:59:12', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:02:06', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:06:28', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:15:12', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:27:33', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:35:22', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:36:03', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:36:10', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:36:12', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:36:28', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:43:40', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:43:46', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:43:48', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:46:50', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:51:56', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:52:11', 'dd-mm-yyyy hh24:mi:ss'), 2982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 09:59:16', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:05:42', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:15:42', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:30:04', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:37:09', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:47:09', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:47:47', 'dd-mm-yyyy hh24:mi:ss'), 2983);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 10:56:57', 'dd-mm-yyyy hh24:mi:ss'), 2983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:00:12', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:07:53', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:12:12', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:16:57', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:17:06', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:17:08', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:20:21', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:22:58', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:28:34', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:37:37', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:05:54', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:06:02', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:06:04', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:12:20', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:18:33', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:28:19', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:46:28', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 00:57:53', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:30:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:36:22', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:44:52', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:54:52', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:58:44', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:58:52', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 01:58:54', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4068);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:16:02', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:21:43', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:25:10', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:33:43', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:45:13', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:52:24', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:52:32', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:52:34', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 02:58:25', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:03:55', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:13:55', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:15:45', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:24:21', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:24:38', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:24:40', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:31:11', 'dd-mm-yyyy hh24:mi:ss'), 4069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:40:18', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:52:51', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 03:59:23', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:06:54', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:16:54', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:17:46', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:17:58', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:27:58', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:30:00', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:43:29', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:43:36', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:43:38', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:46:10', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:53:28', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:53:35', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 04:53:37', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:03:33', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:12:25', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:30:00', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:37:20', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:45:19', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:45:46', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:54:33', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:55:02', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:55:16', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:55:21', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 05:55:23', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:13:14', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:20:42', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:20:52', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:20:54', 'dd-mm-yyyy hh24:mi:ss'), 4071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:20:55', 'dd-mm-yyyy hh24:mi:ss'), 4071);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:30:24', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:40:44', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:41:32', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:51:32', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 06:53:33', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:18:42', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:33:40', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:33:47', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:36:59', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:37:22', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 07:47:22', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:07:22', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:09:54', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:09:56', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:19:56', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:23:03', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:23:44', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:23:50', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:24:02', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:24:06', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:24:08', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:24:37', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:31:41', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:32:00', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:05', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:14', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:18', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:20', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:21', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:25', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:35:28', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:36:19', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:37:13', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:37:17', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:37:19', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:41:38', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:45:08', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:45:17', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:45:19', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 08:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:00:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:01:52', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:14:07', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:30:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:31:48', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 09:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:00:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:07:59', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:17:59', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:38:42', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:39:17', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:39:31', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:39:36', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:39:38', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:40:19', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:50:19', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 10:52:22', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:17:32', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:26:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:27:31', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:27:36', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:27:38', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:29:43', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:34:10', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:41:35', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:47:58', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 11:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:00:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:04:39', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:28:15', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:37:12', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:46:01', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 12:52:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:02:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:04:02', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:29:12', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:54:48', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:55:05', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 13:55:07', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:00:41', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:13:07', 'dd-mm-yyyy hh24:mi:ss'), 4075);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:26:00', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:31:18', 'dd-mm-yyyy hh24:mi:ss'), 4076);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:42:13', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 14:59:59', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4076);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:30:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 15:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:00:00', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:11:05', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:21:05', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:23:07', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:41:01', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:42:55', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:43:12', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:43:16', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:43:18', 'dd-mm-yyyy hh24:mi:ss'), 4077);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:45:39', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:51:57', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:52:18', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 16:52:20', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:02:20', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:05:21', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:05:23', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:06:46', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:06:50', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:06:52', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:07:06', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:07:36', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:07:49', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:07:51', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:17:51', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:23:43', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:28:46', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:34:59', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:36:26', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:46:26', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4078);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 17:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:16:07', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:19:23', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:19:37', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:19:39', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:29:43', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:36:10', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:36:22', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:36:24', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:46:24', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 18:53:08', 'dd-mm-yyyy hh24:mi:ss'), 4079);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:03:08', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:14:59', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:20:41', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:26:13', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:34:04', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:34:59', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:40:19', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:47:18', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 19:51:10', 'dd-mm-yyyy hh24:mi:ss'), 4080);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:01:10', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:03:16', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:14:59', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:29:19', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:34:59', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:39:41', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:49:41', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 20:51:24', 'dd-mm-yyyy hh24:mi:ss'), 4081);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:01:24', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:03:09', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:10:19', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:19:33', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:26:46', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:28:27', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:31:42', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:31:53', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:31:55', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:49:17', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 21:53:07', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:03:07', 'dd-mm-yyyy hh24:mi:ss'), 4082);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:04:59', 'dd-mm-yyyy hh24:mi:ss'), 4083);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:15:34', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:16:58', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:21:10', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:31:10', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:33:13', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 22:58:23', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:28:23', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:30:50', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:31:06', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:31:08', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:34:59', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:38:13', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:44:10', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:51:07', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('17-09-2021 23:58:33', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:39:02', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:49:02', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 11:51:04', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 12:16:13', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 12:46:14', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 12:54:30', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 12:54:40', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 12:54:42', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:04:45', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:05:04', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:15:04', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:17:06', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:19:37', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:19:45', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:19:47', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:23:42', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:28:08', 'dd-mm-yyyy hh24:mi:ss'), 2984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:42:50', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:44:30', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:45:00', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:45:09', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 13:56:48', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:15:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:21:05', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:21:49', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:31:49', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:32:34', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:32:40', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:32:42', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:37:59', 'dd-mm-yyyy hh24:mi:ss'), 2985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:47:59', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 14:55:10', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:00:41', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:03:53', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:10:11', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:10:19', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:10:55', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:12:38', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:18:18', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:18:49', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:20:59', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:26:34', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:45:11', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 15:53:48', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:03:48', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:14:03', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:24:03', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:26:08', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:27:13', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:27:26', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:37:26', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:57:36', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:58:31', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:59:15', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:59:20', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 16:59:22', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:02:16', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:12:16', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:14:19', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:21:37', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:21:50', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:21:52', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:22:18', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:22:19', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:23:50', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:23:52', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:24:14', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:29:29', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:29:39', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:29:41', 'dd-mm-yyyy hh24:mi:ss'), 2987);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:35:52', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:45:52', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:47:54', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:55:48', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:55:58', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 17:56:00', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:15:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:15:34', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:30:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:43:18', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:49:02', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 18:59:02', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 19:01:04', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 19:26:14', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 19:56:14', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 20:26:14', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 20:56:15', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 21:26:15', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 21:56:16', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:17:25', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:17:54', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:18:08', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:18:13', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:18:15', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:30:11', 'dd-mm-yyyy hh24:mi:ss'), 2988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:35:11', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:45:11', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 22:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:07:26', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:17:26', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:31:29', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:41:29', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('17-09-2021 23:43:31', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:50:22', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:40', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:45', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:48', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:50', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:52', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:54', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:57', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:51:59', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:52:01', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:52:04', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:52:06', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:54:12', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:57:08', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:58:03', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:58:30', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:02:59', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:07:38', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:14:42', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:14:50', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:14:52', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:14:56', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:14:58', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:00', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:03', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:06', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:09', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:11', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:13', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:22', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:25', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:27', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:30', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:33', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:40', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:46', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:48', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:50', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:54', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:57', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:15:59', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:02', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:04', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:07', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:09', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:14', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:17', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:19', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:22', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:24', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:26', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:28', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:31', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:33', 'dd-mm-yyyy hh24:mi:ss'), 5144);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:37', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:40', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:16:42', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:17:02', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:22:03', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:23:24', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:25:47', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:27:27', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:27:56', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:28:46', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:33:23', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:36:25', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:37:38', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:40:15', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:40:39', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:44:19', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:48:37', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:48:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:49:58', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:50:02', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:52:12', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:52:38', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:55:03', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:56:39', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:58:11', 'dd-mm-yyyy hh24:mi:ss'), 5144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 11:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:09:05', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:11:24', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:12:00', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:12:48', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:13:46', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:14:53', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:15:58', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:18:55', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:19:10', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:21:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:22:11', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:22:33', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:22:40', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:25:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:29:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:30:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:35:58', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:36:05', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:36:07', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:36:16', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:37:00', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:37:08', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:38:34', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:38:40', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:41:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:42:32', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:43:58', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:44:09', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:44:16', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:44:28', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:45:55', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:47:38', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:57:38', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 12:59:41', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 13:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 13:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:23', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:36', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:38', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:41', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:45', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:48', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:51', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:56', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:02:58', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:01', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:03', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:05', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:07', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:09', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:12', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:14', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:16', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:19', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:21', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:23', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:26', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:29', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:31', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:34', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:37', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:40', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:45', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:47', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:49', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:52', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:54', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:56', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:03:59', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:01', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:04', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:11', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:14', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:23', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:25', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:30', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:33', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:36', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:40', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:42', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:45', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:04:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:30', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:45', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:47', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:49', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:55', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:05:58', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:06:01', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:06:08', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:06:11', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:06:14', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:07:04', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:09:01', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:13:06', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:14:49', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:15:10', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:15:20', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:15:50', 'dd-mm-yyyy hh24:mi:ss'), 5145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:19:24', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:20:50', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:26:55', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:27:24', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:29:38', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:31:41', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:31:52', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:32:23', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:34:14', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:35:11', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:36:01', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:37:05', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:38:21', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:38:57', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:39:14', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:39:58', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:44:42', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:45:23', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:46:02', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:51:33', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:53:25', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:53:39', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:53:52', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 14:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:02:53', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:04:09', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:06:10', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:09:22', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:09:31', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:09:53', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:11:39', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:14:38', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:16:16', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:17:32', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:20:01', 'dd-mm-yyyy hh24:mi:ss'), 5146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:21:01', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:21:50', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:22:36', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:26:38', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:27:02', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:27:26', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:27:46', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:28:32', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:28:35', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:29:27', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:32:20', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:34:10', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:41:48', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:41:50', 'dd-mm-yyyy hh24:mi:ss'), 5147);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:43:42', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:44:27', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:47:18', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:47:39', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:48:24', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:52:05', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:52:38', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:53:08', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:53:12', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:53:39', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:59:12', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:59:14', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 15:59:21', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:01:14', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:01:51', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:11:51', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:13:54', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:52:02', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:52:34', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:52:52', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:52:57', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:52:59', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:53:28', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:55:55', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:57:24', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 16:58:03', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:07:10', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:07:22', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:07:34', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:08:03', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:08:05', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:08:22', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:08:24', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:35', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:39', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:41', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:10:07', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:14:53', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:15:01', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:15:04', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:22:56', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:30:05', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:34:41', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:34:51', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:34:54', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:34:57', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:34:59', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:01', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:03', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:07', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:10', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:16', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:19', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:28', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:30', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:32', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:35', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:37', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:40', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:42', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:45', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:47', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:51', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:54', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:35:59', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:06', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:08', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:11', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:13', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:17', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:19', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:22', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:24', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:26', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:29', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:31', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:33', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:36', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:38', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:40', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:43', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:45', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:47', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:50', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:52', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:54', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:36:58', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:10', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:13', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:22', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:26', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:32', 'dd-mm-yyyy hh24:mi:ss'), 5148);
commit;
prompt 2400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:35', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:37', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:40', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:42', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:45', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:47', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 00:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:22:38', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:32:38', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:34:40', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:37:12', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:37:22', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:37:24', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 01:57:43', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 02:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 02:10:26', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 02:20:26', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 02:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 02:47:38', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 03:17:38', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 03:47:38', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 04:17:39', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 04:47:39', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 05:17:40', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 05:47:40', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 06:17:41', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 06:47:41', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:17:41', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:28:52', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:29:30', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:29:47', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:29:52', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:29:54', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:34:00', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:35:22', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:35:45', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:35:47', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:36:02', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:36:04', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:36:12', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:36:14', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:37:47', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:37:51', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:37:53', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:37:54', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:38:13', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:38:32', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:38:40', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:38:42', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:48:42', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 07:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:38:39', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:42:47', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:42:55', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:42:57', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 08:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 09:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 10:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5974);
commit;
prompt 2500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 11:55:45', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:05:45', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:37:34', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:47:34', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:49:41', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 12:59:41', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:01:43', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:26:52', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:56:53', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:58:43', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:58:52', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 13:58:54', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:28:37', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 14:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:26:30', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:27:35', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:31:45', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:38:56', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:45:03', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:45:09', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:45:11', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:46:07', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 15:53:26', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:03:26', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:19:12', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:26:54', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:36:54', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:38:56', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:51:48', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:52:44', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:52:48', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:52:50', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:52:53', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 16:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:03:45', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:03:54', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:03:56', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:04:10', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:04:13', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:04:16', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:04:32', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:06:09', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:06:21', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:06:23', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 17:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 18:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:36:33', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:46:25', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:46:36', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 19:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 20:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
commit;
prompt 2600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:15:45', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:27:39', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:57:30', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 21:59:32', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 22:24:41', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 22:46:16', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 22:46:23', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 22:46:25', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 22:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:32:07', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('17-09-2021 23:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:52', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:54', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:37:58', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:38:04', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:38:07', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:38:17', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:38:38', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:38:40', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:39:36', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:40:18', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:40:59', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:44:41', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:45:18', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:47:01', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:48:08', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:49:46', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:56:55', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:57:28', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 17:59:09', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:01:59', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:03:31', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:04:52', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:05:32', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:06:17', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:14:16', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:15:04', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:15:45', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:15:49', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:16:40', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:30:35', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:32:45', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:32:55', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:34:09', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:34:38', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:37:39', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:43:31', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:43:44', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:45:32', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:47:10', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:51:27', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:51:34', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:51:36', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:51:59', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 18:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:04:43', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:12:34', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:13:22', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:18:39', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:28:33', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:29:06', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:29:20', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:29:25', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:29:27', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:08', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:13', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:33', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:36', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:38', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:43', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:46', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:48', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:51', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:54', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:56', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:37:58', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:38:01', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:38:03', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:38:05', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:38:08', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:42', 'dd-mm-yyyy hh24:mi:ss'), 5149);
commit;
prompt 2700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:49', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:52', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:54', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:57', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:40:59', 'dd-mm-yyyy hh24:mi:ss'), 5149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:42:08', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:42:10', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:42:12', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:43:01', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:44:25', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:45:25', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:46:29', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:49:09', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:53:39', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 19:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:01:01', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:01:32', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:13:33', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:38:32', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:38:52', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:38:54', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:41:43', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:43:01', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:45:34', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:50:22', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:51:16', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 20:53:31', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:03:31', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:05:33', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:30:43', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:35:03', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:35:17', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:35:19', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:35:32', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:22', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:25', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:27', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:29', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:32', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:36', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:39', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:44', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:49', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:52', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:55', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:38:58', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:39:02', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:39:08', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:16', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:22', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:26', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:30', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:33', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:54', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:40:57', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:41:00', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:41:02', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:41:06', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:41:10', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:45:34', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:45:38', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:51:50', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:54:42', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 21:58:15', 'dd-mm-yyyy hh24:mi:ss'), 5150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:02:03', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:02:19', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:03:00', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:06:56', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:09:23', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:09:42', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:14:08', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:14:21', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:16:36', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:26:36', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:28:38', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 22:53:47', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:23:48', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:43:18', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:44:15', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:44:28', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:44:33', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:44:35', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:44:43', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:49:23', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:28', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:33', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:35', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:44', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:55', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:50:58', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:51:00', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:51:08', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:51:24', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:51:27', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:51:59', 'dd-mm-yyyy hh24:mi:ss'), 5151);
commit;
prompt 2800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:52:02', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:52:08', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:52:33', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:54:42', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:56:16', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 23:59:48', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:00:22', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:00:30', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:01:39', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:01:42', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:01:47', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:03:17', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:03:21', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:04:18', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:09:44', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:13:00', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:15:33', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:16:36', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:17:07', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:18:17', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:19:50', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:21:30', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:22:34', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:23:45', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:24:32', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:24:44', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:25:20', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:35:20', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:36:45', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:37:09', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:39:17', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:40:48', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:41:56', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:42:56', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:43:49', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:44:11', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:53:16', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:58:03', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:58:13', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 00:58:15', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:04:12', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:04:49', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:05:40', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:06:31', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:07:42', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:09:44', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:12:55', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:14:53', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:15:32', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:16:30', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:21:17', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:24:44', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:34:50', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:36:51', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:45:28', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:45:36', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:45:38', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:52:18', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:52:58', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 01:53:00', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 02:03:00', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 02:05:02', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 02:30:12', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 03:00:12', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 03:30:13', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 04:00:13', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 04:30:13', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 05:00:14', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 05:30:14', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 06:00:15', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 06:30:15', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:00:16', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:30:16', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:31:11', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:31:53', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:24', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:42', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:44', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:32:48', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:33:47', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:39:52', 'dd-mm-yyyy hh24:mi:ss'), 5140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:40:51', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:41:47', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:43:08', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:43:32', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:53:07', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:54:44', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:56:11', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 07:59:44', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:00:09', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:00:11', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:02:17', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:02:19', 'dd-mm-yyyy hh24:mi:ss'), 5141);
commit;
prompt 2900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:02:45', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:02:49', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:02:51', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:03:12', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:03:51', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:04:02', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:04:04', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:07:35', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:09:44', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:11:24', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:14:51', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:18:13', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:19:52', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:22:15', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:24:44', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:26:08', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:26:15', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:30:52', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:39:17', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:40:42', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:43:55', 'dd-mm-yyyy hh24:mi:ss'), 5141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:45:02', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:47:22', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:52:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:54:44', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:58:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 08:58:49', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:02:14', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:02:52', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:05:52', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:06:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:35', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:37', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:39', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:53', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:09:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:10:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:10:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:10:09', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:10:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:02', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:04', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:15', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:41', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:44', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:48', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:50', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:53', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:11:55', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:05', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:08', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:31', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:34', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:36', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:39', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:42', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:44', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:47', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:49', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:51', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:53', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:12:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:02', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:04', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:06', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:10', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:13', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:15', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:17', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:19', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:22', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:25', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:28', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:31', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:33', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:36', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:38', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:41', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:49', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:51', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:54', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:13:59', 'dd-mm-yyyy hh24:mi:ss'), 5142);
commit;
prompt 3000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:05', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:08', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:11', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:13', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:15', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:24', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:30', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:34', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:36', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:39', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:47', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:52', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:54', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:14:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:01', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:06', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:12', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:14', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:16', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:22', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:24', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:29', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:34', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:38', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:40', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:44', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:46', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:49', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:52', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:54', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:15:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:05', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:08', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:11', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:14', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:17', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:19', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:21', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:23', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:26', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:29', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:31', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:33', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:40', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:47', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:49', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:51', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:53', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:16:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:05', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:07', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:09', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:13', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:15', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:22', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:25', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:39', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:42', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:48', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:17:54', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:07', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:10', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:12', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:23', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:25', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:29', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:34', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:18:37', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:25:50', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:26:14', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:26:21', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:26:23', 'dd-mm-yyyy hh24:mi:ss'), 5142);
commit;
prompt 3100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:26:52', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:27:08', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:29:07', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:31:57', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:41:12', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:43:33', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:45:42', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:37', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:41', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:47', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:50', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:55', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:46:57', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:47:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:47:31', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:47:42', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:47:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:00', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:03', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:05', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:09', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:14', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:17', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:48:27', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:04', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:06', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:08', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:12', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:16', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:18', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:23', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:25', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:28', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:30', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:32', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:34', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:38', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:40', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:43', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:45', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:48', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:51', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:54', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:56', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:50:58', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:01', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:10', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:13', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:17', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:20', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:23', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:25', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:28', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:30', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:33', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:35', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:38', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:41', 'dd-mm-yyyy hh24:mi:ss'), 5142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:45', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:50', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:55', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:51:57', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:01', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:03', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:05', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:08', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:10', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:12', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:17', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:19', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:22', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:24', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:26', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:32', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:35', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:37', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:40', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:43', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:45', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:48', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:51', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:52:53', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:01', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:04', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:07', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:11', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:13', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:16', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:18', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:20', 'dd-mm-yyyy hh24:mi:ss'), 5143);
commit;
prompt 3200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:23', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:26', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:29', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:31', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:34', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:37', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:39', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:41', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:44', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:46', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:49', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:51', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:54', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:57', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:55:59', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:01', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:04', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:07', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:09', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:12', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:14', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:17', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:19', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:21', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:24', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:27', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:29', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:36', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:38', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:40', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:42', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:45', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:47', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:49', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:53', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:56', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:56:59', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:01', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:03', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:06', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:08', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:10', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:13', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:15', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:18', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:20', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:24', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:27', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:31', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:34', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:39', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:41', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:47', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:52', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:56', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:57:58', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:58:04', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 09:59:37', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:00:34', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:02:55', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:08:00', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:09:43', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:11:23', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:12:20', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:19:42', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:20:37', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:26:20', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:28:39', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:29:03', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:39:03', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:39:43', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:40:13', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:45:20', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:47:40', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('17-09-2021 10:48:44', 'dd-mm-yyyy hh24:mi:ss'), 5143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:25:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:28:13', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:28:45', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:29:00', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:29:04', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:29:06', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:35:07', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:45:07', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 00:47:10', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 01:12:20', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 01:42:20', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 02:12:21', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 02:42:21', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 03:12:22', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 03:42:22', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 04:12:23', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 04:42:23', 'dd-mm-yyyy hh24:mi:ss'), 1790);
commit;
prompt 3300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 05:12:23', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 05:42:24', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 06:12:24', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 06:42:25', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 07:12:25', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 07:42:26', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:01:36', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:02:16', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:02:31', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:02:36', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:02:38', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:04:44', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:10:47', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:10:56', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:10:58', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:11:18', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:12:34', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:13:19', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:15:03', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:15:10', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:15:12', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:18:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:20:51', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:30:51', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:43:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 08:56:57', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:00:19', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:00:25', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:00:27', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:13:28', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:24:21', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:27:11', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:27:19', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:27:21', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:45:59', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:49:56', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:50:06', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 09:50:08', 'dd-mm-yyyy hh24:mi:ss'), 1791);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:00:11', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:13:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:16:01', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:17:41', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:17:51', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:17:53', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:28:19', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:30:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:30:38', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:34:18', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:43:15', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:43:30', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 10:54:25', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:06:32', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:16:04', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:16:12', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:16:14', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:19:02', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:19:57', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:20:08', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:20:10', 'dd-mm-yyyy hh24:mi:ss'), 1792);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:30:11', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 11:58:28', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:02:53', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:05:50', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:05:57', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:05:59', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:07:26', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:07:30', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:07:47', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:07:49', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:08:33', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:18:33', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:19:32', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:19:41', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:19:43', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:24:01', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1793);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:37:13', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:41:35', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:41:44', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:41:46', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:44:55', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:54:55', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 12:56:58', 'dd-mm-yyyy hh24:mi:ss'), 1794);
commit;
prompt 3400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 13:22:08', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 13:52:08', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:00:59', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:01:07', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:01:09', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:02:20', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:03:26', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:03:33', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:03:35', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:03:37', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:05:22', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:11:58', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:12:07', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:12:09', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:23:29', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:25:03', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:25:11', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:25:13', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:31:46', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:42:02', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:45:03', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:45:10', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:45:12', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 14:58:00', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:06:14', 'dd-mm-yyyy hh24:mi:ss'), 1794);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:16:14', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:22:55', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:32:55', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 15:58:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1795);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:07:33', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:08:00', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:08:08', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:08:10', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:12:11', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:12:25', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:12:34', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:12:36', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:16:10', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:18:37', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:18:46', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:18:48', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:18:49', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:23:08', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:33:08', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:35:11', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:54:35', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:54:44', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 16:54:46', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:09:24', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:18:27', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:24:50', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:25:20', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:25:22', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:25:31', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:25:33', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:11', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:15', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:17', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:37', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:52', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:27:59', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:28:01', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:30:46', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:32:51', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:32:58', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:33:00', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:33:27', 'dd-mm-yyyy hh24:mi:ss'), 1796);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:48:27', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 17:58:27', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:13:27', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:13:50', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:16:58', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:17:24', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:17:40', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:17:45', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:17:47', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:18:28', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:23:01', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:28:06', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:33:27', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:43:28', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:44:22', 'dd-mm-yyyy hh24:mi:ss'), 1797);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:48:28', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:51:36', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 18:51:46', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 19:01:46', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 19:03:50', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 19:29:00', 'dd-mm-yyyy hh24:mi:ss'), 1798);
commit;
prompt 3500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 19:59:00', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 20:29:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 20:59:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 21:29:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 21:59:02', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:00:03', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:00:32', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:00:51', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:00:55', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:00:57', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:01:09', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:03:38', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:04:23', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:05:19', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:07:06', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:08:03', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:08:19', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:08:58', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:09:31', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:11:52', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:21:52', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:23:56', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 22:49:05', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:19:05', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:32:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:32:08', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:32:10', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:33:27', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:36:45', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:46:45', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('17-09-2021 23:48:48', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 00:24:40', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 00:54:40', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 01:24:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 01:54:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 02:24:41', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 02:54:42', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 03:24:42', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 03:54:43', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 04:24:43', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 04:54:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 05:24:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 05:54:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 06:24:45', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 06:54:45', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 07:24:46', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 07:54:46', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 08:24:47', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 08:54:47', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 09:24:47', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 09:54:48', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 10:24:48', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 10:54:49', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 11:24:49', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 11:54:50', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 12:24:50', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 12:54:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 13:24:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 13:54:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 14:24:52', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 14:54:52', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 15:24:53', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 15:54:53', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 16:24:54', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 16:54:54', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 17:24:55', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 17:54:55', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 18:24:55', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 18:54:56', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 19:24:56', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 19:54:57', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 20:24:57', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 20:54:58', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 21:24:58', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 21:54:59', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 22:24:59', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 22:54:59', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 23:25:00', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('17-09-2021 23:55:00', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 3600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:47:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:48:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:49:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:59:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 13:01:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 13:26:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 13:56:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:20:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 3700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:21:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:22:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:23:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:24:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 3800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:25:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:26:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:27:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:28:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:19', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 3900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:30:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:17', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:31:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:16', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:45', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:32:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:33:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:41', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:46', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:34:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:18', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 4000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:44', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:35:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:36:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:36:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:36:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:36:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:46:20', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:48:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:55:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:55:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:55:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:57:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 14:59:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 15:02:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 15:12:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 15:14:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 15:39:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 16:09:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 16:39:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 17:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 17:39:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 17:51:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 17:54:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 18:04:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 18:06:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 18:31:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 19:01:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 19:31:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 20:01:49', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 20:31:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 21:01:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 21:31:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 22:01:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 22:31:51', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 23:01:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 23:31:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 00:26:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 00:56:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:26:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:34:01', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:34:13', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:34:15', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:40:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:44:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:54:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 01:56:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 02:22:01', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 02:52:01', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 03:22:02', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 03:52:02', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 04:22:03', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 04:52:03', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 05:22:04', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 05:52:04', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 06:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 06:52:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:22:06', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:36:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:37:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:38:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:38:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:38:07', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:40:32', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:44:58', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:45:24', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:45:26', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:46:10', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:46:12', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:47:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:47:34', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:47:36', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:47:54', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:49:41', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:49:49', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:49:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:52:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:53:56', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 07:54:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:04:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:06:55', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:20:36', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:21:44', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:22:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:22:07', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:23:48', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:33:48', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:35:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:50:41', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:50:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
commit;
prompt 4100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:50:53', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:57:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 08:58:24', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:04:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:04:09', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:04:11', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:12:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:13:56', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:23:56', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:30:19', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:30:29', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:30:31', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:36:19', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:37:03', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:37:32', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:38:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:39:32', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:40:23', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:42:22', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:44:16', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:45:06', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:45:56', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:48:57', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:50:40', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:51:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:55:29', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 09:56:35', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:06:35', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:08:36', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:33:45', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:49:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:49:52', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:49:54', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:50:53', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:52:53', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:57:00', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 10:58:38', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 11:08:38', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 11:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 11:35:52', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:05:52', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:13:57', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:14:05', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:14:07', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:14:17', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:15:10', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:16:02', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:16:16', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:16:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:20', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:22', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:24', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:26', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:33', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:36', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:38', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:43', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:46', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:48', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:51', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:54', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:17:57', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:01', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:03', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:10', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:13', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:21', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:24', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:46', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:49', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:52', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:55', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:18:58', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:04', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:06', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:09', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:11', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:15', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:18', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:22', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:26', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:44', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:46', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:49', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:19:52', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:00', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:05', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:12', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:26', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:34', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:20:53', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:21:06', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:21:11', 'dd-mm-yyyy hh24:mi:ss'), 3130);
commit;
prompt 4200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:21:13', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:21:34', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:23:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:24:12', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:25:14', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:25:26', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:26:57', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:27:00', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:28:57', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:03', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:07', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:15', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:24', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:27', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:29:44', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:30:01', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:30:04', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:30:14', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:30:22', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:30:28', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:31:01', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:31:53', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:32:54', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:33:44', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:36:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:37:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:39:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:40:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:40:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:40:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:42:27', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:43:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:44:48', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:45:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:23', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('17-09-2021 12:46:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:00:10', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:01:16', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:02:12', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:03:09', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:04:31', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:06:23', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:06:55', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:07:52', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:08:39', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:09:15', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:10:15', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:13:16', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:14:49', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:15:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:16:55', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:29:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:44:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:44:31', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 00:59:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:01:32', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:08:18', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:08:29', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:08:31', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:18:29', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:19:10', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:24:37', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:29:55', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:31:36', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:39:20', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:49:20', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 01:51:22', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 02:16:32', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 02:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 03:16:33', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 03:46:33', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 04:16:33', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 04:46:34', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 05:16:34', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 05:46:35', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 06:16:35', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 06:46:36', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:16:36', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:28:43', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:29:16', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:29:32', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:29:39', 'dd-mm-yyyy hh24:mi:ss'), 3136);
commit;
prompt 4300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:32:15', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:32:44', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:32:53', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:32:55', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:34:38', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:34:42', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:34:44', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:34:46', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:35:00', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:35:17', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:35:41', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:35:43', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:41:39', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:44:23', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:46:54', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:47:54', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:57:54', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 07:59:57', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:00:34', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:00:46', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:00:48', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:00:53', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:02:06', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:03:09', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:04:45', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:06:28', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:07:33', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:08:06', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:11:42', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:11:58', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:13:05', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:16:27', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:17:36', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:19:53', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:23:47', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:24:33', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:24:54', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:24:58', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:25:00', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:25:36', 'dd-mm-yyyy hh24:mi:ss'), 3136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:30:29', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:31:00', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:32:31', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:34:21', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:34:38', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:35:06', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:37:47', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:38:19', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:38:46', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:40:40', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:45:47', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:46:55', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:48:19', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:50:42', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:53:03', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:54:00', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:54:27', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:55:30', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:55:52', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:58:59', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 08:59:42', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:01:17', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:02:41', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:05:39', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:08:56', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:11:08', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:11:12', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:11:31', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:12:15', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:17:03', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:18:33', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:20:17', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:21:53', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:23:45', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:24:17', 'dd-mm-yyyy hh24:mi:ss'), 3137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:28:07', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:29:20', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:29:54', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:39:54', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:41:56', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:57:27', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:57:35', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:57:37', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 09:58:29', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:04:20', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:04:26', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:04:44', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:05:31', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:09:03', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:16:15', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:16:25', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:17:37', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:18:58', 'dd-mm-yyyy hh24:mi:ss'), 3138);
commit;
prompt 4400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:19:23', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:19:49', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:21:27', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:21:59', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:22:33', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:23:09', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:24:55', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:27:18', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:36:17', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:37:01', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:45:55', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:47:26', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:48:33', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:51:42', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:52:21', 'dd-mm-yyyy hh24:mi:ss'), 3138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:53:15', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:56:23', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:57:03', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:57:32', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:58:59', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 10:59:47', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:01:03', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:02:27', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:03:05', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:03:46', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:04:05', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:05:08', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:15:08', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:16:14', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:24:25', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:26:00', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:27:57', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:30:19', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:32:02', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:36:43', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:46:43', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 11:48:45', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 12:13:55', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 12:43:55', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:13:56', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:24:26', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:24:38', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:24:40', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:29:35', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:30:07', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:30:32', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:31:37', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:31:47', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:32:40', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:34:34', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:35:01', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:35:10', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:36:39', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:36:53', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:37:06', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:37:54', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:39:24', 'dd-mm-yyyy hh24:mi:ss'), 3139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:39:59', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:41:08', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:42:18', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:42:27', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:42:59', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:47:18', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:51:21', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:56:16', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:56:50', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:58:17', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:59:20', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 13:59:47', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:00:22', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:01:37', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:03:29', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:04:18', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:04:59', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:05:50', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:07:42', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:08:59', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:10:05', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:10:51', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:12:53', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:13:46', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:14:25', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:15:03', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:17:58', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:18:34', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3140);
commit;
prompt 4500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:19:41', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:20:11', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:20:42', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:21:07', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:22:08', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:22:41', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:26:28', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:29:52', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:30:23', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:35:38', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:36:01', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:37:11', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:37:39', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:38:40', 'dd-mm-yyyy hh24:mi:ss'), 3140);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:40:36', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:41:05', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:42:25', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:42:40', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:42:54', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:43:07', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:43:45', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:45:16', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:46:07', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:46:26', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:46:45', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:46:59', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:47:27', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:48:42', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:49:15', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:50:15', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:50:40', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:51:12', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:52:07', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:53:22', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:53:44', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:54:02', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 14:58:11', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:01:12', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:02:54', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:09:21', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:19:21', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:29:29', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:31:24', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:32:02', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3141);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:44:30', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:45:38', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:48:05', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:48:37', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:49:03', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:53:23', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:55:15', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 15:57:13', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:01:10', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:03:29', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:11:42', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:12:57', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:24:14', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:34:14', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:52:20', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:52:57', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:53:16', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:53:21', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:53:23', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:54:49', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:56:53', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 16:59:36', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:00:29', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:01:23', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:02:03', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:03:26', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:04:54', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3142);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:14:06', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:14:51', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:14:53', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:16:14', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:16:18', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:16:20', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:16:50', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:18:06', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:18:14', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:22:26', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:23:06', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:23:59', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:24:33', 'dd-mm-yyyy hh24:mi:ss'), 3143);
commit;
prompt 4600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:25:19', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:27:27', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:28:08', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:29:43', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:32:08', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:33:27', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:34:19', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:34:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:35:50', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:36:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:39:23', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:42:22', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:42:59', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:43:31', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:44:10', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:46:27', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:47:36', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:48:55', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:49:40', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:51:56', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:53:08', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:56:07', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 17:57:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:00:20', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:01:15', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:02:45', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:03:22', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:03:51', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:04:18', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:06:19', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:07:05', 'dd-mm-yyyy hh24:mi:ss'), 3143);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:07:51', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:09:06', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:10:03', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:14:14', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:16:36', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:17:09', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:18:53', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:23:24', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:27:35', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:28:53', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:38:53', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:40:55', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:44:39', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:45:52', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:45:54', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:47:37', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:50:31', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:53:46', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:55:19', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:58:30', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:59:06', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 18:59:52', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:01:35', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:02:19', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:03:09', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:05:32', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:06:20', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:07:28', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:07:57', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:09:06', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:09:41', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:13:23', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:13:41', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:14:03', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:14:27', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:17:03', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:17:33', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:18:57', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:19:17', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:20:41', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:21:12', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:21:31', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:22:14', 'dd-mm-yyyy hh24:mi:ss'), 3144);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:23:04', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:23:52', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:24:45', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:25:48', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:27:22', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:28:16', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:29:07', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:30:01', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:30:21', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:31:35', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:33:07', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:34:29', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:34:45', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:36:02', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:37:18', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:37:59', 'dd-mm-yyyy hh24:mi:ss'), 3145);
commit;
prompt 4700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:38:22', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:39:37', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:41:01', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:42:33', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:43:40', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:44:45', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:45:36', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:46:17', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:47:31', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:48:25', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:49:20', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:49:47', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:50:51', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:51:52', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:53:29', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:54:12', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 19:58:59', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:00:05', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:01:59', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:03:24', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:03:52', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:04:29', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:08:27', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:11:55', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:16:05', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:18:56', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:19:29', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:20:22', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:20:58', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:21:28', 'dd-mm-yyyy hh24:mi:ss'), 3145);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:22:43', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:23:20', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:24:17', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:27:00', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:34:21', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:34:29', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:37:34', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:40:09', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:40:49', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:41:12', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:42:30', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:43:06', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:43:23', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:44:15', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:44:44', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:46:07', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:46:36', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:52:26', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:55:15', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:56:28', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 20:58:38', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 21:08:38', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 21:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 21:35:49', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:05:49', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:09:40', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:10:28', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:10:30', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:11:40', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:14:14', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:15:34', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:17:01', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:18:42', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:20:06', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:21:22', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:25:06', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:26:58', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:28:26', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:30:10', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:31:32', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3146);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:35:24', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:37:06', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:39:19', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:40:45', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:42:48', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:45:08', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:46:00', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:48:20', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:52:52', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:53:46', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:55:16', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:56:47', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 22:58:44', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:08:44', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:10:45', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:27:45', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:28:09', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:28:11', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3147);
commit;
prompt 4800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:38:03', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:38:48', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:38:57', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:39:15', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:39:50', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:40:13', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:41:08', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:43:25', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:45:02', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:45:50', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:46:06', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:46:28', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:46:46', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:47:13', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:47:38', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:48:34', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:49:11', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:49:18', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:50:48', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:53:11', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:53:53', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:54:16', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:55:26', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:57:20', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:58:30', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('17-09-2021 23:59:34', 'dd-mm-yyyy hh24:mi:ss'), 3147);
commit;
prompt 4831 records loaded
set feedback on
set define on
prompt Done.
