﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 00:03:00', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 00:33:00', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 01:03:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 01:33:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 02:03:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 02:33:02', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 03:03:02', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 03:33:03', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 04:03:03', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 04:33:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 05:03:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 05:33:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 06:03:05', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 06:33:05', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 07:03:06', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 07:33:06', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 08:03:07', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 08:33:07', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 09:03:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 09:33:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 10:03:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 10:33:09', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 11:03:09', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 11:33:10', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 12:03:10', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 12:33:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 13:03:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 13:33:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 14:03:12', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 14:33:12', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 15:03:13', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 15:33:13', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 16:03:14', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 16:33:14', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 17:03:14', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 17:33:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 18:03:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 18:33:16', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 19:03:16', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 19:33:17', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 20:03:17', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 20:33:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 21:03:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 21:33:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 22:03:19', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 22:33:19', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 23:03:20', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('18-09-2021 23:33:20', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 00:01:10', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 00:31:10', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 01:01:11', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 01:31:11', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 02:01:12', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 02:31:12', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 03:01:12', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 03:31:13', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 04:01:13', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 04:31:14', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 05:01:14', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 05:31:15', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 06:01:15', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 06:31:16', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 07:01:16', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 07:31:16', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:01:17', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:31:17', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:56:10', 'dd-mm-yyyy hh24:mi:ss'), 1319);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:57:01', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:57:23', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:57:27', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 08:57:29', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:02:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:10:36', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:17:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:27:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:32:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:42:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:47:33', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 09:55:54', 'dd-mm-yyyy hh24:mi:ss'), 1320);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:02:33', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:05:19', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:05:36', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:10:08', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:10:15', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:10:17', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:11:38', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:21:38', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:23:40', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 10:48:49', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 11:18:50', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 11:48:50', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 12:18:51', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 12:48:51', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:18:52', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:31:30', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:31:38', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:31:40', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:32:33', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:39:39', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:39:49', 'dd-mm-yyyy hh24:mi:ss'), 1321);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:39:56', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:39:58', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:41:05', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:51:05', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:53:10', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:56:10', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:56:20', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:56:22', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 13:59:57', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 14:09:57', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 14:11:59', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 14:37:08', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 15:07:09', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 15:37:09', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 16:07:09', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 16:37:10', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 17:07:10', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 17:37:11', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 18:08:20', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 18:38:20', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 19:08:21', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 19:38:21', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 20:08:22', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 20:38:22', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 21:08:23', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 21:38:23', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 22:08:24', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 22:38:24', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 23:08:24', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('18-09-2021 23:38:25', 'dd-mm-yyyy hh24:mi:ss'), 1321);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 00:16:37', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 00:46:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 01:16:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 01:46:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 02:16:39', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 02:46:39', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 03:16:40', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 03:46:40', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 04:16:41', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 04:46:41', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 05:16:41', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 05:46:42', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 06:16:42', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 06:46:43', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 07:16:43', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 07:46:44', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 08:16:44', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 08:46:44', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 09:16:45', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 09:46:45', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 10:16:46', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 10:46:46', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 11:16:47', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 11:46:47', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 12:16:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 12:46:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 13:16:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 13:46:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 14:16:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 14:46:50', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 15:16:50', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 15:46:51', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 16:16:51', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 16:46:52', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 17:16:52', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 17:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 18:16:53', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 18:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 19:16:54', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 19:46:54', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 20:16:55', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 20:46:55', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 21:16:56', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 21:46:56', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 22:16:57', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 22:46:57', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 23:16:57', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('18-09-2021 23:46:58', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 00:15:27', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 00:45:27', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 01:15:28', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 01:45:28', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 02:15:28', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 02:45:29', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 03:15:29', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 03:45:30', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 04:15:31', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 04:45:31', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 05:15:31', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 05:45:32', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 06:15:32', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 06:45:33', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 07:15:33', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 07:45:34', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 08:15:34', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 08:45:35', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 09:15:35', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 09:45:36', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 10:15:36', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 10:45:37', 'dd-mm-yyyy hh24:mi:ss'), 947);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 11:15:37', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 11:45:37', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 12:15:38', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 12:45:38', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 13:15:39', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 13:45:39', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 14:15:40', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 14:45:40', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 15:15:40', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 15:45:41', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 16:15:41', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 16:45:42', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 17:15:42', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 17:45:43', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 18:15:43', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 18:45:44', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 19:15:44', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 19:45:44', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 20:15:45', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 20:45:45', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 21:15:46', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 21:45:46', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 22:15:47', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 22:45:47', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 23:15:48', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('18-09-2021 23:45:48', 'dd-mm-yyyy hh24:mi:ss'), 947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 00:20:46', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 00:50:47', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 01:20:47', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 01:50:48', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 02:20:48', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 02:50:49', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 03:20:49', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 03:50:49', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 04:20:50', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 04:50:50', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 05:20:51', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 05:50:51', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 06:20:52', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 06:50:52', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:20:53', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:30:09', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:31:21', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:32:05', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:32:09', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:32:11', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:35:06', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:37:26', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:47:26', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:49:28', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:55:47', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:55:56', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 07:55:58', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:05:06', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:15:06', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:15:21', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:24:33', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:24:40', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:24:42', 'dd-mm-yyyy hh24:mi:ss'), 2050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:34:45', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:35:06', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:45:06', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:50:05', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 08:58:22', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 09:08:22', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 09:10:22', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 09:35:31', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:05:31', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:30:00', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:30:06', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:30:08', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:35:04', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:44:13', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:45:19', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:45:26', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:45:28', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:50:04', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 10:55:38', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:05:38', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:07:40', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:11:03', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:11:10', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:11:12', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:20:04', 'dd-mm-yyyy hh24:mi:ss'), 2051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:30:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:30:28', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:40:28', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 11:42:30', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 12:07:40', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 12:37:40', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:07:40', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:35:13', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:35:19', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:50:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 13:58:27', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 14:08:27', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 14:10:29', 'dd-mm-yyyy hh24:mi:ss'), 2052);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 14:35:38', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:04:24', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:04:56', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:04:58', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:05:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:15:03', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:16:15', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:16:22', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:16:24', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:20:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:25:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:35:04', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 15:37:06', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:02:15', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:06:33', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:06:39', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:06:41', 'dd-mm-yyyy hh24:mi:ss'), 2052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:13:33', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:23:33', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:25:35', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 16:50:45', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 17:20:45', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 17:50:46', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 18:20:46', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 18:50:47', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 19:20:47', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 19:50:47', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 20:20:48', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 20:50:48', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 21:20:49', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 21:50:49', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 22:20:50', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 22:50:50', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 23:20:51', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('18-09-2021 23:50:51', 'dd-mm-yyyy hh24:mi:ss'), 2053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 00:00:07', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 00:30:08', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 01:00:08', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 01:30:09', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 02:00:09', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 02:30:10', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 03:00:10', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 03:30:10', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 04:00:11', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 04:30:11', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 05:00:12', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 05:30:12', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 06:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 06:30:13', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 07:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 07:30:14', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 08:00:14', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 08:30:15', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 09:00:15', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 09:30:16', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 10:00:16', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 10:30:17', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 11:00:17', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 11:30:17', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 12:00:18', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 12:30:18', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 13:00:19', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 13:30:19', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 14:00:20', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 14:30:20', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 15:00:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 15:30:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 16:00:21', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 16:30:22', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 17:00:22', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 17:30:23', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 18:00:23', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 18:30:24', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 19:00:24', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 19:30:24', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 20:00:25', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 20:30:25', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 21:00:26', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 21:30:26', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:00:27', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:30:27', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:38:53', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:41:29', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:42:33', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:42:37', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:42:39', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:43:06', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:48:06', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 22:58:06', 'dd-mm-yyyy hh24:mi:ss'), 1428);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:00:46', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:03:06', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:05:18', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:11:58', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:21:58', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:24:00', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('18-09-2021 23:49:10', 'dd-mm-yyyy hh24:mi:ss'), 1429);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:03:36', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:13:36', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5049);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:24:31', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:26:38', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:35:32', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:35:39', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:35:41', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:40:40', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 00:57:18', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:19:48', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:20:08', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:30:08', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:32:09', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 01:57:18', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 02:27:19', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 02:57:19', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 03:27:20', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 03:57:20', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 04:27:21', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 04:57:21', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 05:27:22', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 05:57:22', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 06:27:22', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 06:57:23', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:20:49', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:21:25', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:21:42', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:21:46', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:21:48', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:27:16', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:27:18', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:28:39', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:28:42', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:28:44', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:29:01', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:29:21', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:29:27', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:29:29', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 07:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:17:33', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:27:33', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:30:07', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:31:16', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:38:26', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:38:34', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:38:36', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 08:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:11:20', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:25:08', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:52:55', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 09:56:27', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:04:53', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:14:53', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:16:55', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:35:35', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:35:57', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:35:59', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:41:33', 'dd-mm-yyyy hh24:mi:ss'), 5052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 10:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:13:37', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:22:37', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 11:51:34', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:55:39', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 12:57:05', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:07:05', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:09:07', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:34:16', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:53:36', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:53:43', 'dd-mm-yyyy hh24:mi:ss'), 5055);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:53:45', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 13:57:55', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:03:36', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:03:53', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:03:55', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:13:57', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:39:30', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 14:50:54', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:00:54', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:21:29', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:31:29', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:33:32', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:40:31', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:40:37', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:40:39', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:46:36', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 15:56:36', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:15:06', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:15:14', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:15:16', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:20:16', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:30:16', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:32:17', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 16:57:26', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 17:27:27', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 17:57:27', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 18:27:28', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 18:57:28', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 19:27:29', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 19:57:29', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 20:27:30', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 20:57:30', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 21:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 21:57:31', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 22:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 22:57:32', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 23:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('18-09-2021 23:57:33', 'dd-mm-yyyy hh24:mi:ss'), 5057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 00:15:20', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 00:45:20', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 01:15:21', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 01:45:21', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 02:15:22', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 02:45:22', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 03:15:22', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 03:45:23', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 04:15:23', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 04:45:24', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 05:15:24', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 05:45:25', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 06:15:25', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 06:45:26', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:15:26', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:45:27', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:05', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:10', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:28', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:52', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:56', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:54:58', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:55:02', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:55:04', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:55:28', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:55:32', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:55:34', 'dd-mm-yyyy hh24:mi:ss'), 3857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 07:56:28', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 08:06:26', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 08:08:29', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 08:33:39', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 09:03:39', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 09:33:40', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:03:40', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:33:41', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:42:23', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:42:42', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:43:25', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:43:27', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:53:27', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:56:48', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 10:57:01', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:07:01', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:11:48', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:21:48', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:26:48', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:36:48', 'dd-mm-yyyy hh24:mi:ss'), 3858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:41:48', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:47:40', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 11:51:42', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:04:18', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:09:59', 'dd-mm-yyyy hh24:mi:ss'), 4922);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:11:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:13:22', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:16:38', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:36:51', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:38:50', 'dd-mm-yyyy hh24:mi:ss'), 4922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:49:53', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:51:01', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 00:58:55', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:08:55', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:10:57', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:14:13', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:14:43', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:14:45', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:18:50', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:22:12', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:25:42', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:36:51', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:39:29', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:40:18', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:41:50', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:51:50', 'dd-mm-yyyy hh24:mi:ss'), 4923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:56:50', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 01:57:34', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:07:28', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:11:13', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:15:56', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:17:23', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:18:15', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:18:19', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:18:21', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:25:07', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:26:50', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:29:27', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:37:24', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:41:50', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:51:50', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:53:27', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:53:58', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:54:00', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 02:54:56', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:04:56', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:06:55', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:07:00', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:07:09', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:07:11', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:07:22', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:15:24', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:15:38', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:15:40', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:16:54', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:24:22', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:24:29', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:24:31', 'dd-mm-yyyy hh24:mi:ss'), 4924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:26:29', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:26:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:36:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:41:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:51:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 03:56:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:06:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:11:50', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:18:33', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:19:16', 'dd-mm-yyyy hh24:mi:ss'), 4925);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:26:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:30:38', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:30:53', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:36:37', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:46:37', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 04:48:38', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 05:13:47', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 05:43:47', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 06:13:48', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 06:43:48', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 07:13:49', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 07:43:49', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 08:13:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 08:43:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:13:51', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:28:52', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:29:28', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:29:40', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:29:45', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:29:47', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:39:47', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:41:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:48:01', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 09:56:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:00:18', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:05:52', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:06:01', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:06:03', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:09:46', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:11:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:21:50', 'dd-mm-yyyy hh24:mi:ss'), 4926);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:36:50', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:37:46', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:41:50', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:43:57', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:53:57', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 10:56:00', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:03:27', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:03:35', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:03:37', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:05:54', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:15:54', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:17:57', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:43:07', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:55:50', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:55:59', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:56:02', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:56:36', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 11:56:51', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:06:51', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:13:51', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:23:51', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:28:36', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:38:36', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:40:39', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:41:51', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:42:01', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:42:03', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4927);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:49:36', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 12:59:39', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:09:08', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:11:49', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:15:45', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:25:45', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:27:47', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 13:52:57', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:22:57', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:29:03', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:29:11', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:29:13', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:39:13', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:42:58', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:52:58', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 14:55:01', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:15:09', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:16:37', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:17:08', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:17:12', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:17:14', 'dd-mm-yyyy hh24:mi:ss'), 4928);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:46:03', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:56:03', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 16:10:31', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 16:20:31', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 16:22:32', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 16:47:42', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 17:17:42', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 17:47:43', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:08:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:09:52', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:10:47', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:10:51', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:10:53', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:21:49', 'dd-mm-yyyy hh24:mi:ss'), 4929);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:37:05', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 18:39:07', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:04:16', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:34:17', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:54:17', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:55:14', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:55:16', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 19:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:07:11', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:07:25', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:11:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:13:00', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:23:00', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:36:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:41:49', 'dd-mm-yyyy hh24:mi:ss'), 4930);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:51:21', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:56:28', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 20:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:06:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:11:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:18:29', 'dd-mm-yyyy hh24:mi:ss'), 4931);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:26:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:36:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:40:38', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:41:49', 'dd-mm-yyyy hh24:mi:ss'), 4931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:51:49', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:54:59', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 21:57:54', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 22:07:54', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 22:08:50', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 22:18:50', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 22:20:52', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 22:46:01', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:05:17', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:05:28', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:05:30', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:06:25', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:08:02', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:11:48', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:21:48', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:26:48', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:36:48', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:39:51', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:41:48', 'dd-mm-yyyy hh24:mi:ss'), 4932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:51:48', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:56:48', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('18-09-2021 23:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 00:21:13', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 00:51:13', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 01:21:14', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 01:51:14', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 02:21:14', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 02:45:55', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 02:46:06', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 02:46:08', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 02:50:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:00:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:03:39', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:15:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:20:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:35:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:39:35', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:49:35', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:50:03', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 03:50:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:00:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:12:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:22:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:24:15', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 04:49:24', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 05:19:24', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 05:49:25', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 06:19:25', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 06:49:26', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 07:17:48', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 07:17:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 07:27:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 07:29:59', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 07:55:08', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:05:20', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:05:46', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:06:01', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:06:06', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:06:08', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:06:10', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:14:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:24:13', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:26:15', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:40:22', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:40:30', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:40:32', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:49:43', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 08:59:43', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 09:01:46', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 09:26:55', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 09:56:55', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 10:26:56', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 10:56:56', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 11:26:57', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 11:56:57', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 12:26:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 12:56:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 13:26:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 13:56:59', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 14:26:59', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 14:57:00', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 15:27:00', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 15:46:48', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 15:46:56', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 15:46:58', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 15:50:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:00:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:05:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:15:19', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:16:49', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:26:49', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:28:51', 'dd-mm-yyyy hh24:mi:ss'), 2098);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 16:54:01', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 17:24:01', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 17:54:02', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 18:24:02', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 18:54:03', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 19:24:03', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 19:54:04', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 20:24:04', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 20:54:04', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 21:24:05', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 21:54:05', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 22:24:06', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 22:54:06', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 23:24:07', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('18-09-2021 23:54:07', 'dd-mm-yyyy hh24:mi:ss'), 2098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:14:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:15:25', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:24:02', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:29:13', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:33:49', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 00:59:58', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:02:09', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:09:46', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:09:57', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:09:59', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:22:05', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:32:05', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:34:07', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 01:59:17', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 02:29:17', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 02:59:18', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 03:29:18', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 03:59:18', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 04:29:19', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 04:59:19', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 05:29:20', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 05:59:20', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 06:29:21', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 06:59:21', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:29:22', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:32:14', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:33:16', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:33:36', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:33:40', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:33:42', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:43:24', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:43:26', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:44:46', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:44:50', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:44:52', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:45:12', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:46:04', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:46:13', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:46:15', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:54:02', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 07:59:49', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:11:35', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:23:30', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:33:30', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:35:32', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:44:05', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:44:16', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:44:18', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:48:10', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 08:56:17', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:07:08', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:17:08', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:18:11', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:31:44', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:40:20', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 09:57:24', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:02:20', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:10:03', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:31:59', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:35:30', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:43:13', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 10:59:29', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:11:25', 'dd-mm-yyyy hh24:mi:ss'), 4088);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:29:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:38:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:47:05', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 11:59:58', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:01:42', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:03:24', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:10:18', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:10:33', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:10:35', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:17:49', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:29:58', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:45:19', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:55:19', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 12:57:21', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 13:22:31', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 13:52:31', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:07:49', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:08:03', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:08:05', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:11:53', 'dd-mm-yyyy hh24:mi:ss'), 4089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:29:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:32:55', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:47:51', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 14:58:16', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:14:58', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:16:44', 'dd-mm-yyyy hh24:mi:ss'), 4090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:22:15', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:32:15', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:47:14', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 15:59:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:01:33', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:14:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:16:59', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:42:08', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:48:40', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:49:15', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:49:32', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:49:37', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:49:39', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:53:39', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:56:22', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:56:30', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 16:56:32', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:14:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:29:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:44:32', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:53:28', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 17:59:57', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:04:03', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:04:15', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:04:17', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:14:58', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:21:01', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:31:01', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:35:23', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:44:08', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:52:10', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 18:57:37', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:14:34', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:19:28', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:19:36', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:19:38', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:29:58', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:32:39', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:49:59', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 19:52:19', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:00:28', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:09:41', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:09:48', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:09:50', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:19:50', 'dd-mm-yyyy hh24:mi:ss'), 4094);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:21:56', 'dd-mm-yyyy hh24:mi:ss'), 4094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:31:56', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:33:34', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:35:52', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:36:04', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:36:06', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:38:55', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:43:36', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:43:49', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:43:51', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:50:36', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 20:58:51', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:09:38', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:19:38', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:25:13', 'dd-mm-yyyy hh24:mi:ss'), 4095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:32:44', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:42:45', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:47:27', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 21:59:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:04:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:06:45', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:13:11', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:17:57', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:19:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:25:40', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:35:40', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 22:37:41', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:02:51', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:32:12', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:32:26', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:32:28', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:34:58', 'dd-mm-yyyy hh24:mi:ss'), 4096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:38:54', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:47:05', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:49:58', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('18-09-2021 23:59:58', 'dd-mm-yyyy hh24:mi:ss'), 4097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 12:01:42', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 12:03:43', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 12:28:53', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 12:58:53', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:28:54', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:42:59', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:43:19', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:43:21', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:44:56', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:54:56', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 13:56:56', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:04:23', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:04:43', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:04:45', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:11:48', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:14:59', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:23:14', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 14:35:15', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:00:24', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:21:05', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:21:18', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:21:20', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:22:03', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:32:03', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:34:05', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 15:59:14', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 16:29:15', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 16:59:15', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:02:19', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:02:45', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:02:47', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:03:17', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:13:17', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:15:18', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:35:09', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:40:14', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 17:45:12', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 18:10:22', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 18:40:22', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 19:10:23', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 19:40:23', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 20:10:24', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 20:40:24', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 21:10:25', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 21:40:25', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 22:10:25', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 22:40:26', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 23:10:26', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('18-09-2021 23:40:27', 'dd-mm-yyyy hh24:mi:ss'), 3859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:08:40', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:35:33', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:35:41', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:35:43', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:35:44', 'dd-mm-yyyy hh24:mi:ss'), 2989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:45:50', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 00:50:11', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:00:11', 'dd-mm-yyyy hh24:mi:ss'), 2990);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:08:18', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:13:28', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:15:57', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:27:16', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:37:16', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:39:18', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:47:30', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:47:37', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:47:39', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 01:56:29', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:02:19', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:03:52', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:04:00', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:04:02', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:15:10', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:22:21', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:25:22', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:31:15', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:37:48', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:47:48', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:53:44', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:58:17', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:58:32', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 02:58:34', 'dd-mm-yyyy hh24:mi:ss'), 2991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:12:23', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:23:12', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:33:12', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:35:14', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:52:02', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:52:09', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:52:11', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 03:55:27', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:05:27', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:06:56', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:08:46', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:08:48', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:18:57', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:44:49', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 04:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:15:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:35:04', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:39:36', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:39:45', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:39:47', 'dd-mm-yyyy hh24:mi:ss'), 2993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:49:50', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 05:55:24', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:00:11', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:00:22', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:12:03', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:22:03', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:24:04', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:30:57', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:31:07', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:31:09', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:33:25', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:35:00', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:36:48', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:46:48', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 06:48:51', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:14:01', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:22:47', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:23:17', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:23:38', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:23:43', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:23:45', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:26:37', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:29:34', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:30:20', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:30:37', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:30:39', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:32:44', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:32:46', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:33:07', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:36:32', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:36:56', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:36:58', 'dd-mm-yyyy hh24:mi:ss'), 2994);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:39:51', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:46:15', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 07:57:58', 'dd-mm-yyyy hh24:mi:ss'), 2994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:15:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:27:20', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:29:00', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:29:08', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:29:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:34:16', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:36:31', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:46:31', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:47:55', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:48:02', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:48:04', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:48:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:48:34', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:49:01', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 08:54:15', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:04:00', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:05:04', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:05:58', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:13:32', 'dd-mm-yyyy hh24:mi:ss'), 2995);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:20:52', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:30:52', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:34:17', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:39:25', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:49:25', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 09:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:03:32', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:04:44', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:05:08', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:10:52', 'dd-mm-yyyy hh24:mi:ss'), 2996);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:30:48', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:44:16', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:46:44', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:52:52', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:54:26', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:54:53', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:55:01', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 10:56:44', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:05:31', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:05:40', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:05:42', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:06:11', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:13:01', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:22:57', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:23:05', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:23:07', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:31:23', 'dd-mm-yyyy hh24:mi:ss'), 2997);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:36:46', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:39:44', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:49:44', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 11:51:46', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:16:55', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:46:56', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:47:28', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:49:32', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:49:34', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:49:43', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 12:57:05', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:07:05', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:07:15', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:07:22', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:07:23', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:16:03', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:20:09', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:29:28', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:38:34', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:39:00', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:42:24', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:42:30', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:42:33', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:43:38', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:44:00', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:45:50', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:47:16', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2998);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:55:18', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 13:57:12', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:05:56', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:06:07', 'dd-mm-yyyy hh24:mi:ss'), 2999);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:16:07', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:20:09', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:26:47', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:28:43', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:36:28', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:42:24', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2999);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 14:54:18', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:04:15', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:05:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:05:57', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:06:22', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:16:22', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:20:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:20:12', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:27:17', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:37:17', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:39:20', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:40:35', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:40:37', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:50:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:53:37', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:56:29', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:56:36', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 15:56:38', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:00:26', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:05:09', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:06:48', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:16:48', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:18:50', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 16:43:59', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 17:14:00', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 17:44:00', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 18:14:01', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 18:44:01', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 19:14:02', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 19:44:02', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 20:14:03', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 20:44:03', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 21:14:03', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 21:44:04', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 22:14:04', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 22:44:05', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 23:14:05', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('18-09-2021 23:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3000);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 00:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:21:36', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:31:36', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:33:38', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:38:11', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:38:19', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:38:21', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:38:22', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:48:22', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 01:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 02:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 02:04:47', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 02:14:47', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 02:16:49', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 02:41:58', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 03:11:59', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 03:41:59', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 04:12:00', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 04:42:00', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 05:12:00', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 05:42:01', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 06:12:01', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 06:42:02', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:12:02', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:18:00', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:18:51', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:20:59', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:21:02', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:21:42', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:22:01', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:22:05', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:22:07', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:26:39', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:36:39', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:36:42', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:37:06', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:37:08', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:37:41', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:37:43', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:00', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5985);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:06', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:22', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:53', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:39:55', 'dd-mm-yyyy hh24:mi:ss'), 5985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:49:55', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 07:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:42:38', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 08:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:02:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:02:40', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:07:15', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:15:07', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:15:15', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:15:17', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:18:30', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:48:28', 'dd-mm-yyyy hh24:mi:ss'), 5987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:51:40', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:54:15', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 09:56:45', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:01:51', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:09:33', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:11:21', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:16:05', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:19:40', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:20:14', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:23:40', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:24:52', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:27:12', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:27:51', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:29:35', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:32:19', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:00:06', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:00:42', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:07:14', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:09:42', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:12:38', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:22:38', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:24:42', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:25:15', 'dd-mm-yyyy hh24:mi:ss'), 5151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:25:49', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:25:57', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:27:15', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:30:53', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:35:28', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:36:32', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:39:42', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:42:32', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:49:01', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:49:18', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:49:23', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:51:51', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 00:54:42', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:04:20', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:09:42', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:10:15', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:10:23', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:10:27', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:10:57', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:11:25', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:21:25', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:23:27', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 01:48:36', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:06:55', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:07:02', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:07:04', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:07:44', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:17:44', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:19:47', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 02:44:56', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 03:14:57', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 03:44:57', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 04:14:57', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 04:44:58', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 05:14:58', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 05:44:59', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 06:14:59', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 06:45:00', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 07:15:00', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 07:45:01', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 08:15:01', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 08:45:01', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 09:15:02', 'dd-mm-yyyy hh24:mi:ss'), 5152);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 09:45:02', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 10:15:03', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 10:45:03', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 11:15:04', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 11:45:04', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 12:15:05', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 12:45:05', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 13:15:06', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 13:45:06', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 14:15:06', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 14:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 15:15:08', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 15:45:08', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 16:15:09', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 16:45:09', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 17:15:10', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 17:45:10', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 18:15:11', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 18:45:11', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 19:15:12', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 19:45:12', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 20:15:12', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 20:45:13', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 21:15:13', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 21:45:14', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 22:15:14', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 22:45:15', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 23:15:15', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('18-09-2021 23:45:16', 'dd-mm-yyyy hh24:mi:ss'), 5152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:32:33', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:35:41', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:37:18', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:38:16', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:40:08', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:45:12', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:48:44', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:48:52', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:48:54', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:49:21', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:55:26', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:55:46', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:56:27', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:58:41', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:59:17', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 10:59:54', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:00:35', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:04:08', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:06:10', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:07:19', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:07:27', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:10:33', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:10:46', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:11:13', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:11:23', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:11:46', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:15:26', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:23:03', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:26:17', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:26:38', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:37:46', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:40:03', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:42:19', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:42:28', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:42:30', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:43:24', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:48:00', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:52:26', 'dd-mm-yyyy hh24:mi:ss'), 5989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:57:53', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:58:24', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 11:59:45', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:03:35', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:06:58', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:07:26', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:11:44', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:16:16', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:21:52', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:22:26', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:22:42', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:23:32', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:31:57', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:32:05', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:32:13', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:33:11', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:39:21', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:39:28', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:39:30', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:41:15', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:41:46', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:42:33', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:43:28', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:45:29', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:48:51', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 12:50:38', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 13:00:38', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 13:02:40', 'dd-mm-yyyy hh24:mi:ss'), 5990);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 13:27:50', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 13:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:03:48', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:03:59', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:04:01', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:07:26', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:07:45', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:12:23', 'dd-mm-yyyy hh24:mi:ss'), 5990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:13:55', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:15:23', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:22:26', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:26:17', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:27:09', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:28:20', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:35:55', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:36:20', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:36:46', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:37:26', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:40:16', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:50:16', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:52:26', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 14:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:02:45', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:03:14', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:05:03', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:06:11', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:07:06', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:07:26', 'dd-mm-yyyy hh24:mi:ss'), 5991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:17:26', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:22:26', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:32:26', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:37:26', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:39:28', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:44:11', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:45:08', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:45:51', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:46:47', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:51:07', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:52:26', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:53:30', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:54:21', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:55:45', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 15:56:43', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:03:42', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:06:22', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:07:25', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:10:55', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:18:04', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:18:13', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:18:15', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:20:14', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:20:45', 'dd-mm-yyyy hh24:mi:ss'), 5992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:21:19', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:21:43', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:22:06', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:32:06', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:34:08', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 16:59:18', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 17:29:18', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 17:59:19', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 18:29:19', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 18:51:38', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 18:52:17', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 19:02:17', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 19:27:26', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 19:57:27', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 20:27:27', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 20:57:28', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 21:27:28', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 21:57:29', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 22:27:29', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 22:57:29', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 23:27:30', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('18-09-2021 23:57:30', 'dd-mm-yyyy hh24:mi:ss'), 5993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 00:13:57', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 00:43:58', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 01:13:58', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 01:43:59', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 02:13:59', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 02:44:00', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 03:14:00', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 03:44:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 04:14:01', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 04:44:02', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 05:14:02', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 05:44:02', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 06:14:03', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 06:44:03', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 07:14:04', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 07:44:04', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 08:14:05', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 08:44:05', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 09:14:06', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 09:44:06', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 10:14:06', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 10:44:07', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 11:14:07', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 11:44:08', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 12:14:08', 'dd-mm-yyyy hh24:mi:ss'), 1798);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 12:44:09', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 13:14:09', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 13:44:10', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 14:14:10', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 14:44:10', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 15:14:11', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 15:44:11', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 16:14:12', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 16:44:12', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 17:14:13', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 17:44:13', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 18:14:14', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 18:44:14', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 19:14:15', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 19:44:15', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 20:14:15', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 20:44:16', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 21:14:16', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 21:44:17', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 22:14:17', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 22:44:18', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 23:14:18', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('18-09-2021 23:44:19', 'dd-mm-yyyy hh24:mi:ss'), 1798);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 00:25:01', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 00:55:01', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 01:25:02', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 01:55:02', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 02:25:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 02:55:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 03:25:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 03:55:04', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 04:25:04', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 04:55:05', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 05:25:05', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 05:55:06', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 06:25:06', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 06:55:06', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 07:25:07', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 07:55:07', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 08:25:08', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 08:55:08', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 09:25:09', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 09:55:09', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 10:25:09', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 10:55:10', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 11:25:10', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 11:55:11', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 12:25:11', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 12:55:12', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 13:25:12', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 13:55:13', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 14:25:13', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 14:55:13', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 15:25:14', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 15:55:14', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 16:25:15', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 16:55:15', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 17:25:16', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 17:55:16', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 18:25:16', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 18:55:17', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 19:25:17', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 19:55:18', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 20:25:18', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 20:55:19', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 21:25:19', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 21:55:19', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 22:25:20', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 22:55:20', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 23:25:21', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('18-09-2021 23:55:21', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 00:01:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 00:31:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 01:01:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 01:31:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 02:01:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 02:31:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 03:01:55', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 03:31:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 04:01:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 04:31:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 05:01:57', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 05:31:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 06:01:58', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 06:31:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 07:01:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 07:31:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 08:02:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 08:32:00', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 09:02:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 09:32:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 10:02:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 10:32:02', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 11:02:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 11:32:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 12:02:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 12:32:04', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 13:02:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 13:32:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 14:02:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 14:32:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 15:02:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 15:32:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 16:02:07', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 16:32:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 17:02:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 17:32:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 18:02:09', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 18:32:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 19:02:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 19:32:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 20:02:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 20:32:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 21:02:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 21:33:12', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 22:03:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 22:33:13', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 23:03:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('18-09-2021 23:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:01:08', 'dd-mm-yyyy hh24:mi:ss'), 3147);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:02:22', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:04:00', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:05:18', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:08:25', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:10:24', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:11:18', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:12:45', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:13:35', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:13:59', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:14:55', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:15:32', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:16:12', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:17:11', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:18:00', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:18:35', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:20:42', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:22:55', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:32:55', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 00:34:56', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:00:05', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:30:06', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:53:39', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:53:45', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:53:47', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:54:03', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 01:55:14', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 02:05:14', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 02:07:17', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 02:32:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 03:02:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 03:32:28', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 04:02:28', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 04:32:28', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 05:02:29', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 05:32:29', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 06:02:30', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 06:32:30', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:02:31', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:32:31', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:34:05', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:34:43', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:35:01', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:35:06', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:35:08', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:35:11', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:38:03', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:39:40', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:04', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:06', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:22', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:23', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:36', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:40:38', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:41:56', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:42:02', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:42:21', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:42:53', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:43:11', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:43:13', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:53:30', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 07:53:53', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:03:53', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:05:49', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:09:55', 'dd-mm-yyyy hh24:mi:ss'), 3148);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:12:34', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:13:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:19:37', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:26:28', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:30:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:43:08', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:53:08', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 08:55:08', 'dd-mm-yyyy hh24:mi:ss'), 3149);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:20:17', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:50:18', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:57:02', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:57:10', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:57:12', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 09:57:43', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 10:07:43', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 10:09:45', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 10:34:54', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 11:04:55', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 11:34:55', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:04:56', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:16:28', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:16:43', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:16:45', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:16:57', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:17:21', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:18:21', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:23:13', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:26:07', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:29:08', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:42:15', 'dd-mm-yyyy hh24:mi:ss'), 3149);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:47:34', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:48:45', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 12:56:12', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 13:06:12', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 13:08:12', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 13:33:21', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:03:22', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:22:55', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:23:03', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:23:58', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:24:09', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:24:31', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:28:59', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:31:50', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:34:07', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:34:44', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:35:51', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:36:09', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:36:51', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:39:26', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:40:50', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:43:09', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:49:51', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:52:52', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:53:09', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 14:56:41', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:06:09', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:07:26', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:08:25', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:08:37', 'dd-mm-yyyy hh24:mi:ss'), 3150);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:09:26', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:09:53', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:10:43', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:12:24', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:14:34', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:16:14', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:16:50', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:18:01', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:18:48', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:20:49', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:21:45', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:25:29', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:27:06', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:27:29', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:28:09', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:28:52', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:29:53', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:32:39', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:34:21', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:35:20', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:35:39', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:40:01', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:41:07', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:44:35', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:48:11', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:49:07', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:49:57', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:50:26', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:51:10', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:51:25', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:51:40', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:52:59', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:53:59', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:54:37', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:55:38', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:56:41', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 15:58:45', 'dd-mm-yyyy hh24:mi:ss'), 3151);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:01:15', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:03:10', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:04:51', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:05:14', 'dd-mm-yyyy hh24:mi:ss'), 3151);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:10:14', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:22:46', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:26:22', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:36:22', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 16:38:23', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:03:32', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:19:07', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:19:41', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:21:34', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:21:51', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:21:56', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:21:58', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:25:57', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:32:49', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:34:29', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:38:49', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:41:25', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:44:33', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:45:47', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:46:17', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:47:03', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:48:44', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:49:28', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:55:00', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:55:44', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 17:56:15', 'dd-mm-yyyy hh24:mi:ss'), 3152);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:03:06', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:03:42', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:07:22', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:09:47', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:13:35', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:18:40', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:21:13', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:21:52', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:24:17', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:26:21', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:29:09', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:30:49', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:33:38', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:36:22', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:36:52', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:43:12', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:43:27', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:44:59', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:45:33', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:48:22', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:49:00', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:54:36', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:55:42', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:59:12', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 18:59:51', 'dd-mm-yyyy hh24:mi:ss'), 3153);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:00:55', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:01:38', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:02:10', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:02:53', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:03:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:03:56', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:06:54', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:08:00', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:15:18', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:15:59', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:16:33', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:17:23', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:17:54', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:19:19', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:20:50', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:37:03', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:39:04', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:46:50', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:46:56', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:46:58', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:48:11', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:49:39', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:51:12', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:51:40', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 19:53:38', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:00:58', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:01:05', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:01:07', 'dd-mm-yyyy hh24:mi:ss'), 3154);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:02:11', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:04:23', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:05:25', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:06:38', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:07:37', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:07:59', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:08:18', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:09:04', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:10:37', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:13:23', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:14:37', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:18:53', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:19:53', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:21:19', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:22:41', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:24:42', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:26:06', 'dd-mm-yyyy hh24:mi:ss'), 3154);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:27:25', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:28:22', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:29:17', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:30:29', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:31:12', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:32:08', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:32:47', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:33:09', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:33:57', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:34:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:35:05', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:35:35', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:35:49', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:38:15', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:39:35', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:40:42', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:43:29', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:46:39', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:47:19', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:48:38', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:49:40', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:51:08', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:55:36', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:59:34', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:59:41', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 20:59:43', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:01:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:02:20', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:03:05', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:14:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:17:31', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:18:13', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:19:44', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:22:01', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:22:36', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:23:06', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:23:47', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:24:18', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:24:35', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:24:49', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:25:41', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:26:34', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:27:41', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:28:08', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:28:55', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:30:29', 'dd-mm-yyyy hh24:mi:ss'), 3155);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:32:17', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:32:44', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:33:11', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:34:26', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:34:28', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:35:12', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:36:36', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:37:42', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:38:12', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:38:37', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:40:09', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:40:50', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:42:27', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:42:48', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:43:10', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:44:00', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:44:48', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:46:59', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:48:28', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:49:15', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:49:27', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:49:36', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:50:39', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:51:12', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:52:11', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 21:53:49', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 22:03:49', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 22:05:50', 'dd-mm-yyyy hh24:mi:ss'), 3156);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 22:31:00', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:01:00', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:31:01', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:58:09', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:58:23', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:58:25', 'dd-mm-yyyy hh24:mi:ss'), 3156);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('18-09-2021 23:59:02', 'dd-mm-yyyy hh24:mi:ss'), 3156);
commit;
prompt 2307 records loaded
set feedback on
set define on
prompt Done.
