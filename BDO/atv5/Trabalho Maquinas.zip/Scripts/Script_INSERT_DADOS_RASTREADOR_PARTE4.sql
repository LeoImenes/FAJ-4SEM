﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 00:01:02', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 00:31:02', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 01:01:03', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 01:31:03', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 02:01:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 02:31:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 03:01:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 03:31:05', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 04:01:05', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 04:31:06', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 05:01:06', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 05:31:07', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 06:01:07', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 06:31:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 07:01:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 07:31:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 08:01:09', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 08:31:09', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 09:01:10', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 09:31:10', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 10:01:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 10:31:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 11:01:11', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 11:31:12', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 12:01:12', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 12:31:13', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 13:01:13', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 13:31:13', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 14:01:14', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 14:31:14', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 15:01:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 15:31:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 16:01:16', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 16:31:16', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 17:01:17', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 17:31:17', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 18:02:33', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 18:32:33', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 19:02:33', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 19:32:34', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 20:02:34', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 20:32:35', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 21:02:35', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 21:32:36', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 22:02:36', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 22:32:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 23:02:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('16-09-2021 23:32:38', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 00:15:14', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 00:45:14', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 01:15:14', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 01:45:15', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 02:15:15', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 02:45:16', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 03:15:16', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 03:45:17', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 04:15:17', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 04:45:18', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 05:15:18', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 05:45:18', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 06:15:19', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 06:45:19', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:15:20', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:27:25', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:28:02', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:28:16', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:28:21', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:28:23', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:32:37', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:34:44', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:37:49', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:38:12', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:38:14', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:38:42', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:38:44', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:40:11', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:40:14', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:40:16', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:40:47', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:41:13', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:41:21', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:41:23', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:42:02', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:46:48', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:46:55', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:46:57', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:47:36', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 07:50:44', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:00:44', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:02:36', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:03:22', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:08:49', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:17:36', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:27:36', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:28:15', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:29:28', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:29:38', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:29:40', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:32:36', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:34:24', 'dd-mm-yyyy hh24:mi:ss'), 1315);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:39:51', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:39:59', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:40:01', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:43:10', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:43:26', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:50:12', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:50:24', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:50:26', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 08:57:41', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:07:41', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:09:43', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:14:20', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:14:36', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:23:17', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:23:25', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:23:27', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:24:38', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:32:36', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:35:38', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:36:08', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:37:47', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:37:54', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:37:56', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:42:18', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:46:39', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:47:36', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:47:57', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:57:57', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 09:59:58', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:03:55', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:04:03', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:04:05', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:11:43', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:17:36', 'dd-mm-yyyy hh24:mi:ss'), 1315);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:27:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:29:47', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:36:21', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:36:34', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:36:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:46:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:47:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:49:07', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:56:40', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 10:56:51', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:02:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:07:45', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:08:31', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:08:37', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:09:40', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:09:49', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:09:51', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:11:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:12:55', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:13:02', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:13:04', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:13:39', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:17:29', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:17:40', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:17:42', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:19:56', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:27:54', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:28:09', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:28:11', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:32:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:42:36', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:46:49', 'dd-mm-yyyy hh24:mi:ss'), 1316);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:47:36', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:47:44', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:49:21', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 11:59:21', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 12:01:22', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 12:26:31', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 12:56:32', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:13:02', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:13:22', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:13:24', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:16:28', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:26:28', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:28:30', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 13:53:39', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 14:23:40', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 14:53:40', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:15:06', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:15:18', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:15:20', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:17:36', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:20:03', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:30:03', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:32:05', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 15:57:15', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:01:35', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:02:19', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:02:38', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:02:42', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:02:44', 'dd-mm-yyyy hh24:mi:ss'), 1317);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:02:47', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:04:43', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:14:43', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:16:45', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:30:08', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:30:17', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:30:19', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:31:46', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:41:46', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 16:43:49', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 17:08:58', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 17:38:59', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 18:08:59', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 18:39:00', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 19:09:00', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 19:39:01', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 20:09:01', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 20:39:02', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 21:09:02', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 21:39:03', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 22:09:03', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 22:39:04', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 23:09:04', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('16-09-2021 23:39:04', 'dd-mm-yyyy hh24:mi:ss'), 1317);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 00:21:29', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 00:51:30', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 01:21:30', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 01:51:31', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 02:21:31', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 02:51:32', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 03:21:32', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 03:51:33', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 04:21:33', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 04:51:33', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 05:21:34', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 05:51:34', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 06:21:35', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 06:51:35', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:08:34', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:09:16', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:09:37', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:09:42', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:09:44', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:09:48', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:19:48', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:22:07', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:22:15', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:22:17', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:23:37', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:33:37', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:35:40', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:45:32', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:45:41', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:45:43', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:46:14', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:56:14', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:56:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:59:13', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:59:23', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:59:25', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 07:59:57', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:00:01', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:00:03', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:01:13', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:11:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:16:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:26:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:31:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:41:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:46:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 08:56:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:06:13', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:08:16', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:33:26', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:40:30', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:40:37', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:40:39', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:46:12', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:46:36', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:56:36', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 09:58:39', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:21:28', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:21:41', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:21:43', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:22:02', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:32:02', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:34:05', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 10:59:15', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 11:29:15', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 11:54:58', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 11:55:09', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 11:55:11', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 11:55:58', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:04:36', 'dd-mm-yyyy hh24:mi:ss'), 1473);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:04:43', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:04:45', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:08:47', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:10:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:10:40', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:10:42', 'dd-mm-yyyy hh24:mi:ss'), 1474);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:11:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:21:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:23:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:34:09', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:34:21', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:34:23', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:42:39', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:52:39', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 12:54:42', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:19:51', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:49:52', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:57:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:57:20', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:57:22', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 13:57:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:07:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:09:52', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:35:02', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:42:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:42:57', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:42:59', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:46:11', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:49:28', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:52:05', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:52:14', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 14:52:16', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:01:11', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:05:23', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:06:58', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:07:07', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:07:09', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:10:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:20:35', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:22:38', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 15:47:47', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 16:17:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 16:47:48', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:17:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:47:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:54:58', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:55:27', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:55:44', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:55:49', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:55:51', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 17:57:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 18:07:15', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 18:09:18', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 18:34:28', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 19:04:28', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 19:34:28', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 20:04:29', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 20:34:29', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 21:04:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 21:34:30', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 22:04:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 22:34:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 23:04:31', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('16-09-2021 23:34:32', 'dd-mm-yyyy hh24:mi:ss'), 1474);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 00:25:31', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 00:55:32', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 01:25:32', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 01:55:32', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 02:25:33', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 02:55:34', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 03:25:34', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 03:55:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 04:25:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 04:55:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 05:25:36', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 05:55:36', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:25:37', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:52:45', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:52:50', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:52:51', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:53:03', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:53:05', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:54:10', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:54:12', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 06:54:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:04:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:06:37', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:26:42', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:27:49', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:28:34', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:28:38', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:28:40', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:28:43', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:38:43', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:39:06', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:43:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:45:52', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:55:52', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 07:57:54', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:01:27', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:01:38', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:01:40', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:11:40', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:12:15', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:13:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:19:24', 'dd-mm-yyyy hh24:mi:ss'), 941);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:29:24', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:29:58', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:30:10', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:30:12', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:31:03', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:38:17', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:38:29', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:38:31', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:43:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:47:18', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:55:04', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:55:18', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:55:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 08:58:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:08:20', 'dd-mm-yyyy hh24:mi:ss'), 941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:13:20', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:15:25', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:18:12', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:20:27', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:20:35', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:20:37', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:25:18', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:28:20', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:32:55', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:42:29', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:43:05', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:43:58', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:44:07', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:44:09', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:44:11', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:44:58', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:54:58', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 09:56:57', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:08:29', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:08:39', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:08:41', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:09:12', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:19:12', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:21:14', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 10:46:24', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 11:16:24', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 11:46:25', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 12:16:25', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 12:46:26', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:16:26', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:46:26', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:57:55', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:58:06', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:58:08', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 13:58:20', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:04:21', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:11:23', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:16:17', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:16:27', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:16:29', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:22:59', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:32:59', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:35:01', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:35:59', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:36:09', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:36:11', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:37:41', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:47:41', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:49:42', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:56:34', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:56:53', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:56:55', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 14:58:20', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:04:11', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:11:33', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:11:47', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:13:20', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:17:15', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:23:10', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:23:19', 'dd-mm-yyyy hh24:mi:ss'), 942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:28:18', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:38:18', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:43:18', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:53:18', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:18', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:27', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:43', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:45', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:47', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 15:58:51', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:08:51', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:10:53', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:17:12', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:17:20', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:17:22', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:19:26', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:20:20', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:20:29', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:20:31', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:20:51', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:30:51', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:32:53', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 16:58:02', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 17:28:03', 'dd-mm-yyyy hh24:mi:ss'), 943);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 17:58:03', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 18:28:04', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 18:58:04', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 19:28:05', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 19:58:05', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 20:16:21', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 20:16:34', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 20:26:34', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 20:51:43', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 21:21:44', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 21:51:44', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 22:21:45', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 22:51:45', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 23:21:46', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('16-09-2021 23:51:46', 'dd-mm-yyyy hh24:mi:ss'), 943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 00:28:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 00:58:55', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 01:28:55', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 01:58:56', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 02:28:56', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 02:58:57', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 03:28:57', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 03:58:59', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 04:28:59', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 04:59:00', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 05:29:00', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 05:59:01', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 06:29:01', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 06:59:01', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:29:02', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:40:16', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:41:18', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:41:50', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:41:55', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:41:57', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:48:17', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:51:27', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:51:51', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:51:53', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:52:34', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:52:38', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:52:47', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:52:49', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:54:26', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:54:30', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:54:32', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:55:14', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:55:38', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:55:45', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:55:47', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 07:58:13', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:08:13', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:10:14', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:11:14', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:11:24', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:11:26', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:13:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:22:59', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:23:06', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:23:08', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:25:07', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:28:35', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:28:42', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:28:44', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:28:53', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:32:53', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:32:59', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:33:01', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:45:57', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:48:08', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:48:09', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:48:17', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 08:51:54', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:01:54', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:02:24', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:02:42', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:02:44', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:15:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:40:33', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:50:33', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:51:32', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:52:16', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 09:52:18', 'dd-mm-yyyy hh24:mi:ss'), 2041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:02:21', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:15:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 10:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 11:00:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 11:00:17', 'dd-mm-yyyy hh24:mi:ss'), 2043);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 11:10:17', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 11:12:19', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 11:37:28', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:07:28', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:08:44', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:08:51', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:08:53', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:12:14', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:22:14', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:24:15', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 12:49:24', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:19:25', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:29:43', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:29:50', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:29:52', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 13:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:00:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:14:06', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:24:06', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:26:07', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:40:45', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:41:44', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:41:46', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:47:38', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:57:13', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:57:25', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 14:57:27', 'dd-mm-yyyy hh24:mi:ss'), 2043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:07:22', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:17:22', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:19:00', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:19:09', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:19:11', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:44:42', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:45:38', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:45:44', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:45:46', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:47:04', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 15:59:29', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 16:03:11', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 16:13:11', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 16:15:12', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 16:40:21', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:10:21', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:14:02', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:14:08', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:14:10', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:20:08', 'dd-mm-yyyy hh24:mi:ss'), 2044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:30:08', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:49:30', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 17:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:00:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:15:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:36:01', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:46:01', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:46:28', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 18:53:09', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 19:03:09', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 19:05:11', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 19:30:20', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 20:00:20', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 20:30:21', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 21:00:21', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 21:30:22', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 22:00:22', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 22:30:23', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 23:00:23', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('16-09-2021 23:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 00:28:20', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 00:58:21', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 01:28:21', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 01:58:22', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 02:28:22', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 02:58:23', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 03:28:23', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 03:58:24', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 04:28:24', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 04:58:24', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 05:28:25', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 05:58:25', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 06:28:26', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 06:58:26', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 07:28:27', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 07:58:27', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 08:28:27', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 08:58:28', 'dd-mm-yyyy hh24:mi:ss'), 1427);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 09:28:28', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 09:58:29', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 10:28:29', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 10:58:30', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 11:28:30', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 11:58:30', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 12:28:31', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:05:28', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:05:47', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:19:28', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:20:15', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:22:36', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:33:52', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:37:48', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:40:47', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:49:27', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:49:45', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 00:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:06:57', 'dd-mm-yyyy hh24:mi:ss'), 4888);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:12:09', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:22:09', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:27:41', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:34:03', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:36:51', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:39:52', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:48:22', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:48:28', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 01:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:01:16', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:03:18', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:13:18', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:15:11', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:15:39', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:15:56', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:16:00', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:16:02', 'dd-mm-yyyy hh24:mi:ss'), 4889);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:26:02', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:30:40', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:33:18', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:33:37', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:34:00', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:39:51', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:45:09', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:45:51', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:47:40', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:52:58', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:54:43', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:58:52', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 02:59:35', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:03:13', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:05:33', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:08:05', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:11:47', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:13:25', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:14:22', 'dd-mm-yyyy hh24:mi:ss'), 4890);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:22:39', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:22:45', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:30:49', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:40:49', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:51:57', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 03:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:01:26', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:03:11', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:10:11', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:20:11', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:22:13', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 04:47:23', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 05:17:23', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 05:47:24', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 06:17:24', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 06:47:24', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:17:25', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:18:08', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:18:33', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:20:36', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:22:24', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:22:43', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:22:47', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:22:50', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:24:38', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:27:43', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:28:06', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:28:08', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:28:46', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:28:48', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:30:22', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:30:26', 'dd-mm-yyyy hh24:mi:ss'), 4891);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:30:28', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:30:58', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:31:56', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:32:16', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:32:18', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:32:26', 'dd-mm-yyyy hh24:mi:ss'), 4891);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:34:37', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:38:35', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:38:45', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:38:47', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:41:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:51:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 07:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:04:22', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:10:43', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:10:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:10:58', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:11:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:21:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:24:36', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:26:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:36:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:41:56', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:43:46', 'dd-mm-yyyy hh24:mi:ss'), 4892);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:53:46', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 08:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:06:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:07:07', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:09:11', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:09:42', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:09:44', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:11:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:21:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:26:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:36:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:40:55', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:41:56', 'dd-mm-yyyy hh24:mi:ss'), 4893);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:51:56', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 09:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:00:41', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:10:41', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:11:56', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:14:12', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:15:11', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:25:11', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:26:56', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:29:32', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:39:32', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:41:56', 'dd-mm-yyyy hh24:mi:ss'), 4894);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:51:56', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:59:31', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 10:59:34', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 12:58:31', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 13:28:32', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 13:58:32', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 14:28:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 14:58:33', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 15:28:34', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 15:58:34', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 16:28:34', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 16:58:35', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 17:28:35', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 17:58:36', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 18:28:36', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 18:58:37', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 19:28:37', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 19:58:38', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 20:28:38', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 20:58:38', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 21:28:39', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 21:58:39', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 22:28:40', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 22:58:40', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 23:28:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('16-09-2021 23:58:41', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:39:13', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 00:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:01:37', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:23:48', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:33:48', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 01:35:51', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 02:01:01', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 02:31:01', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 03:01:02', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 03:31:02', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 04:01:03', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 04:31:03', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 05:01:03', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 05:31:04', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 06:01:04', 'dd-mm-yyyy hh24:mi:ss'), 5023);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 06:31:05', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:01:05', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:18:01', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:18:21', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:18:26', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:18:28', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:25:02', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:31:51', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:34:41', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:35:04', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:35:06', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:35:32', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:35:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:36:58', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:01', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:03', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:27', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:36', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:46', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:37:48', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 07:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 08:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 09:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5025);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:49:24', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:56:52', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:57:00', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 10:57:02', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5026);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 11:52:13', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:03:46', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:07:05', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:07:19', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:07:21', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5027);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:25:57', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:32:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:32:36', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:37:03', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 12:54:29', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 13:04:29', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 13:06:31', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 13:31:40', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:00:11', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:00:31', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:00:33', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5028);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:49:19', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:53:53', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:53:59', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 14:54:01', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:00:18', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:18:06', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:28:06', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:32:32', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:37:03', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:47:03', 'dd-mm-yyyy hh24:mi:ss'), 5029);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:49:05', 'dd-mm-yyyy hh24:mi:ss'), 5029);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:50:29', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:50:38', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:50:40', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 15:59:32', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:06:11', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:06:17', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:06:19', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:07:42', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:09:23', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:09:33', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:09:35', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:24:57', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:34:57', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:37:00', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:48:44', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:49:09', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:49:22', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:49:27', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:49:29', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 16:59:29', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:18:21', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:18:33', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:18:35', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:21:16', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:22:47', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:22:54', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:22:56', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:27:41', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:27:43', 'dd-mm-yyyy hh24:mi:ss'), 5030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:40:05', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:49:38', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 17:59:38', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:18:47', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:26:18', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:31:07', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:31:16', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:31:18', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:41:54', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:51:54', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 18:53:56', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:12:41', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:12:55', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:12:57', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:22:12', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:26:43', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:31:37', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:32:02', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:32:04', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:42:07', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:44:19', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:47:10', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:50:16', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:50:24', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 19:50:26', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:00:26', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:05:57', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:10:48', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:15:18', 'dd-mm-yyyy hh24:mi:ss'), 5032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:15:52', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:16:11', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:16:16', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:16:18', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:30:29', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:31:36', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:35:01', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:45:01', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 20:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:03:21', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:13:21', 'dd-mm-yyyy hh24:mi:ss'), 5033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:43:17', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:53:17', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 21:55:19', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 22:20:28', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 22:50:29', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 22:59:37', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:00:06', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:00:20', 'dd-mm-yyyy hh24:mi:ss'), 5034);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:00:24', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:00:26', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5034);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('16-09-2021 23:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:24:32', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:42:19', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:52:19', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 00:56:48', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:01:50', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:01:52', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:22:20', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:32:20', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:34:20', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:53:02', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:53:10', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:53:12', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 01:56:48', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:06:48', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:16:22', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:26:22', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:28:22', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 02:53:31', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 03:23:32', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 03:53:32', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 04:23:32', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 04:53:33', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 05:23:33', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 05:53:34', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 06:23:34', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 06:53:35', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:23:32', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:24:46', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:25:15', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:25:19', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:25:21', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3839);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:41:13', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:42:03', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:43:41', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:43:45', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:43:47', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:44:25', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:44:53', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:45:08', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:45:10', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:55:10', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 07:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:09:09', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3840);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:33:44', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:41:50', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:47:46', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 08:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:30:47', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:37:28', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:37:40', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:37:42', 'dd-mm-yyyy hh24:mi:ss'), 3841);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 09:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:17:46', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:27:46', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:29:02', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:29:41', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:29:43', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:39:43', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3842);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:06:21', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:41:58', 'dd-mm-yyyy hh24:mi:ss'), 3843);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:51:58', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:49:03', 'dd-mm-yyyy hh24:mi:ss'), 3844);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 12:54:08', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 13:04:08', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 13:06:10', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 13:31:20', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:01:20', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:15:59', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:16:09', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:16:11', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:26:11', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:26:15', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 14:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:09:17', 'dd-mm-yyyy hh24:mi:ss'), 3845);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:13:15', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:23:15', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:25:17', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:50:26', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:54:20', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:55:09', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:55:26', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:55:31', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:55:33', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 16:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:02:50', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:10:52', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:11:12', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:11:14', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:11:16', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:13:27', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:13:35', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:13:37', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:23:37', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 17:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:47:16', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:53:38', 'dd-mm-yyyy hh24:mi:ss'), 3848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 18:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:40:59', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:46:28', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:46:39', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:46:41', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:56:41', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 19:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 20:00:42', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 20:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 20:12:43', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 20:37:52', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 21:07:53', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 21:37:53', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:07:53', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:37:54', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:44:11', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:44:23', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:44:25', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:54:25', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 22:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:06:38', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:08:29', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:08:31', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('16-09-2021 23:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:03:24', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:09:19', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:12:39', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:12:48', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:12:50', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:12:51', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:16:02', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:20:28', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:20:39', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:20:41', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:26:15', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:26:56', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:35:31', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:41:56', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:51:56', 'dd-mm-yyyy hh24:mi:ss'), 4895);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 11:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:06:16', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:08:08', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:09:04', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:19:04', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:21:06', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:41:13', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:41:48', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:42:07', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:42:09', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:52:09', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 12:58:47', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:08:47', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:18:28', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:28:28', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:30:30', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:31:33', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:32:03', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:32:18', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:32:23', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:32:25', 'dd-mm-yyyy hh24:mi:ss'), 4896);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:39:13', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:41:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:45:11', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:55:11', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 13:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:03:36', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:21:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:36:55', 'dd-mm-yyyy hh24:mi:ss'), 4897);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:41:55', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:43:09', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:53:09', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 14:56:56', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:06:56', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:21:28', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:27:55', 'dd-mm-yyyy hh24:mi:ss'), 4898);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:37:55', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:39:59', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:42:53', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:43:00', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:43:02', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:44:58', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:47:20', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:47:28', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:47:30', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:53:22', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 15:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:06:57', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:13:01', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:23:01', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:25:02', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:50:11', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:53:01', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:54:43', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:55:14', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:55:18', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:55:20', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:56:09', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 16:58:45', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:07:59', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:08:13', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:08:15', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:08:37', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:14:17', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:15:42', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:15:44', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:16:30', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:17:43', 'dd-mm-yyyy hh24:mi:ss'), 4899);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:17:51', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:17:53', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:27:27', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:37:27', 'dd-mm-yyyy hh24:mi:ss'), 4899);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:41:55', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:51:55', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 17:57:59', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:07:59', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:11:55', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:12:42', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:14:42', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:15:44', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:17:14', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:17:28', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:17:30', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:20:18', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:22:41', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:25:12', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:36:07', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:37:08', 'dd-mm-yyyy hh24:mi:ss'), 4900);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:41:55', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:51:55', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:53:51', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 18:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:04:13', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:18:34', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:25:25', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:36:55', 'dd-mm-yyyy hh24:mi:ss'), 4901);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:41:55', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:43:06', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:47:33', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:47:44', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:47:46', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:48:40', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:56:10', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 19:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:01:25', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:03:39', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:21:54', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:36:55', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:38:05', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:41:31', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:41:54', 'dd-mm-yyyy hh24:mi:ss'), 4902);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:47:13', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:49:34', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:50:32', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:55:04', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 20:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:00:35', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:00:37', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:01:07', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:01:40', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:05:47', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:07:58', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:13:52', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:15:06', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:18:30', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:26:54', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:32:35', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:34:48', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:36:15', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:41:54', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:43:06', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:44:27', 'dd-mm-yyyy hh24:mi:ss'), 4903);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:45:48', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:54:40', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:54:42', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 21:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:02:14', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:04:05', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:04:56', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:21:33', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:25:06', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:26:51', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:26:54', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:31:51', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:33:04', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:36:00', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:41:54', 'dd-mm-yyyy hh24:mi:ss'), 4904);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:45:47', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:52:25', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:55:37', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:55:53', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:56:54', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 22:57:31', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:00:38', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:01:42', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:04:44', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:05:35', 'dd-mm-yyyy hh24:mi:ss'), 4905);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:11:54', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:12:02', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:12:12', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:15:07', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:16:26', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:26:13', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:36:13', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('16-09-2021 23:38:15', 'dd-mm-yyyy hh24:mi:ss'), 4905);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 00:07:27', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 00:37:28', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:07:28', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:24:08', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:24:21', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:24:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:48:36', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 01:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:00:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:05:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:08:48', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:18:48', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:20:50', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 02:45:59', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:09:56', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:10:09', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:10:11', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:20:11', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:30:23', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:46:12', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:56:12', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 03:58:14', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 04:23:24', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 04:53:24', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 05:23:25', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 05:53:26', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 06:23:26', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 06:53:23', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 06:53:39', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:03:39', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:05:39', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:23:00', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:25:31', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:25:46', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:25:50', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:25:52', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:34:22', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:38:34', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:38:43', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:38:45', 'dd-mm-yyyy hh24:mi:ss'), 2090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:47:08', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:57:08', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 07:59:10', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 08:24:19', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 08:54:20', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:24:20', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:25:00', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:25:07', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:25:09', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:40:01', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:50:01', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:51:41', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:51:49', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 09:51:51', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:01:51', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:02:25', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:07:15', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:07:27', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:07:29', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:14:49', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:24:49', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:26:52', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 10:52:02', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:07:21', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:07:28', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:07:30', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:12:38', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:20:20', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:30:20', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:32:22', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:49:16', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:49:24', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:49:26', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 11:50:28', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 12:00:28', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 12:02:30', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 12:27:40', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 12:57:40', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 13:27:40', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 13:57:41', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:27:41', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:33:15', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:33:24', 'dd-mm-yyyy hh24:mi:ss'), 2091);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:33:26', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:44:48', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:49:13', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:49:21', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:49:23', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:54:12', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:56:59', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:57:07', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:57:09', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 14:59:33', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 15:04:34', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 15:14:34', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 15:16:35', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 15:41:44', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:11:45', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:41:45', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:42:36', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:42:44', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:42:45', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:43:16', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:53:16', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 16:55:18', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 17:20:28', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 17:50:28', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 18:20:29', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 18:50:29', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 19:20:29', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 19:50:30', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 20:20:30', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 20:50:31', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 21:20:31', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 21:50:32', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 22:20:32', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 22:50:33', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 23:20:33', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('16-09-2021 23:50:33', 'dd-mm-yyyy hh24:mi:ss'), 2092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 00:02:51', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 00:04:52', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 00:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 01:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 01:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 01:56:28', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 01:56:36', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 01:56:38', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:00:59', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:29:18', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:35:06', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:45:06', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:55:48', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 02:58:02', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:02:26', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:02:33', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:02:35', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:09:08', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:19:08', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:19:32', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4051);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:40:22', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:50:20', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:50:28', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:50:30', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 03:50:32', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:00:35', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:01:41', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:10:35', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:10:44', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:10:46', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:41:41', 'dd-mm-yyyy hh24:mi:ss'), 4052);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 04:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:06:41', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:16:36', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:42:40', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:52:40', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:54:43', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:57:51', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:58:01', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 05:58:03', 'dd-mm-yyyy hh24:mi:ss'), 4053);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:13:42', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:31:28', 'dd-mm-yyyy hh24:mi:ss'), 4054);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:39:06', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:42:18', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:52:18', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 06:54:20', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:19:30', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:20:34', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:22:35', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:23:04', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:23:09', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:23:11', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:26:33', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:31:17', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:31:41', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:31:43', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:32:18', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:32:20', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:33:47', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:33:51', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:33:53', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:34:21', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:35:35', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:35:42', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:35:44', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:35:46', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:43:12', 'dd-mm-yyyy hh24:mi:ss'), 4054);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 07:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:21:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:31:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:32:24', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:37:10', 'dd-mm-yyyy hh24:mi:ss'), 4055);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:47:10', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 08:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:09:54', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:11:36', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:16:55', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:17:44', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:17:46', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:23:51', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:32:05', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:45:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:50:55', 'dd-mm-yyyy hh24:mi:ss'), 4056);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 09:59:40', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:10:31', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:16:43', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:22:16', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:28:09', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:45:01', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:46:51', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 10:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4057);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:06:37', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:09:24', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:16:12', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:16:25', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:16:27', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:33:39', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:38:26', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:48:26', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 11:50:28', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 12:15:37', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 12:45:37', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 12:56:36', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 12:56:42', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 12:56:44', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:15:39', 'dd-mm-yyyy hh24:mi:ss'), 4058);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:15:45', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:25:45', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:27:49', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:30:39', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:30:46', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:30:48', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:41:22', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:48:30', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 13:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:04:06', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4059);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:32:12', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:36:16', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:46:16', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:48:08', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 14:58:08', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:00:09', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:00:13', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:00:29', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:00:31', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:03:48', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:15:31', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:20:30', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:30:30', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4060);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:45:01', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:46:49', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 15:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:14:10', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:17:14', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:27:14', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:29:16', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:50:22', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:54:49', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:55:07', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:55:11', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:55:13', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 16:59:05', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:08:25', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:08:38', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:08:40', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:09:08', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:17:41', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:17:50', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:17:52', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:18:59', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:20:21', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:20:35', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:20:37', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:20:39', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:30:39', 'dd-mm-yyyy hh24:mi:ss'), 4061);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:40:54', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:49:28', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 17:58:26', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:17:16', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:22:54', 'dd-mm-yyyy hh24:mi:ss'), 4062);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:32:54', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:38:53', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:46:35', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:56:35', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:58:04', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:58:29', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:58:43', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:58:48', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 18:58:50', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:12:30', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:24:26', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:31:37', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:43:35', 'dd-mm-yyyy hh24:mi:ss'), 4063);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:44:26', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:54:26', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:56:28', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:56:33', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:56:47', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 00:16:54', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 00:46:54', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 01:16:55', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 01:46:55', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 02:16:56', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 02:46:56', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 03:16:57', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 03:46:57', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 04:16:57', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 04:46:58', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 05:16:58', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 05:46:59', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 06:16:59', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 06:47:00', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 07:17:00', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 07:47:00', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 08:17:01', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 08:47:01', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 09:17:02', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 09:47:02', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:17:03', 'dd-mm-yyyy hh24:mi:ss'), 2977);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:47:03', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:49:25', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:50:17', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:51:18', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:51:22', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:51:24', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 10:54:44', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:04:44', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:06:46', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:09:23', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:09:35', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:09:37', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:19:37', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:20:12', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:30:12', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:33:14', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:35:12', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:45:12', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:50:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 11:53:38', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:02:46', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:15:01', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:15:15', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:20:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:30:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:31:03', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:35:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:45:12', 'dd-mm-yyyy hh24:mi:ss'), 2978);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:50:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 12:53:28', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 13:03:28', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 13:05:29', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 13:30:38', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 13:54:57', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:03:09', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:03:11', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:15:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:20:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:30:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:34:18', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:35:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:45:12', 'dd-mm-yyyy hh24:mi:ss'), 2979);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:49:57', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 14:50:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:00:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:05:15', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:15:15', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:20:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:30:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:35:12', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:46:49', 'dd-mm-yyyy hh24:mi:ss'), 2980);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:50:12', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:51:22', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 15:55:21', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 16:05:21', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 16:07:24', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 16:32:33', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 16:52:50', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 16:54:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 17:04:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 17:05:59', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 17:31:08', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 18:01:09', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 18:31:09', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 19:01:10', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 19:31:10', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 20:01:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 20:31:11', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 21:01:12', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 21:31:12', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 22:01:13', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 22:31:13', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 23:01:13', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('16-09-2021 23:31:14', 'dd-mm-yyyy hh24:mi:ss'), 2981);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 19:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:11:35', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:23:53', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:33:53', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:41:23', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:50:55', 'dd-mm-yyyy hh24:mi:ss'), 4064);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 20:59:19', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:15:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:16:17', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:24:36', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:34:31', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4065);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 21:50:34', 'dd-mm-yyyy hh24:mi:ss'), 4065);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:00:34', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:05:09', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:11:25', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:16:17', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:20:00', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:25:40', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:33:47', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:35:00', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:39:54', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:49:54', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 22:50:00', 'dd-mm-yyyy hh24:mi:ss'), 4066);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:00:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:05:00', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:06:42', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:07:12', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:17:12', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:19:14', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('16-09-2021 23:44:23', 'dd-mm-yyyy hh24:mi:ss'), 4067);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:00:05', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:02:43', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:04:56', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:09:16', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:09:21', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:09:46', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:13:11', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:18:06', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:21:00', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:21:15', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:21:23', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:24:46', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:27:34', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:30:41', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:31:28', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:31:47', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:32:53', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:39:46', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:39:55', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:43:29', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:46:03', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:46:05', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 00:52:37', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:02:37', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:04:38', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:29:47', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:46:17', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:46:25', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:46:27', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:50:47', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:55:30', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:55:37', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:55:39', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:55:41', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 01:59:54', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 02:03:49', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 02:05:18', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 02:15:18', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 02:17:19', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 02:42:28', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 03:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 03:42:29', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 04:12:30', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 04:42:30', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 05:12:31', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 05:42:31', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 06:12:32', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 06:42:32', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:10:11', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:11:08', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:11:27', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:15:09', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:19:23', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:19:48', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:19:51', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:20:18', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:20:34', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:20:36', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:22:01', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:22:05', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:22:07', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:23:47', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:23:57', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:23:59', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:24:46', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:32:04', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:32:16', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:33:00', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:34:11', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:35:18', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:35:48', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:39:46', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:41:12', 'dd-mm-yyyy hh24:mi:ss'), 5127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:45:20', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:55:20', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:55:48', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:55:56', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:55:58', 'dd-mm-yyyy hh24:mi:ss'), 5128);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:58:15', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:58:21', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:58:43', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:59:28', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:59:43', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 07:59:58', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:00:30', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:01:25', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:40', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:43', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:45', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:48', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:51', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:54', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:05:58', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:00', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:03', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:05', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:07', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:09', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:11', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:15', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:17', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:06:19', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:09:46', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:14:19', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:14:43', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:16:26', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:17:16', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:21:35', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:22:24', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:24:46', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:26:12', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:26:42', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:36:42', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:37:16', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:39:27', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:39:46', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:51:15', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:51:39', 'dd-mm-yyyy hh24:mi:ss'), 5128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:52:52', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:54:43', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 08:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:04:47', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:05:50', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:10:49', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:11:20', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:15:09', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:17:09', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:18:34', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:18:59', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:25:52', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:26:00', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:26:02', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:27:07', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:30:58', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:31:05', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:31:07', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:31:17', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:34:26', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:37:58', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:38:15', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:43:32', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:47:47', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:49:44', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:49:52', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:49:54', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:50:08', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:52:48', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:54:46', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 09:57:50', 'dd-mm-yyyy hh24:mi:ss'), 5129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:06:31', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:09:35', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:09:46', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:14:36', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:14:50', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:19:30', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:22:17', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:24:06', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:24:46', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:25:59', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:28:52', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:29:15', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:34:42', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:38:27', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:40:29', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:41:58', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:42:31', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:43:28', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:50:02', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:52:25', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:54:52', 'dd-mm-yyyy hh24:mi:ss'), 5130);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:56:45', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:57:51', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 10:58:19', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:01:45', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:01:54', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:01:56', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:02:03', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:05:09', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:11:48', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:11:56', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:11:58', 'dd-mm-yyyy hh24:mi:ss'), 5130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:07', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:12', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:41', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:52', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:55', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:19:58', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:00', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:03', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:06', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:13', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:16', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:22', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:24', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:27', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:30', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:33', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:38', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:41', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:44', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:20:52', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:11', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:13', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:16', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:18', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:22', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:25', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:27', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:30', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:32', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:34', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:37', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:39', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:42', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:44', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:51', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:21:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:00', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:02', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:05', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:07', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:09', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:12', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:14', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:18', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:20', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:22', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:24', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:27', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:32', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:34', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:39', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:41', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:44', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:48', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:22:59', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:03', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:05', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:12', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:15', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:20', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:22', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:24', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:27', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:29', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:31', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:34', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:38', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:40', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:44', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:48', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:53', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:55', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:57', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:23:59', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:02', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:06', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:13', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:15', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:19', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:21', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:24', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:27', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:31', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:34', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:38', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:40', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:24:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:00', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:02', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:07', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:14', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:16', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:20', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:23', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:26', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:28', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:32', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:34', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:40', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:44', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:53', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:55', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:25:57', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:00', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:02', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:05', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:13', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:16', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:18', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:20', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:23', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:26', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:28', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:30', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:37', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:39', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:42', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:52', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:57', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:26:59', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:28', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:35', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:37', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:42', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:49', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:51', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:27:59', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:01', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:03', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:05', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:08', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:31', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:39', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:41', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:28:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:31:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:32:35', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:33:23', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:41:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:41:50', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:41:55', 'dd-mm-yyyy hh24:mi:ss'), 5131);
commit;
prompt 2400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:01', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:04', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:07', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:14', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:17', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:19', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:22', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:26', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:42:28', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:45:23', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:46:38', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:48:41', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:48:54', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:48:56', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:52:04', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:52:07', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:52:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:52:52', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:53:28', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:54:25', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:56:12', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:56:17', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:56:29', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 11:57:52', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:01:30', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:06:36', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:08:20', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:08:24', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:08:33', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:10:06', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:10:46', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:11:25', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:14:23', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:16:10', 'dd-mm-yyyy hh24:mi:ss'), 5131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:17:34', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:19:13', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:19:18', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:22:15', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:22:58', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:26:33', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:26:48', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:27:32', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:27:51', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:31:46', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:33:08', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:36:07', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:36:17', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:36:52', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:37:15', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:38:54', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:39:30', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:40:36', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:40:38', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:41:13', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:42:00', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:52:00', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 12:54:02', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 13:19:12', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 13:49:12', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:02:22', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:02:35', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:02:37', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:03:14', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:05:32', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:05:38', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:11:10', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:13:17', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:13:53', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:15:56', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:17:26', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:21:53', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:21:57', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:24:37', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:25:15', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:30:09', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:32:26', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:34:41', 'dd-mm-yyyy hh24:mi:ss'), 5132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:37:13', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:39:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:40:58', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:42:16', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:42:19', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:42:21', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:42:23', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:08', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:34', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:39', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:41', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:43', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:48', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:52', 'dd-mm-yyyy hh24:mi:ss'), 5133);
commit;
prompt 2500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:43:59', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:01', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:05', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:07', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:12', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:14', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:19', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:21', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:24', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:52', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:55', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:44:57', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:00', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:02', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:04', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:06', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:12', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:14', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:19', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:22', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:24', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:29', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:31', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:33', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:35', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:38', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:40', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:42', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:47', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:49', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:51', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:53', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:55', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:45:58', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:00', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:03', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:05', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:07', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:20', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:22', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:24', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:29', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:31', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:36', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:38', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:40', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:42', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:46:50', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:47:06', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:47:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:12', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:15', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:18', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:20', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:22', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:25', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:46', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:51', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:51:54', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:07', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:12', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:18', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:33', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:36', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:40', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:42', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:52:46', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:53:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:53:22', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:53:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:53:31', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:54:02', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:55:09', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:56:11', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:56:15', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 14:57:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:00:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:00:21', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:01:29', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:02:13', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:03:38', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:04:40', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:07:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
commit;
prompt 2600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:07:57', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:08:39', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:08:44', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:09:51', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:09:57', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:10:09', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:10:19', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:10:40', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:11:39', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:11:41', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:11:52', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:11:57', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:01', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:05', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:07', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:14', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:21', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:26', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:36', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:39', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:12:49', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:13:49', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:13:51', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:14:07', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:14:11', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:19:33', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:20:19', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:22:17', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:28:10', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:32:53', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:33:06', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:33:57', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:34:25', 'dd-mm-yyyy hh24:mi:ss'), 5133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:38:18', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:41:30', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:42:14', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:44:46', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:45:06', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:48:13', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:49:31', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:49:40', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:49:49', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:52:16', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:52:58', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:54:40', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:55:21', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 15:56:26', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:05:52', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:05:59', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:06:01', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:07:36', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:07:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:08:02', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:08:11', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:08:39', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:09:10', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:09:53', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:19:53', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:21:54', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:47:04', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:47:34', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:48:04', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:48:17', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:48:22', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:48:24', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:51:53', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:52:13', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:52:20', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:52:22', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 16:53:08', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:03:08', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:05:09', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:07:43', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:07:53', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:07:55', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:08:14', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:13:14', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:13:21', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:13:23', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:14:11', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:15:47', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:15:55', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:15:57', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:21:26', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:23:49', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:24:28', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:27:17', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:29:47', 'dd-mm-yyyy hh24:mi:ss'), 5134);
commit;
prompt 2700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:34:55', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:36:59', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:37:37', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:38:11', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:38:29', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:38:50', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:42:29', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:43:10', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:43:30', 'dd-mm-yyyy hh24:mi:ss'), 5134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:46:07', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:47:43', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:53:44', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:04:46', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:33:05', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 00:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5953);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:22:39', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:32:39', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:34:40', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:37:50', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:37:59', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:38:01', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:38:02', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:48:02', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 01:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:19:55', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:21:57', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 02:47:06', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 03:17:06', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 03:47:07', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 04:17:07', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 04:47:08', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 05:17:08', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 05:47:09', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 06:17:09', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 06:47:09', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:14:37', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:15:16', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:15:31', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:15:36', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:15:38', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:25:14', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:25:16', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:26:55', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:26:58', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:27:00', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:27:26', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:27:46', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:27:56', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:27:58', 'dd-mm-yyyy hh24:mi:ss'), 5954);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 07:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5955);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 08:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 09:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 10:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:09:40', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:19:40', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:42:12', 'dd-mm-yyyy hh24:mi:ss'), 5959);
commit;
prompt 2800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:48:52', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:51:31', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:51:40', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:51:42', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 11:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:15:01', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:29:41', 'dd-mm-yyyy hh24:mi:ss'), 5959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:42:54', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 12:51:44', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:01:44', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:03:46', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:28:55', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:57:14', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:57:24', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 13:57:26', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:07:26', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:47:51', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 14:54:06', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:04:06', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:14:02', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:26:39', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:36:39', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:37:47', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:37:55', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:37:57', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:37:58', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:48:08', 'dd-mm-yyyy hh24:mi:ss'), 5961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 15:57:31', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:04:33', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:24:56', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:34:56', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:36:58', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:48:38', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:49:19', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:49:35', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:49:40', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:49:42', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 16:52:53', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:01:27', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:01:37', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:01:39', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:02:22', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:09:59', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:10:04', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:10:06', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:20:06', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5962);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 17:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5963);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 18:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5964);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 19:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:00:58', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:09:51', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:10:00', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:10:02', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:20:02', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5965);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 20:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:02:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5966);
commit;
prompt 2900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:47:32', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:57:32', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 21:59:34', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:38:35', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:38:41', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:38:43', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:48:34', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:53:21', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:53:27', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 22:53:29', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:03:29', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:07:28', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:17:28', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:22:28', 'dd-mm-yyyy hh24:mi:ss'), 5967);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:32:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('16-09-2021 23:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 17:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:00:37', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:01:27', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:09:12', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:10:26', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:10:31', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:11:32', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:12:43', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:14:06', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:14:31', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:15:14', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:15:34', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:15:41', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:16:21', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:17:56', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:15', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:18', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:21', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:53', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:18:56', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:03', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:25', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:30', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:33', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:36', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:19:54', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:05', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:11', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:16', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:20', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:20:51', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:00', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:10', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:13', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:15', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:23', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:27', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:29', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:32', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:35', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:37', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:39', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:42', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:47', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:21:49', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:22:04', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:23:23', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:24:06', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:25:20', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:26:21', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:26:47', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:26:52', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:26:57', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:27:01', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:27:16', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:27:25', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:27:50', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:28:30', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:28:50', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:28:54', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:30:16', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:30:22', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:32:08', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:33:12', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:33:31', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:33:36', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:34:01', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:34:12', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:34:19', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:35:54', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:36:47', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:09', 'dd-mm-yyyy hh24:mi:ss'), 5135);
commit;
prompt 3000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:21', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:24', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:32', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:37:40', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:17', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:20', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:25', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:27', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:44', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:47', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:49', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:38:51', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:39:09', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:40:20', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:40:34', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:41:05', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:41:19', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:41:59', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:42:39', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:42:51', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:43:41', 'dd-mm-yyyy hh24:mi:ss'), 5135);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:44:43', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:45:22', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:46:59', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:47:02', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:49:28', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:50:40', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:50:43', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:51:58', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:52:03', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:53:34', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:53:44', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:53:46', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:55:09', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:55:25', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:56:18', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:56:23', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 18:57:09', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:00:15', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:01:10', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:01:50', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:02:01', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:02:15', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:03:15', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:03:54', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:04:29', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:04:35', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:06:01', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:06:49', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:06:55', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:07:18', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:07:35', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:07:41', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:08:31', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:13:26', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:14:21', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:15:18', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:15:24', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:16:06', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:16:15', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:17:20', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:18:04', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:18:55', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:19:38', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:20:32', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:20:41', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:21:29', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:23:53', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:24:38', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:25:27', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:29:04', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:30:47', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:44:02', 'dd-mm-yyyy hh24:mi:ss'), 5136);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:47:51', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:50:29', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:50:53', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 19:56:41', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:01:59', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:02:07', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:02:09', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:04:53', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:07:22', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:16:52', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:18:23', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:19:35', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:22:37', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:24:45', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:25:53', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:27:37', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5137);
commit;
prompt 3100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:31:37', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:37:14', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:37:34', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:41:25', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:42:01', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:42:31', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:43:49', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:49:15', 'dd-mm-yyyy hh24:mi:ss'), 5137);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:49:43', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:53:31', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:54:34', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:59:34', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 20:59:58', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:00:17', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:03:34', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:03:54', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:05:44', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:08:12', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:09:45', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:11:43', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:15:04', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:15:12', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:19:41', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:20:38', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:30:38', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:32:39', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:10', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:23', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:25', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:27', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:45', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:39:54', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:40:24', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:42:49', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:42:57', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:43:16', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:44:01', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:45:34', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:45:57', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:47:45', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:48:00', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:51:53', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:52:27', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:52:46', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:53:08', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:54:44', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:56:22', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:57:53', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 21:58:08', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 22:08:08', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 22:10:07', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 22:35:17', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:05:17', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:29:43', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:29:50', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:29:52', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:36:45', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:37:20', 'dd-mm-yyyy hh24:mi:ss'), 5138);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:39:44', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:42:14', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:52:14', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:54:44', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:59:25', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:59:28', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('16-09-2021 23:59:32', 'dd-mm-yyyy hh24:mi:ss'), 5139);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 00:19:23', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 00:49:23', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 01:19:23', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 01:49:24', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 02:19:24', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 02:49:25', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 03:19:25', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 03:49:26', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 04:19:26', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 04:49:27', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 05:19:27', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 05:49:27', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 06:19:28', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 06:49:28', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 07:19:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 07:49:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 08:19:30', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 08:49:30', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 09:19:31', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 09:49:31', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:19:32', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:49:32', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:51:07', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:51:30', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:51:32', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 10:52:08', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:02:08', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:03:48', 'dd-mm-yyyy hh24:mi:ss'), 1786);
commit;
prompt 3200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:03:50', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:08:55', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:12:47', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:14:05', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:14:44', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:14:48', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:14:50', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:16:15', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:18:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:19:10', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:25:47', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:26:53', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:27:17', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:27:19', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:35:15', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:44:59', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:49:51', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:56:47', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:56:55', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:56:57', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 11:57:40', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:00:49', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:00:51', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:03:59', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:09:04', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:09:18', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:09:20', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:10:18', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:11:30', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:11:38', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:11:40', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:12:42', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:22:42', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:24:45', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:31:54', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:32:08', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:32:10', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:32:14', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:43:03', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:43:10', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:43:12', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 12:53:58', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:03:58', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:06:02', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:31:11', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:59:12', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:59:21', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 13:59:23', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:13:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:18:29', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:18:43', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:28:43', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:30:46', 'dd-mm-yyyy hh24:mi:ss'), 1787);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:37:16', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:37:28', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:37:30', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:42:12', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:52:12', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 14:54:15', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:05:36', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:05:43', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:05:45', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:06:47', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:11:41', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:11:48', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:11:50', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:12:46', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:22:46', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:22:49', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:22:57', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:22:59', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:33:07', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:40:17', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:42:54', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:43:01', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:43:03', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 15:53:33', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 16:03:33', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 16:05:35', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 16:30:44', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:00:45', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:05:56', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:05:58', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:06:00', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:06:08', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:06:10', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:06:41', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:07:09', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:07:18', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:07:20', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:07:34', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:15:28', 'dd-mm-yyyy hh24:mi:ss'), 1788);
commit;
prompt 3300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:18:29', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:23:23', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:25:05', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:25:14', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:25:16', 'dd-mm-yyyy hh24:mi:ss'), 1788);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:43:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:54:48', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:58:15', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:58:25', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 17:58:27', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:03:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:13:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:18:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:28:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1789);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:40:06', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:48:12', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 18:58:12', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 19:00:15', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 19:25:25', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 19:55:25', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 20:25:26', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 20:55:26', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 21:25:27', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 21:55:27', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 22:25:27', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 22:55:28', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 23:25:28', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('16-09-2021 23:55:29', 'dd-mm-yyyy hh24:mi:ss'), 1790);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 00:27:46', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 00:57:47', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 01:27:47', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 01:57:48', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 02:27:48', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 02:57:49', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 03:27:49', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 03:57:49', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 04:27:50', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 04:57:50', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 05:27:51', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 05:57:51', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 06:27:52', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 06:57:52', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:10:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:10:52', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:11:12', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:11:16', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:11:18', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:11:21', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:21:21', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:25:32', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:25:39', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:25:41', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:26:04', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:27:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:27:31', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:34:37', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:35:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:37:06', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:44:58', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:22', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:24', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:30', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:47', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:49', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:56', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:45:58', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:47:42', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:47:46', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:47:48', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:48:16', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:58:13', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:58:34', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:58:36', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 07:59:40', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:01:41', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:02:57', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:03:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:03:09', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:05:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:06:06', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:08:27', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:08:33', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:08:35', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:10:32', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:11:53', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:18:02', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:20:07', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:27:51', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:35:07', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:36:47', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:45:07', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:50:08', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:55:15', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:55:29', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:56:26', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:56:41', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:56:43', 'dd-mm-yyyy hh24:mi:ss'), 470);
commit;
prompt 3400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:57:49', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 08:59:31', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:00:02', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:02:35', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:05:07', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:08:20', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:12:57', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:17:03', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:17:10', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:17:12', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:17:53', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:18:08', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:20:07', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:24:40', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:29:10', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:29:17', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:29:19', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:29:43', 'dd-mm-yyyy hh24:mi:ss'), 470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:35:07', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:37:42', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:39:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:40:05', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:47:05', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:47:11', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:47:13', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:48:10', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:50:08', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:51:13', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:54:02', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:55:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:55:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:55:46', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:58:34', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 09:59:17', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:01:44', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:01:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:01:53', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:03:11', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:04:46', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:05:07', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:15:07', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:18:51', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:23:38', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:23:45', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:23:47', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:27:53', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:27:59', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:28:25', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:38:25', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:40:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:45:56', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:46:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:46:05', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:49:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 10:59:03', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:01:06', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:15:54', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:16:25', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:16:27', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:17:17', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:27:17', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:29:19', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 11:54:28', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 12:24:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 12:54:29', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 13:24:30', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 13:54:30', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 14:24:30', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 14:54:31', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 15:24:31', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 15:54:32', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 16:24:32', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 16:54:33', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 17:24:33', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 17:54:34', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 18:24:34', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 18:54:35', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 19:24:35', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 19:54:36', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 20:24:36', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 20:54:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 21:24:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 21:54:37', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 22:24:38', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 22:54:38', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 23:24:39', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('16-09-2021 23:54:39', 'dd-mm-yyyy hh24:mi:ss'), 471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 00:16:20', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 00:46:21', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:16:21', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:24:52', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:24:58', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:25:00', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:27:04', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:37:04', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 01:39:06', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 02:04:15', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 02:34:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 03:04:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 03:34:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
commit;
prompt 3500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 04:04:17', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 04:34:17', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 05:04:18', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 05:34:18', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:04:19', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:33:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:34:38', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:34:56', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:35:01', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:35:03', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:37:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:47:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 06:50:00', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:10:52', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:10:54', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:12:03', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:16:58', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:17:00', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:17:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:17:11', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:18:23', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:18:27', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:18:29', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:18:51', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:20:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:20:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:20:32', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:23:43', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:33:43', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:35:45', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:43:52', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:44:01', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:44:03', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:45:50', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:45:58', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:47:10', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:57:10', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 07:59:10', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:20:31', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:20:39', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:20:41', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:37:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:39:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:39:39', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:49:39', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 08:51:41', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 09:16:50', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 09:46:51', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 09:59:11', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 09:59:20', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 09:59:22', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:04:58', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:11:10', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:12:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:17:35', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:27:35', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:54:47', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 10:59:48', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:00:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:00:07', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:00:50', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:01:37', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:09:06', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:09:16', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:09:18', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:09:41', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:10:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:11:41', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:12:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:13:44', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:15:20', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:17:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:22:44', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:25:28', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:26:59', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:28:31', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:38:31', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 11:40:33', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 12:05:43', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 12:35:43', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 13:05:43', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 13:35:44', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:05:44', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:18:07', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:18:22', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:18:24', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:24:26', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:26:51', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:28:11', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:29:55', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:30:49', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:32:17', 'dd-mm-yyyy hh24:mi:ss'), 3126);
commit;
prompt 3600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:35:13', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:36:38', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:37:55', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:42:03', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:42:45', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:43:57', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:48:12', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:49:17', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:51:51', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:53:00', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:57:03', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:57:25', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 14:58:44', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:07:44', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:08:41', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:09:13', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:12:03', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:13:49', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:14:46', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:16:13', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:26:13', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:28:15', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 15:53:24', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:08:34', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:08:46', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:08:48', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:09:05', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:09:16', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:09:28', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:09:43', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:09:53', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:11:11', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:11:37', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:12:02', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:12:41', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:16:50', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:26:44', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:27:03', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:29:20', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:39:20', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:41:22', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:55:53', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:56:31', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:56:54', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:56:56', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 16:57:02', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:03:15', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:03:25', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:03:41', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:13:41', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:15:42', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:29:16', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:29:29', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:29:31', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:31:57', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:34:10', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:34:28', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:36:47', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:39:05', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:39:19', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:41:10', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:41:26', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:42:02', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:43:09', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:45:52', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:46:07', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:46:29', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:46:51', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:47:55', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:48:15', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:49:29', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:50:05', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:51:45', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:52:21', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:52:58', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:54:30', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:55:43', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:56:04', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:57:02', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 17:58:43', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 18:08:43', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 18:10:44', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 18:35:54', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 19:05:54', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 19:35:55', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:05:55', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:17:10', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:17:38', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:17:53', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:17:57', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:17:59', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:24:45', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:25:12', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:25:35', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:26:18', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:27:00', 'dd-mm-yyyy hh24:mi:ss'), 3128);
commit;
prompt 3700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:27:39', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:29:08', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:29:16', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:29:57', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:33:56', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:35:28', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:37:15', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:39:35', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:40:20', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:40:57', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:41:32', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:43:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:46:10', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:46:17', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:47:35', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:50:09', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:50:28', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:50:48', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:54:27', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:54:49', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:57:00', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:57:32', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:57:40', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:57:52', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 20:58:36', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:04:33', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:06:15', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:06:55', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:16:55', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:18:55', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:28:23', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:28:31', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:28:33', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:32:20', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:32:37', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:32:44', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:33:02', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:33:26', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:33:37', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:33:58', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:34:12', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:34:24', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:34:35', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:35:08', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:35:31', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:35:42', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:35:59', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:36:10', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:36:37', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:37:15', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:37:24', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:37:45', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:38:02', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:38:40', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:39:38', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:39:54', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:40:50', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:41:11', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:41:34', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:42:08', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:43:22', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:43:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:44:18', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:44:37', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:45:19', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:45:58', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:47:04', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:49:06', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:49:38', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 21:59:38', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 22:01:39', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 22:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 22:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 23:26:50', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('16-09-2021 23:56:50', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 00:15:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 00:45:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:16:00', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:27:15', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:27:17', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:44:22', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:45:10', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:45:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:50:13', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:50:45', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:57:27', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:57:42', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 01:59:46', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 02:09:46', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 02:11:46', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 02:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3124);
commit;
prompt 3800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 03:06:56', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 03:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 04:06:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 04:36:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 05:06:58', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 05:36:58', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 06:06:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 06:36:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:06:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:37:00', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:43:25', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:07', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:26', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:32', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:44', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:48', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:44:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:48:24', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:48:35', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:48:57', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:49:06', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:49:08', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:49:45', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:50:21', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:50:24', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:50:26', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:50:40', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:51:03', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:51:14', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:51:16', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:54:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:59:00', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:59:11', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 07:59:13', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:02:44', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:05:32', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:12:28', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:12:52', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:16:45', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:16:53', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:16:55', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:17:44', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:17:54', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:20:51', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:30:51', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:32:51', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:45:14', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:45:21', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:45:23', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:45:39', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:47:20', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:48:27', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:50:24', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:51:20', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:53:29', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:54:19', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:54:59', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 08:59:23', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:00:42', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:03:27', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:07:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:17:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 09:44:40', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:11:57', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:12:07', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:13:26', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:13:59', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:14:26', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:15:07', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:16:31', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:17:22', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:17:43', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:17:58', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:20:12', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:20:39', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:20:54', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:21:48', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:22:08', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:22:40', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:29:50', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:33:16', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:43:16', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:45:19', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:46:27', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:46:36', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:46:38', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:49:15', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:53:41', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:54:48', 'dd-mm-yyyy hh24:mi:ss'), 3126);
commit;
prompt 3900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 10:55:09', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:05:09', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:07:10', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:07:45', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:07:52', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:07:54', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:09:13', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:12:59', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:17:16', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:18:56', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:29:08', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:31:22', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:41:22', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 11:43:24', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 12:08:34', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 12:38:34', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:08:35', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:37:57', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:38:06', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:38:08', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:38:29', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:38:59', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:39:26', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:39:53', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:40:25', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:41:13', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:41:39', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:41:55', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:42:34', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:43:30', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:44:00', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:44:30', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:44:58', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:45:28', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:47:02', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:52:15', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:52:38', 'dd-mm-yyyy hh24:mi:ss'), 3126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 13:58:22', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:04:11', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:04:56', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:06:37', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:07:01', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:07:26', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:07:33', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:11:19', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:17:23', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:26:01', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:26:53', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:27:19', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:30:16', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:33:18', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:33:43', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:36:55', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:38:32', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:39:27', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:42:16', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:45:06', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:53:08', 'dd-mm-yyyy hh24:mi:ss'), 3127);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:57:19', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 14:59:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:13:32', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:13:54', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:14:27', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:16:10', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:16:37', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:17:03', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:20:14', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:21:14', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:22:07', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:22:41', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:22:59', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:23:38', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:24:14', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:26:24', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:27:49', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:30:59', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:32:47', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:35:40', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:35:53', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:36:21', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:36:37', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:37:00', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:37:56', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:38:42', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:38:57', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:39:10', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:39:53', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:40:08', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:40:36', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:41:08', 'dd-mm-yyyy hh24:mi:ss'), 3128);
commit;
prompt 4000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:42:51', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:48:19', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:49:42', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:49:45', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:50:15', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:50:17', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:52:22', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:53:49', 'dd-mm-yyyy hh24:mi:ss'), 3128);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:57:36', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 15:59:32', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:01:58', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:03:29', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:08:41', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:11:56', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:12:41', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:14:19', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:14:38', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:15:14', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:15:33', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:17:54', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:19:08', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:19:47', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:22:07', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:22:37', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:23:18', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:24:01', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:24:35', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:26:39', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:29:16', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:39:16', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:41:17', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:58:36', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:58:48', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 16:58:50', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:03:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:10:51', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:11:15', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:11:17', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:13:37', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:13:53', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:14:38', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:15:17', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:15:25', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:15:41', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:15:58', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:16:04', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:16:18', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:18:03', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:18:32', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:19:03', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:20:15', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:20:33', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:21:36', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:21:52', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:22:35', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:22:54', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:24:20', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:24:28', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:25:00', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:26:05', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:28:30', 'dd-mm-yyyy hh24:mi:ss'), 3129);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:29:40', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:30:28', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:31:02', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:32:11', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:33:19', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:34:05', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:35:09', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:37:11', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:37:58', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:38:24', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:38:51', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:40:29', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:40:58', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:41:29', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:45:16', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:46:49', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:48:14', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:48:25', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:56:40', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:56:42', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:56:48', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 17:57:21', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:00:14', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:01:35', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:08:27', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:12:50', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:13:40', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:18:10', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:18:18', 'dd-mm-yyyy hh24:mi:ss'), 3130);
commit;
prompt 4100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:19:04', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:19:41', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:21:20', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:23:19', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:24:17', 'dd-mm-yyyy hh24:mi:ss'), 3130);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:30:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:30:34', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:31:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:31:25', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:33:05', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:33:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:34:03', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:35:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:37:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:38:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:39:22', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:39:42', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:40:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:41:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:42:31', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:43:24', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:43:53', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:44:10', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:44:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:45:32', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:46:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:47:08', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:49:21', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:50:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:50:52', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 18:52:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:02:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:04:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:05:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:06:11', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:06:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:06:38', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:06:40', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:07:54', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:08:37', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:09:14', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:09:43', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:12:29', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:14:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:15:47', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:17:28', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:20:01', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:22:36', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:23:56', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:24:39', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:25:59', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:27:26', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:33:50', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:35:35', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:38:33', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:41:06', 'dd-mm-yyyy hh24:mi:ss'), 3131);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:41:43', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:42:23', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:43:06', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:44:01', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:44:59', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:46:07', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:46:54', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:51:48', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:53:16', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:54:27', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:55:25', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 19:56:18', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:01:16', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:02:00', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:03:08', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:06:16', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:07:00', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:09:01', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:10:09', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:12:06', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:13:34', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:14:45', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:15:58', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:22:38', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:23:04', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:27:56', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:28:07', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:35:50', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:41:13', 'dd-mm-yyyy hh24:mi:ss'), 3132);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:41:55', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:42:19', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:43:16', 'dd-mm-yyyy hh24:mi:ss'), 3133);
commit;
prompt 4200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:49:10', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:54:20', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:57:29', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:58:09', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 20:58:47', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:01:05', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:01:35', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:02:53', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:04:17', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:04:50', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:05:14', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:07:17', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:08:05', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:09:28', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:11:55', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:13:25', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:13:58', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:14:42', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:15:13', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:16:25', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:17:36', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:18:15', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:18:46', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:21:10', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:21:24', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:21:37', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:23:16', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:24:24', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:25:49', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:26:30', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:26:55', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:27:24', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:27:56', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:29:05', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:29:34', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:30:26', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:32:51', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:34:14', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:34:53', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:36:17', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:36:41', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:36:58', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:37:33', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:38:17', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:38:42', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:39:56', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:41:09', 'dd-mm-yyyy hh24:mi:ss'), 3133);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:41:35', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:42:32', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:43:32', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:43:50', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:44:37', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:45:07', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:46:31', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:47:33', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:48:12', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:49:43', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:50:57', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:56:03', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:56:17', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:56:19', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:56:54', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 21:59:36', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:00:02', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:01:21', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:02:33', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:03:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:04:40', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:05:19', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:06:37', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:16:37', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:18:39', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 22:43:49', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:13:49', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:24:10', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:24:24', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:24:26', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:27:38', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:27:52', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:28:21', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:28:56', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:29:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:29:54', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:30:17', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:30:52', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:31:12', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:33:07', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:33:35', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:34:56', 'dd-mm-yyyy hh24:mi:ss'), 3134);
commit;
prompt 4300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:35:31', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:35:59', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:36:57', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:38:19', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:38:50', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:41:19', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:42:42', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:43:29', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:45:38', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:46:33', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:47:35', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:48:27', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:49:25', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:50:34', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:51:33', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:52:29', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:53:30', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:54:41', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:55:43', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:58:02', 'dd-mm-yyyy hh24:mi:ss'), 3134);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('16-09-2021 23:59:09', 'dd-mm-yyyy hh24:mi:ss'), 3134);
commit;
prompt 4323 records loaded
set feedback on
set define on
prompt Done.
