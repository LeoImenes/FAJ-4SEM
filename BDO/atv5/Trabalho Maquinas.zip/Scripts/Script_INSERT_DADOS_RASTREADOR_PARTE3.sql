﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 00:26:19', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 00:56:20', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 01:26:20', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 01:56:21', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 02:26:21', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 02:56:21', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 03:26:22', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 03:56:22', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 04:26:23', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 04:56:23', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 05:26:24', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 05:56:24', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 06:26:24', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 06:56:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:07:29', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:08:21', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:08:38', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:08:43', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:08:45', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:08:46', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:10:19', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:10:29', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:10:31', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:12:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:22:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:24:28', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 07:49:37', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 08:19:38', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 08:49:38', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 08:51:36', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 08:51:44', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 08:51:46', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:01:19', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:04:00', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:04:30', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:04:32', 'dd-mm-yyyy hh24:mi:ss'), 1469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:14:40', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:16:20', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:26:20', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:31:20', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:41:20', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:43:38', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:53:38', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 09:55:41', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 10:20:50', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 10:50:51', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:20:51', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:24:38', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:24:47', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:24:49', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:31:19', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:39:10', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:44:24', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:44:33', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:44:35', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:46:19', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:50:24', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:51:53', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:52:28', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:52:30', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:52:49', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:54:15', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:54:25', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:54:27', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:55:09', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:57:12', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 11:57:14', 'dd-mm-yyyy hh24:mi:ss'), 1470);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:01:19', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:02:09', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:04:41', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:04:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:04:49', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:05:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:15:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:17:44', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:37:05', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:37:11', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:37:13', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:46:19', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:48:46', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:50:43', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:50:50', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:50:52', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 12:52:30', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 13:02:30', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 13:04:33', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 13:29:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 13:59:43', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:26:31', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:26:41', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:26:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:27:03', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:27:51', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:27:59', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:28:01', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:28:21', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:30:00', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:30:10', 'dd-mm-yyyy hh24:mi:ss'), 1471);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:30:12', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:31:19', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:36:35', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:38:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:38:51', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:38:53', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:45:18', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:55:18', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 14:57:21', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:22:30', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:25:04', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:25:14', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:25:16', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:31:18', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:40:12', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:42:33', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:42:40', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:42:42', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:46:18', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:50:23', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:51:50', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:51:59', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:52:01', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 15:52:37', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 16:02:37', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 16:04:39', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 16:29:48', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 16:59:49', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:03:13', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:03:25', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1471);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:13:28', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:16:18', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:26:18', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 00:26:56', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 00:56:56', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 01:26:57', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 01:56:57', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 02:26:58', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 02:56:58', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 03:26:58', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 03:56:59', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 04:26:59', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 04:57:00', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 05:27:00', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 05:57:01', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 06:27:01', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 06:57:02', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:10:39', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:11:07', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:11:17', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:11:21', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:11:23', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:11:36', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:13:08', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:20:03', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:24:59', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:25:01', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:26:35', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:26:38', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:26:40', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:27:00', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:27:17', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:27:26', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:27:28', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:28:08', 'dd-mm-yyyy hh24:mi:ss'), 253);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:38:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:43:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:43:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:45:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 07:52:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 08:02:15', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 08:04:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 08:29:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 08:59:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 09:29:29', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 09:59:29', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 10:29:29', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 10:59:30', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 11:29:30', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 11:59:31', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:29:31', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:38:54', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:39:02', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:39:04', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:43:05', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:43:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:50:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:51:54', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 12:58:08', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 13:03:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 13:13:37', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 13:15:39', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 13:40:48', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 14:10:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 14:40:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 15:10:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 15:40:50', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 16:10:50', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 16:40:51', 'dd-mm-yyyy hh24:mi:ss'), 254);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:10:51', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:20:28', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:21:46', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:21:51', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:23:44', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:23:49', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:24:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:34:18', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 17:35:47', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 18:00:56', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 18:30:57', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 19:00:57', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 19:30:58', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 20:00:58', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 20:30:59', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 21:00:59', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 21:31:00', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 22:01:00', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 22:31:00', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 23:01:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('15-09-2021 23:31:01', 'dd-mm-yyyy hh24:mi:ss'), 254);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 00:14:24', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 00:44:24', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 01:14:25', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 01:44:25', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 02:14:26', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 02:44:26', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 03:14:27', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 03:44:27', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 04:14:27', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 04:44:28', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 05:14:28', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 05:44:29', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 06:14:29', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 06:44:30', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:14:30', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:44:31', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:44:34', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:45:10', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:45:26', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:45:31', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:45:33', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:49:32', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:52:26', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:52:44', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:52:46', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 07:53:53', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:03:53', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:05:58', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:31:08', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:55:33', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:55:58', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 08:56:00', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:02:37', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:12:37', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:17:38', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:25:22', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:32:37', 'dd-mm-yyyy hh24:mi:ss'), 1311);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:42:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:46:51', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:56:51', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 09:58:53', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 10:24:02', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 10:54:03', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 11:24:04', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 11:54:04', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:19:57', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:23:44', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:23:46', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:23:49', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:25:33', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:32:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:42:18', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:42:27', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:42:29', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:47:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:49:02', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:54:14', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:54:30', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:54:32', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 12:55:43', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:01:47', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:02:02', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:02:06', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:02:13', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:02:15', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:02:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:13:28', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:15:30', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:17:14', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:17:21', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:17:23', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:17:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:27:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:32:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:36:25', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:45:39', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:45:47', 'dd-mm-yyyy hh24:mi:ss'), 1312);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:45:49', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:47:37', 'dd-mm-yyyy hh24:mi:ss'), 1312);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:54:33', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:55:18', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:55:25', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 13:55:27', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:00:17', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:10:17', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:12:19', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:18:06', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:18:13', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:18:15', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:18:17', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:18:53', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:22:16', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:22:25', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:22:26', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:22:33', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:22:35', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:27:52', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:29:09', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:29:16', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:29:18', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:29:28', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:39:28', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:41:31', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:47:22', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:47:41', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:50:53', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:50:55', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 14:57:16', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:02:37', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:12:37', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:17:37', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:24:32', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:24:34', 'dd-mm-yyyy hh24:mi:ss'), 1313);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:32:37', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:37:55', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:47:55', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 15:49:57', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 16:15:06', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 16:45:07', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 17:15:07', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 17:45:08', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 18:15:08', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 18:45:09', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 19:15:09', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 19:45:10', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 20:15:10', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 20:45:10', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 21:15:11', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 21:45:11', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 22:15:12', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 22:45:12', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 23:15:13', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('15-09-2021 23:45:13', 'dd-mm-yyyy hh24:mi:ss'), 1314);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:01:41', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:11:41', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 00:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5008);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 01:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5009);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 02:00:06', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 02:10:06', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 02:12:09', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 02:37:19', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 03:07:19', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 03:37:20', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 04:07:20', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 04:37:20', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 05:07:21', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 05:37:21', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 06:07:22', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 06:37:22', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:07:23', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:10:29', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:11:10', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:11:33', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:11:38', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:11:40', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:19:49', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:21:36', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:27:21', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:27:44', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:27:46', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:28:15', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:28:16', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:28:26', 'dd-mm-yyyy hh24:mi:ss'), 5010);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:28:28', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:29:53', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:29:56', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:29:58', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:30:19', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:30:32', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:30:59', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:31:01', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 07:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5010);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:30:01', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:33:18', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:33:25', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:33:27', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:39:24', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:42:54', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:45:10', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:45:17', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:45:19', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 08:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:05:41', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:12:10', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:12:19', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:12:21', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:16:31', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:26:31', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:26:47', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:26:55', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:26:57', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:28:50', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:31:43', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:31:54', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:31:56', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:31:57', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:39:46', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:49:46', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:51:41', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:51:57', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 09:51:59', 'dd-mm-yyyy hh24:mi:ss'), 5011);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:00:12', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:04:48', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:04:55', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:04:57', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:15:07', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:23:11', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:23:52', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:25:19', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:25:21', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:31:35', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:41:35', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 10:54:27', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:04:27', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:06:28', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:31:37', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:41:39', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:42:11', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:42:34', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:42:38', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:42:40', 'dd-mm-yyyy hh24:mi:ss'), 5012);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 11:56:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:03:34', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:13:34', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:14:16', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:14:23', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:14:25', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:16:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:26:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:31:31', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:35:02', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:35:08', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:35:10', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:45:04', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:55:04', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 12:57:05', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 13:22:15', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 13:52:15', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 13:55:30', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 13:55:36', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 13:55:38', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5013);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:48:58', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:58:47', 'dd-mm-yyyy hh24:mi:ss'), 5014);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:59:36', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 14:59:38', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5014);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:24:32', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:25:29', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:25:39', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:25:41', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:26:46', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:28:56', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:29:03', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:29:05', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 15:59:37', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:08:32', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:17:42', 'dd-mm-yyyy hh24:mi:ss'), 5015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:22:47', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:32:47', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:34:49', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:51:26', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:51:56', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:52:28', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:52:33', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 16:52:35', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:12:07', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:17:07', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:17:31', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:17:33', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:19:26', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:19:28', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:20:35', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:31:18', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:36:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:46:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 17:48:29', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:13:38', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:40:12', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:40:52', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:41:06', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:41:10', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:41:12', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:44:13', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:54:13', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 18:56:15', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 19:21:25', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 19:51:25', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 20:21:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 20:51:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 21:21:26', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 21:51:27', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 22:21:27', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 22:51:28', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 23:21:29', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('15-09-2021 23:51:29', 'dd-mm-yyyy hh24:mi:ss'), 1472);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 00:04:32', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 00:34:32', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 01:04:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 01:34:33', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 02:04:34', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 02:34:34', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 03:04:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 03:34:35', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 04:04:36', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 04:34:36', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 05:04:37', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 05:34:37', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 06:04:37', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 06:34:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:04:38', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:22:07', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:23:22', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:23:58', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:24:03', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:24:05', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:24:08', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:34:08', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:36:09', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:54:21', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:54:29', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:54:31', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:58:22', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 07:58:52', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:01:03', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:01:15', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:01:17', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:03:08', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:13:08', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:15:10', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:34:40', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:34:59', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:35:01', 'dd-mm-yyyy hh24:mi:ss'), 937);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:36:39', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:46:39', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 08:48:41', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:13:50', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:35:24', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:35:39', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:35:41', 'dd-mm-yyyy hh24:mi:ss'), 937);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:42:02', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:52:02', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 09:54:03', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:18:34', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:18:41', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:18:43', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:28:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:38:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:40:37', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:43:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:53:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:57:07', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 10:58:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:08:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:13:21', 'dd-mm-yyyy hh24:mi:ss'), 938);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:23:21', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:28:21', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:32:40', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:42:40', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 11:44:42', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:09:51', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:19:26', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:19:44', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:19:46', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:20:00', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:30:00', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:32:01', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 12:57:10', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:27:10', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:31:49', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:32:04', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:32:06', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:42:06', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:43:21', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 13:50:20', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:00:21', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:00:32', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:00:34', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:06:56', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:13:48', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:14:02', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:14:04', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:14:06', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:19:14', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:27:32', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:37:32', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:39:31', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:47:26', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:47:36', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:47:38', 'dd-mm-yyyy hh24:mi:ss'), 939);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 14:55:48', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:05:48', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:07:50', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:32:59', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:53:48', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:53:55', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:53:57', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:58:21', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 15:58:28', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:03:35', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:12:06', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:12:31', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:12:33', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:22:39', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:24:41', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 16:49:51', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:09:55', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:10:22', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:10:24', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:12:39', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:14:22', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:14:44', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:14:46', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:15:01', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:25:01', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:27:02', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 17:52:11', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:09:28', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:11:03', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:11:04', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:11:15', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:21:15', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:21:26', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:26:18', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:26:22', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:26:24', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:26:28', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:28:20', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:30:10', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:40:10', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 18:42:10', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:07:20', 'dd-mm-yyyy hh24:mi:ss'), 940);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:37:20', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:48:38', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:54:10', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:54:12', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:58:21', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 19:59:45', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:01:49', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:11:49', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:13:51', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:39:01', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:44:36', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:46:09', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:46:11', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:46:15', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:56:15', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 20:58:15', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:19:55', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:20:11', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:20:14', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:20:16', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:20:20', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:30:20', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 21:55:29', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 22:25:29', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 22:55:30', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 23:25:30', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('15-09-2021 23:55:31', 'dd-mm-yyyy hh24:mi:ss'), 940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 00:07:54', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 00:37:55', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 01:07:55', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 01:37:56', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 02:07:56', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 02:37:57', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 03:07:57', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 03:37:57', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 04:07:58', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 04:37:58', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 05:07:59', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 05:38:00', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 06:08:00', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 06:38:01', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 07:08:01', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 07:38:02', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:01:31', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:02:31', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:02:58', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:03:02', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:03:04', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:06:09', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:12:27', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:12:33', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:12:35', 'dd-mm-yyyy hh24:mi:ss'), 2036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:20:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:30:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:30:41', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:31:24', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:31:31', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:31:33', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:35:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:45:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 08:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:00:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:15:09', 'dd-mm-yyyy hh24:mi:ss'), 2037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:16:31', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:26:31', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:28:33', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:50:01', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 09:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:15:09', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:20:09', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:24:48', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:34:48', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 10:36:50', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 11:01:59', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 11:32:00', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:02:00', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:04:29', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:04:36', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:04:38', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:05:09', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:07:50', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:17:50', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:19:52', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 12:45:02', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:09:51', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:09:59', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:10:01', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:20:03', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 13:54:11', 'dd-mm-yyyy hh24:mi:ss'), 2039);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:04:11', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:06:13', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:09:40', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:09:49', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:09:51', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:13:26', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:22:16', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:22:23', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:22:25', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:32:27', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:35:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:45:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:50:07', 'dd-mm-yyyy hh24:mi:ss'), 2039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 14:54:39', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:04:39', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:06:41', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:22:50', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:22:57', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:22:59', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:24:35', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:34:35', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:36:38', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:44:28', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:44:35', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:44:37', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:46:31', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:55:13', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:55:20', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 15:55:22', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 16:05:07', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 16:13:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 16:23:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 16:25:56', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 16:51:06', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 17:21:06', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 17:51:07', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:11:01', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:11:52', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:12:18', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:12:23', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:12:25', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:20:07', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:21:38', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:31:38', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:33:40', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 18:58:50', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 19:28:50', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 19:58:51', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 20:28:51', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 20:58:51', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 21:28:52', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 21:58:52', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 22:28:53', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 22:58:53', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 23:28:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('15-09-2021 23:58:54', 'dd-mm-yyyy hh24:mi:ss'), 2040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 00:19:10', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 00:49:10', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 01:19:11', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 01:49:11', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 02:19:12', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 02:49:12', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 03:19:13', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 03:49:13', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 04:19:13', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 04:49:14', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 05:19:14', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 05:49:15', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 06:19:15', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 06:49:16', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:19:16', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:43:32', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:44:38', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:45:31', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:45:36', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:45:38', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:47:10', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:48:09', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 07:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:03:09', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:07:39', 'dd-mm-yyyy hh24:mi:ss'), 1426);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:14:22', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:18:09', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:19:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:29:44', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:31:45', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 08:56:54', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 09:26:55', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 09:56:55', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 10:26:55', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 10:56:56', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 11:26:56', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 11:56:57', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 12:26:57', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 12:56:58', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 13:26:58', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 13:56:59', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 14:26:59', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 14:56:59', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 15:27:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 15:57:00', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 16:27:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 16:57:01', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 17:27:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 17:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 18:28:15', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 18:58:16', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 19:28:16', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 19:58:17', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 20:28:17', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 20:58:17', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 21:28:18', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 21:58:18', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 22:28:19', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 22:58:19', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 23:28:20', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('15-09-2021 23:58:20', 'dd-mm-yyyy hh24:mi:ss'), 1427);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:07:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:22:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:25:11', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4872);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:32:28', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:37:02', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:42:00', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:42:23', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:44:04', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:54:04', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:56:12', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 00:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:06:59', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:18:00', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4873);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:30:12', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:40:12', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:46:55', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:56:55', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 01:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:06:59', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:08:26', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:08:52', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:18:52', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:20:54', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 02:46:04', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 03:16:04', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 03:46:04', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 04:16:05', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 04:46:05', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 05:16:06', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 05:46:06', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 06:16:07', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 06:46:07', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:16:08', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:24:23', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:24:59', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:25:18', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:26:15', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:26:32', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:26:36', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:26:38', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:27:00', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:32:35', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:33:51', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:42:26', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:42:52', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:42:54', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:42:56', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:43:26', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:43:27', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:43:37', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:43:39', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:45:13', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:45:17', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:45:19', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:45:43', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:47:19', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:47:34', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:47:36', 'dd-mm-yyyy hh24:mi:ss'), 4874);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 07:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:07:00', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:07:19', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:12:00', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:22:00', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:35:10', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:38:32', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:51:11', 'dd-mm-yyyy hh24:mi:ss'), 4875);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 08:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:06:30', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:36:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:48:50', 'dd-mm-yyyy hh24:mi:ss'), 4876);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 09:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:05:16', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:34:26', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:36:26', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:44:47', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:54:47', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:58:28', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:58:39', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 10:58:41', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:01:08', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:08:20', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:08:29', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:08:31', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4877);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:36:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:43:58', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:53:58', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 11:58:21', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:08:21', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:14:46', 'dd-mm-yyyy hh24:mi:ss'), 4878);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:17:10', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:27:10', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:29:12', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 12:54:21', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:24:22', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:25:46', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:25:56', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:25:58', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:36:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:51:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 13:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:06:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:21:59', 'dd-mm-yyyy hh24:mi:ss'), 4879);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:26:59', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:36:59', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:51:07', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 14:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:01:41', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:02:57', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:03:07', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:03:09', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:19:43', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:22:39', 'dd-mm-yyyy hh24:mi:ss'), 4880);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:24:54', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:36:58', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:41:59', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:48:46', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:52:40', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:52:54', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:52:56', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 15:56:04', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:06:04', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:08:06', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:12:17', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:12:26', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:12:28', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:12:29', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:13:15', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:23:15', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:25:18', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:50:28', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 16:57:54', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:00:24', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:00:32', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:00:35', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:01:30', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:01:56', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:02:01', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:02:03', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:04:43', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:04:57', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:05:20', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:05:22', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:05:55', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:05:57', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:07:08', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:07:12', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:07:14', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:07:37', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:10:30', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:10:43', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:10:45', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:21:58', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:22:06', 'dd-mm-yyyy hh24:mi:ss'), 4881);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:26:06', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:27:13', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:30:28', 'dd-mm-yyyy hh24:mi:ss'), 4881);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:31:40', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:36:33', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:41:58', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:46:36', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:47:19', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:52:12', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:53:54', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:55:41', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:57:29', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 17:57:54', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:00:09', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:01:16', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:09:45', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:09:54', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:09:56', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:14:48', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:21:18', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:23:47', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:27:24', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:28:43', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:33:04', 'dd-mm-yyyy hh24:mi:ss'), 4882);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:41:58', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:50:12', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:50:24', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:54:09', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:55:29', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:55:59', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:56:28', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:56:31', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:59:07', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 18:59:50', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:00:26', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:10:26', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:17:20', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:22:35', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:23:56', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:25:33', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:26:46', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:27:19', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:32:30', 'dd-mm-yyyy hh24:mi:ss'), 4883);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:41:58', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:43:03', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:53:03', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 19:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:04:55', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:10:26', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:12:14', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:22:14', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:24:16', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:24:24', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:24:35', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:24:37', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:28:50', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:28:53', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:29:21', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:29:55', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:32:02', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:37:56', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:39:05', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:41:58', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:43:52', 'dd-mm-yyyy hh24:mi:ss'), 4884);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:55:02', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 20:59:27', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:02:44', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:06:24', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:06:27', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:07:14', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:16:22', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:26:22', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:26:25', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:26:58', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:36:58', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:41:58', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:49:52', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:49:56', 'dd-mm-yyyy hh24:mi:ss'), 4885);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:54:17', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 21:58:38', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:07:25', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:11:58', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:13:52', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:23:12', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:24:31', 'dd-mm-yyyy hh24:mi:ss'), 4886);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:28:53', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:30:57', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:33:46', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:42:55', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:51:04', 'dd-mm-yyyy hh24:mi:ss'), 4886);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 22:52:40', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:02:40', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:04:41', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:10:02', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:10:36', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:10:51', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:10:56', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:10:58', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:11:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:12:44', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:19:19', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:26:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:36:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:51:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('15-09-2021 23:56:57', 'dd-mm-yyyy hh24:mi:ss'), 4887);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:20:39', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:20:41', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:21:12', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:31:12', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:32:09', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:32:21', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:32:23', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:32:24', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:42:24', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:42:53', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:46:20', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:46:31', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 17:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:01:35', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:02:41', 'dd-mm-yyyy hh24:mi:ss'), 5016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:12:41', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:19:20', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:29:20', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:36:56', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 18:56:07', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:20:08', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:21:05', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:21:19', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:21:23', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:21:25', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:31:25', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:41:11', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 19:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:28:04', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 20:51:45', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:11:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:32:57', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:40:37', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:40:51', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:50:51', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 21:52:53', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:18:02', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:40:28', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:40:57', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:41:11', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:41:15', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:41:17', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 22:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:01:34', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:11:14', 'dd-mm-yyyy hh24:mi:ss'), 5020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:16:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:26:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:31:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:41:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:46:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('15-09-2021 23:56:34', 'dd-mm-yyyy hh24:mi:ss'), 5021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 00:09:52', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 00:39:52', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 01:09:53', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 01:39:53', 'dd-mm-yyyy hh24:mi:ss'), 3825);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 02:09:54', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 02:39:54', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 03:09:55', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 03:39:55', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 04:09:56', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 04:39:56', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 05:09:57', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 05:39:57', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 06:09:57', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 06:39:58', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:09:58', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:23:07', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:23:36', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:23:44', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:25:15', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:25:35', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:25:39', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:25:41', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:28:37', 'dd-mm-yyyy hh24:mi:ss'), 3825);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:38:37', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:41:50', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:51:50', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 07:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:18:31', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:33:05', 'dd-mm-yyyy hh24:mi:ss'), 3826);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 08:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:12:46', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:22:46', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:29:29', 'dd-mm-yyyy hh24:mi:ss'), 3827);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:39:29', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:41:50', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:51:50', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 09:56:50', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:00:17', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:10:17', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:12:02', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:12:13', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:12:15', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:12:17', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:22:17', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:26:50', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:36:50', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3828);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:25:41', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:31:08', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:31:17', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:31:19', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:41:19', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3829);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:11:07', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:21:50', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:47:59', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 12:57:59', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 13:00:00', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 13:25:09', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 13:55:10', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:05:26', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:05:34', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:05:36', 'dd-mm-yyyy hh24:mi:ss'), 3830);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 14:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3831);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3832);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:14:57', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:24:57', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:27:00', 'dd-mm-yyyy hh24:mi:ss'), 3833);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:52:10', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:54:08', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:54:41', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:54:59', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:55:03', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:55:05', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 16:57:02', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:02:22', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:02:34', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:02:36', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:14:28', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:21:32', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:21:54', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:21:56', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:22:28', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:22:31', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:23:48', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:23:52', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:23:54', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:25:21', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:25:56', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:25:58', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:44:03', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:44:05', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:49:28', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 17:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3833);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 18:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3834);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:25:58', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:28:33', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:38:33', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 19:40:32', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:00:33', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:00:40', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:00:43', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:17:09', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3835);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:38:34', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:42:59', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:52:00', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:52:08', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:52:10', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 20:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:35:14', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:38:06', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:48:06', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:49:37', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:49:39', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:52:15', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:59:15', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:59:22', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 21:59:24', 'dd-mm-yyyy hh24:mi:ss'), 3836);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:09:24', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:33:04', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:43:04', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 22:45:06', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:10:16', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:28:09', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:28:20', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:28:22', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:38:22', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3837);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('15-09-2021 23:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3838);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 00:00:48', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 00:30:48', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 01:00:49', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 01:30:49', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 02:00:50', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 02:30:50', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:00:51', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:30:51', 'dd-mm-yyyy hh24:mi:ss'), 2083);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:34:06', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:35:14', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:35:39', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:35:44', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:35:46', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:35:49', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:40:19', 'dd-mm-yyyy hh24:mi:ss'), 2083);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:50:19', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 03:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:13:53', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:23:53', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:25:54', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 04:51:03', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 05:21:03', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 05:51:04', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 06:21:04', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 06:51:05', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 06:51:37', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 06:52:21', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:02:21', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:27:30', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:28:59', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:29:33', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:29:47', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:29:52', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:29:54', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:33:59', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:38:31', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:42:11', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:42:21', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:42:23', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:48:44', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:57:08', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:57:17', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 07:57:19', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:10:19', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:11:26', 'dd-mm-yyyy hh24:mi:ss'), 2084);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:24:02', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:31:09', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:31:16', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:31:18', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:34:23', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:37:19', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:38:53', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:47:59', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:49:23', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:49:25', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:57:38', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 08:59:39', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:09:39', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:11:42', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:36:52', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:41:58', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:42:05', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:42:07', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:48:43', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 09:56:40', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:00:29', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:23:13', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:31:14', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:31:21', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:31:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:42:50', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:45:06', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:45:40', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:45:42', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 10:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:00:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:05:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:06:17', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:16:17', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:16:22', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:16:30', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:16:32', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:30:23', 'dd-mm-yyyy hh24:mi:ss'), 2086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:41:47', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:53:04', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:54:34', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:54:43', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 11:54:45', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:00:48', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:10:48', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:12:49', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:36:15', 'dd-mm-yyyy hh24:mi:ss'), 2087);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:36:22', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:36:24', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:45:21', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 12:58:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:02:06', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:02:14', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:02:16', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:02:34', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:12:34', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:14:36', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 13:39:45', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 14:09:46', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 14:39:46', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 15:09:47', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 15:39:47', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 16:09:47', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 16:39:48', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:09:48', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:14:25', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:14:58', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:15:13', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:15:18', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:15:20', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:16:59', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:26:59', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:27:21', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:27:44', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:27:46', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:28:16', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:28:17', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:28:25', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:28:27', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:29:38', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:29:42', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:29:44', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:30:07', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:31:44', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:31:54', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:31:56', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:49:01', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:52:45', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:53:20', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 17:53:22', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:03:22', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:05:23', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:06:42', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:12:32', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:20:23', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:30:23', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 18:50:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 19:00:13', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 19:10:13', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 19:12:14', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 19:37:23', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 20:07:24', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 20:37:24', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 21:07:25', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 21:37:25', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 22:07:26', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 22:37:26', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 23:07:26', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('15-09-2021 23:37:27', 'dd-mm-yyyy hh24:mi:ss'), 2089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:45:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:00:31', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:09:25', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:09:37', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:09:39', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:19:45', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:38:08', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:41:57', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 14:57:42', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:01:15', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:01:25', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:01:27', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:09:38', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:19:38', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:33:34', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4045);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:41:38', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:50:27', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:50:34', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:50:36', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 15:50:37', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:00:45', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:02:30', 'dd-mm-yyyy hh24:mi:ss'), 4046);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:07:08', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:07:19', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:07:21', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:13:44', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:15:12', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:25:12', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:27:13', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:52:22', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:58:08', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:58:44', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:58:59', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:59:03', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 16:59:05', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:03:04', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:04:16', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:05:04', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:05:35', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:05:53', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:05:58', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:06:00', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:08:17', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:10:57', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:11:20', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:11:22', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:11:50', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:11:52', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:13:04', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:13:08', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:13:10', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:13:41', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:15:45', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:15:57', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:15:59', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:26:16', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:37:12', 'dd-mm-yyyy hh24:mi:ss'), 4046);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:47:12', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:51:32', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 17:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:04:08', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:15:01', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:23:49', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:33:07', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:37:45', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:37:54', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:37:56', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:43:29', 'dd-mm-yyyy hh24:mi:ss'), 4047);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:47:00', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:57:00', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 18:59:02', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 19:24:12', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 19:54:12', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 20:24:13', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 20:54:13', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:23:27', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:23:57', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:24:11', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:24:16', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:24:18', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:32:48', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:45:01', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:46:32', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 21:54:35', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:04:35', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:11:32', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4048);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:25:28', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:43:09', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:49:02', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 22:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:00:01', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:05:01', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:07:24', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:10:55', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:20:01', 'dd-mm-yyyy hh24:mi:ss'), 4049);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:30:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:33:59', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:35:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:45:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:48:14', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:50:01', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 23:52:51', 'dd-mm-yyyy hh24:mi:ss'), 4050);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:00:01', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:04:39', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:12:42', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:13:23', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:15:27', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:17:32', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:19:19', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:20:49', 'dd-mm-yyyy hh24:mi:ss'), 2968);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:23:12', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:26:10', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:28:06', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:32:54', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:44:17', 'dd-mm-yyyy hh24:mi:ss'), 2968);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:52:09', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:52:33', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:53:26', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 00:55:38', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:03:49', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:10:01', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:14:03', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:16:46', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:19:34', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:19:41', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:20:14', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:25:01', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:25:23', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:25:30', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:25:48', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:26:01', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:26:43', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:27:00', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:29:05', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:29:26', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:30:08', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:33:32', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:43:32', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:45:34', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:54:38', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:54:44', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 01:54:46', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:04:46', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2969);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:13:34', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:15:07', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:25:07', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:27:09', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 02:52:19', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 03:22:19', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 03:52:20', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 04:22:20', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 04:52:21', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 05:22:21', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 05:52:21', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 06:22:22', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 06:52:22', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:21:30', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:23:32', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:23:58', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:24:16', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:34:16', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:36:18', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:54:03', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:55:25', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:56:25', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:56:30', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 07:56:32', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:05:18', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:07:09', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:07:11', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:17:11', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:20:15', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:30:15', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:35:15', 'dd-mm-yyyy hh24:mi:ss'), 2970);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:45:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 08:50:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:00:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:05:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:15:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:20:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:22:28', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:32:28', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:35:15', 'dd-mm-yyyy hh24:mi:ss'), 2971);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:45:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:50:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 09:54:52', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:01:38', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:01:59', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:02:01', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:05:05', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:05:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:15:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:20:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:30:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:35:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:45:15', 'dd-mm-yyyy hh24:mi:ss'), 2972);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 10:50:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:00:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:02:13', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:05:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:15:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:20:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:30:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:35:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:45:15', 'dd-mm-yyyy hh24:mi:ss'), 2973);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 11:50:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:00:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:05:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:06:50', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:16:50', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:20:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:30:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:35:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:45:15', 'dd-mm-yyyy hh24:mi:ss'), 2974);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:50:15', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 12:53:45', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 13:03:45', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 13:05:50', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 13:30:59', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:01:00', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:12:20', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:12:32', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:12:34', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:20:13', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:30:13', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:35:13', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:40:09', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:50:09', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:50:13', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:53:07', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 14:54:09', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:03:59', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:05:13', 'dd-mm-yyyy hh24:mi:ss'), 2975);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:08:50', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:18:14', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:19:33', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:20:13', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:30:13', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:34:04', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:35:13', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:35:23', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:45:23', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 15:47:25', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:12:34', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:42:34', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:46:15', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:46:27', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:46:29', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:48:16', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:54:06', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:54:13', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:54:15', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:57:46', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:57:48', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 16:58:19', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:08:19', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:10:21', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:32:41', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:32:50', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:32:52', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:35:12', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:42:07', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:52:07', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 17:54:10', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:09:26', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:10:07', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:10:51', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:10:55', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:10:57', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:14:26', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:20:13', 'dd-mm-yyyy hh24:mi:ss'), 2976);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:30:13', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:35:13', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:39:38', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:49:38', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 18:51:40', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 19:16:49', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 19:46:50', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 20:16:50', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 20:46:51', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 21:16:51', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 21:46:52', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 22:16:52', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 22:46:52', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 23:16:53', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('15-09-2021 23:46:53', 'dd-mm-yyyy hh24:mi:ss'), 2977);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 00:03:51', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 00:05:53', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 00:31:03', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 01:01:03', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 01:31:03', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 01:56:59', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 01:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 01:57:08', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:09:57', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:19:04', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4035);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:40:35', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:49:53', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 02:59:39', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4036);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:10:42', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:19:08', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:21:37', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:21:44', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:21:46', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:27:34', 'dd-mm-yyyy hh24:mi:ss'), 4036);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:41:31', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:47:17', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:53:28', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:59:33', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:59:41', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 03:59:43', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:15:02', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:16:20', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:16:33', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:24:01', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:24:09', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:24:11', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:31:52', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:35:46', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:36:43', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:46:43', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:48:44', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:52:35', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:52:43', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 04:52:45', 'dd-mm-yyyy hh24:mi:ss'), 4037);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:02:55', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:06:45', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:12:56', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:22:56', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:23:58', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:24:07', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:24:09', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:28:24', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:44:11', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:49:13', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 05:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:01:20', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:10:15', 'dd-mm-yyyy hh24:mi:ss'), 4038);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:14:23', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:44:36', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:46:58', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:56:58', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 06:59:00', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:24:09', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:24:46', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:25:25', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:25:39', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:25:44', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:25:46', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:29:28', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:38:42', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:39:06', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:39:08', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:39:45', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:39:47', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:41:26', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:41:30', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:41:32', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:42:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:43:14', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:44:11', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:44:13', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 07:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4039);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:11:27', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:23:29', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:33:29', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:45:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 08:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4040);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:13:01', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:23:01', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:23:23', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:23:29', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:23:31', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:31:31', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:45:02', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:47:24', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:52:37', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:55:21', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 09:55:23', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4041);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:15:02', 'dd-mm-yyyy hh24:mi:ss'), 4041);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:16:48', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:44:08', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:49:05', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 10:50:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:00:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:03:22', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:15:02', 'dd-mm-yyyy hh24:mi:ss'), 4042);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:35:02', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:42:27', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:52:27', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 11:54:29', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 12:19:39', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 12:49:39', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 12:54:49', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 12:54:58', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 12:55:00', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:05:02', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4043);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:30:02', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('15-09-2021 13:33:25', 'dd-mm-yyyy hh24:mi:ss'), 4044);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:12:33', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:13:50', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:23:50', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:25:52', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:33:58', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:34:06', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:34:08', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:42:50', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:48:42', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:51:29', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:57:12', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:57:39', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:58:11', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:02:07', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:02:41', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:03:46', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:05:02', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:09:46', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:09:53', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:19:53', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:21:55', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 22:47:05', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:17:05', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:36:06', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:36:14', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:36:16', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:49:47', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:54:46', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 23:58:53', 'dd-mm-yyyy hh24:mi:ss'), 5126);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:00:11', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:03:41', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:04:10', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:04:14', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:09:02', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:14:25', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:14:50', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:16:29', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:16:39', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:21:51', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:23:12', 'dd-mm-yyyy hh24:mi:ss'), 5111);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:23:56', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:24:14', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:24:16', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:25:01', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:25:12', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:25:16', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:25:59', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:26:16', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:27:53', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:28:21', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:28:36', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:29:37', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:29:43', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:30:32', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:31:30', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:31:50', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:32:17', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:32:23', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:32:47', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:35:05', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:35:20', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:36:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:49:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:53:27', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 00:55:26', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:02:36', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:19:48', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:21:44', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:21:50', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:06', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:08', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:12', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:34', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:52', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:54', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:22:59', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:32:59', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:35:01', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:51:45', 'dd-mm-yyyy hh24:mi:ss'), 5112);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:51:53', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:51:55', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:52:39', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:56:38', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:57:25', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 01:57:35', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:07:35', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:13:16', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:20:02', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:23:31', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:26:26', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:27:01', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:27:43', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:29:18', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:30:19', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:33:53', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:36:46', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:37:07', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:38:19', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:40:38', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:44:13', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:46:18', 'dd-mm-yyyy hh24:mi:ss'), 5113);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:55:02', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:56:05', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:56:39', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:56:44', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:57:12', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 02:59:56', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:02:10', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:03:43', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:08:14', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:09:26', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:21:35', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:30:42', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:31:31', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:36:09', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:46:21', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:47:28', 'dd-mm-yyyy hh24:mi:ss'), 5114);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 03:51:57', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 04:01:57', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 04:03:58', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 04:29:07', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 04:59:07', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 05:29:08', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 05:59:08', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 06:29:09', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 06:59:09', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:07:57', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:08:43', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:09:00', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:09:05', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:09:07', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:12:29', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:13:22', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:19:18', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:19:27', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:19:29', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:20:06', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:21:53', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:22:25', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:27:31', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:33:59', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:34:28', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:34:30', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:35:05', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:35:07', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:36:40', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:36:43', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:36:45', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:37:12', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:37:42', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:37:53', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:37:55', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:38:55', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5115);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:41:41', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:46:15', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:52:34', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:52:50', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:53:26', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:53:32', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:53:41', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:54:02', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:55:06', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 07:59:21', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:01:00', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:01:12', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:01:50', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:06:01', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:09:48', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:15:21', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:15:25', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:15:34', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:15:53', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:16:04', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:16:44', 'dd-mm-yyyy hh24:mi:ss'), 5115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:21:58', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:22:50', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:27:45', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:27:59', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:28:47', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:29:13', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:30:45', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:33:57', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:34:05', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:34:07', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:38:38', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:40:11', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:40:55', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:44:42', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:45:46', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:49:17', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:49:44', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:54:16', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:54:26', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:54:28', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:54:48', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:59:30', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 08:59:42', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:02:26', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:03:59', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:14:22', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:15:30', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:22:07', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:22:15', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:22:17', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:22:31', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:24:28', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:24:48', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:25:12', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:32:14', 'dd-mm-yyyy hh24:mi:ss'), 5116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:34:07', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:34:11', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:34:13', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:36:24', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:43:10', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:43:15', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:48:35', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 09:58:15', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:05:10', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:05:50', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:07:23', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:07:57', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:08:32', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:08:45', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:09:19', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:12:25', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:15:10', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:16:00', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:16:21', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:16:24', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:19:26', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:22:14', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:22:31', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:25:03', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:25:54', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:26:27', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:28:14', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:29:12', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:29:55', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:39:55', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:41:56', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:47:19', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:47:27', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:47:38', 'dd-mm-yyyy hh24:mi:ss'), 5117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:47:44', 'dd-mm-yyyy hh24:mi:ss'), 5117);
commit;
prompt 2400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:50:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:54:22', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:54:58', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 10:55:50', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:00:52', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:02:26', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:05:25', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:10:20', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:10:39', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:12:42', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:12:44', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:12:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:16:48', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:17:23', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:18:41', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:20:54', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:25:46', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:33:20', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:35:13', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:36:58', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:38:05', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:39:22', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:39:54', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:40:05', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:40:10', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:41:36', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:42:31', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:44:27', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:47:03', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:47:11', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:47:13', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:48:29', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:50:16', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:53:57', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:55:00', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:55:14', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:55:38', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 11:56:14', 'dd-mm-yyyy hh24:mi:ss'), 5118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:03:07', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:06:18', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:07:44', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:08:48', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:12:23', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:14:48', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:16:00', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:18:13', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:20:46', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:21:03', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:24:10', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:28:53', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:30:33', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:33:07', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:33:39', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:34:08', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:34:22', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:34:49', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:39:13', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:39:37', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:43:31', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:45:47', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:46:55', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:47:41', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:48:27', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 12:58:27', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 13:00:29', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 13:25:39', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 13:55:39', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:06:15', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:06:33', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:06:35', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:12:15', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:12:51', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:14:44', 'dd-mm-yyyy hh24:mi:ss'), 5119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:16:11', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:23:33', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:32:20', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:32:32', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:37:23', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:38:19', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:38:50', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:07', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:10', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:17', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:41', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:46:35', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:48:06', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:48:34', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:50:01', 'dd-mm-yyyy hh24:mi:ss'), 5120);
commit;
prompt 2500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:53:43', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:57:36', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 14:57:40', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:00:26', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:00:30', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:07:16', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:09:00', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:11:12', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:18:09', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:18:17', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:18:19', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:19:23', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:19:34', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:21:34', 'dd-mm-yyyy hh24:mi:ss'), 5120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:22:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:29:46', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:32:13', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:32:39', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:36:32', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:36:46', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:43:03', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:43:19', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:44:49', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:45:27', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:45:36', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:47:19', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:49:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 15:59:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:01:49', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:02:14', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:02:21', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:02:24', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:06:16', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:06:37', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:08:50', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:09:26', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:19:26', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:21:29', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:46:39', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:47:17', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:47:43', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:47:56', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:48:01', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:48:03', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:48:15', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:52:20', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:52:52', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:53:45', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 16:57:02', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:04:20', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:07:10', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:13:34', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:13:43', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:13:45', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:14:06', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:14:58', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:15:04', 'dd-mm-yyyy hh24:mi:ss'), 5121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:23:19', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:23:34', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:24:49', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:25:00', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:31:20', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:31:25', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:31:42', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:31:44', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:33:59', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:44:29', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:44:37', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:44:57', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:47:12', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 17:59:14', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:02:19', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:10:59', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:11:03', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:11:05', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:18', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:20', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:22', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:24', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:27', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:14:31', 'dd-mm-yyyy hh24:mi:ss'), 5122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:23:14', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:26:45', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:37', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:39', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:41', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:44', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:47', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:50', 'dd-mm-yyyy hh24:mi:ss'), 5123);
commit;
prompt 2600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:52', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:27:54', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:28:02', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:31:00', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:31:17', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:32:22', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:33:11', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:33:25', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:33:52', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:34:50', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:37:50', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:39:31', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:49:38', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 18:51:10', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:01:10', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:02:54', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:03:03', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:03:11', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:07:42', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:17:42', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:19:44', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:25:55', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:26:02', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:26:04', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:36:04', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:38:59', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:39:52', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:39:56', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:41:49', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:43:05', 'dd-mm-yyyy hh24:mi:ss'), 5123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:53:05', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 19:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:04:47', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:09:21', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:10:06', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:17:38', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:24:47', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:25:31', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:30:06', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:31:44', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:32:12', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:33:10', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:35:42', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:39:47', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:41:53', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:43:43', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:46:23', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:47:01', 'dd-mm-yyyy hh24:mi:ss'), 5124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:48:22', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:50:43', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:54:47', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 20:57:45', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:07:45', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('15-09-2021 21:09:47', 'dd-mm-yyyy hh24:mi:ss'), 5125);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5940);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 00:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:18:27', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:28:28', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:30:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:32:08', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:32:21', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:32:23', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 01:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5941);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 02:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 02:02:41', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 02:12:41', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 02:14:43', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 02:39:53', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 03:09:53', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 03:39:54', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 04:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 04:39:55', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 05:09:55', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 05:39:55', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 06:09:56', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 06:39:56', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:09:57', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:10:30', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:11:01', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:11:24', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:11:28', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:11:30', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:16:03', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:21:05', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:21:30', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:21:32', 'dd-mm-yyyy hh24:mi:ss'), 5942);
commit;
prompt 2700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:21:54', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:21:56', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:22:34', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:23:30', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:23:34', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:23:36', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:24:00', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:24:13', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:24:23', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:24:25', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:34:25', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 07:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5942);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 08:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5943);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 09:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5944);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:47:17', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 10:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5945);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:41:21', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:51:21', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 11:53:22', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:03:53', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:04:02', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:04:04', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:09:39', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:19:39', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:21:40', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 12:46:49', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 13:16:50', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 13:46:50', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 14:16:50', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 14:46:51', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 15:16:51', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 15:46:52', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:16:52', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:46:53', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:47:22', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:48:05', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:48:23', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:48:28', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:48:30', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 16:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5946);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 17:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5947);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 18:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5948);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:26:07', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:36:07', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:38:55', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:48:55', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 19:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5949);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:15:43', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
commit;
prompt 2800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:43:14', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 20:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:02:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5950);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:47:48', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:49:57', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 21:59:57', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:02:01', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:27:10', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:49:27', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:49:33', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:49:35', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 22:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:07:29', 'dd-mm-yyyy hh24:mi:ss'), 5951);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:17:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:22:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:32:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:37:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:47:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('15-09-2021 23:52:29', 'dd-mm-yyyy hh24:mi:ss'), 5952);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:02:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:04:00', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:09:13', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:11:02', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:12:08', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:13:24', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:15:11', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:21:45', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:31:46', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:33:47', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 00:58:56', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:28:56', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:35:21', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:35:31', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:35:33', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:44:00', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:54:00', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 01:56:02', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:01:08', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:01:15', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:01:17', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:07:04', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:17:04', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:19:05', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 02:44:14', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 03:14:14', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 03:44:15', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 04:14:15', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 04:44:16', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 05:14:16', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 05:44:17', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:14:17', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:44:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:47:17', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:47:58', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:48:14', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:48:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:48:20', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:48:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 06:58:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:00:33', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:06:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:06:20', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:17:38', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:18:06', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:18:09', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:18:16', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:18:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:19:37', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:19:40', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:19:42', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:20:02', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:20:54', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:21:03', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:21:05', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:23:59', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:33:59', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:36:02', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:46:12', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:46:20', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:46:22', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:56:22', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 07:57:56', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:07:56', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:08:19', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:08:44', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:18:44', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:20:46', 'dd-mm-yyyy hh24:mi:ss'), 3118);
commit;
prompt 2900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 08:45:55', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:00:40', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:00:53', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:00:55', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:04:14', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:04:28', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:08:09', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:08:36', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:09:20', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:14:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:24:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:26:31', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:35:26', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:35:38', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:35:40', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:38:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:39:18', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:40:48', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:42:34', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:47:49', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:52:43', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:55:01', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:55:25', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:59:00', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 09:59:17', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:04:48', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:10:34', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:15:58', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:16:31', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:17:07', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:17:40', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:18:18', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:19:06', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:19:51', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:20:20', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:20:44', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:21:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:27:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:32:39', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:33:55', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:43:55', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:45:57', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:50:51', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:51:01', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:51:03', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:55:56', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 10:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 11:03:47', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 11:13:47', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 11:15:49', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 11:40:59', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 12:10:59', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 12:41:00', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:11:00', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:36:22', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:36:31', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:36:33', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:37:17', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:39:15', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:40:18', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:41:25', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:41:36', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:42:22', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:42:44', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:43:45', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:48:20', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 13:53:57', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:03:57', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:05:59', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:16:29', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 00:19:01', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 00:49:02', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 01:19:02', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 01:49:03', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 02:19:03', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 02:49:03', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 03:19:04', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 03:49:04', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 04:19:05', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 04:49:05', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 05:19:06', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 05:49:06', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 06:19:07', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 06:49:07', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 07:19:07', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 07:49:08', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 08:19:08', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 08:49:09', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 09:19:09', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 09:49:10', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 10:19:10', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 10:49:11', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 11:19:11', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 11:49:11', 'dd-mm-yyyy hh24:mi:ss'), 1786);
commit;
prompt 3000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 12:19:12', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 12:49:12', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 13:19:13', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 13:49:13', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 14:19:14', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 14:49:14', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 15:19:15', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 15:49:15', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 16:19:15', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 16:49:16', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 17:19:16', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 17:49:17', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 18:19:17', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 18:49:18', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 19:19:18', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 19:49:19', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 20:19:19', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 20:49:19', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 21:19:20', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 21:49:20', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 22:19:21', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 22:49:21', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 23:19:22', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('15-09-2021 23:49:22', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 00:23:31', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 00:53:31', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 01:23:31', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 01:53:32', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 02:23:32', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 02:53:33', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 03:23:33', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 03:53:34', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 04:23:34', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 04:53:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 05:23:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 05:53:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 06:23:36', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 06:53:36', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:08:55', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:09:44', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:10:00', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:10:05', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:10:07', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:10:08', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:16:15', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:16:21', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:16:23', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:19:03', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:19:05', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:19:09', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:19:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:29:35', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:31:39', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:36:45', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:36:51', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:36:53', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:37:08', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:37:32', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:38:17', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:38:44', 'dd-mm-yyyy hh24:mi:ss'), 463);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:45:44', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:47:41', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:47:48', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:47:50', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:49:38', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:49:42', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:49:44', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:50:04', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:50:18', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:50:29', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:50:31', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:50:33', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:52:14', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 07:55:39', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:05:09', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:07:11', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:12:13', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:15:36', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:15:42', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:15:44', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:18:57', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:20:09', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:28:04', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:29:29', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:29:35', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:29:37', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:31:59', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:35:09', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:43:37', 'dd-mm-yyyy hh24:mi:ss'), 464);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:50:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 08:51:26', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:01:26', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:03:30', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:28:39', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:44:26', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:44:34', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:44:36', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:45:40', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 09:50:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:00:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
commit;
prompt 3100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:05:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:15:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:20:03', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:20:09', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:28:13', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:32:08', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:37:05', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:37:14', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:37:16', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:38:42', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:39:30', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:43:12', 'dd-mm-yyyy hh24:mi:ss'), 465);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:50:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:57:31', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 10:57:54', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:05:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:08:54', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:11:36', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:17:50', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:18:07', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:18:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:20:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:24:11', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:34:11', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:36:13', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:42:35', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:42:41', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:42:43', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:43:07', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:51:05', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:51:12', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:51:14', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:51:59', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:53:01', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:53:08', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:53:10', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:53:17', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:54:01', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:55:27', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:55:33', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:55:35', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:55:51', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 11:56:50', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:02:31', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:02:37', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:02:39', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:04:08', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:05:57', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:06:04', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:06:06', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:06:07', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:06:58', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:10:52', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:11:00', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:11:02', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:20:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:21:20', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:21:53', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:22:58', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:24:50', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:31:24', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:31:30', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:31:32', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:32:06', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:33:14', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:35:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:36:21', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:46:21', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 12:48:23', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:13:33', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:43:33', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:03', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:09', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:11', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:23', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:37', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 13:59:57', 'dd-mm-yyyy hh24:mi:ss'), 466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:05:09', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:05:11', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:06:26', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:14:43', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:14:51', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:17:15', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:17:55', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:20:09', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:26:23', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:27:14', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:27:21', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:27:23', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:27:39', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:28:36', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:28:52', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:28:54', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:29:45', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:37:06', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:37:13', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:37:15', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:38:10', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:46:23', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:46:31', 'dd-mm-yyyy hh24:mi:ss'), 467);
commit;
prompt 3200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:46:33', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:47:06', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:47:26', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:50:09', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 14:54:29', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:00:16', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:00:46', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:00:53', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:00:55', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:05:09', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:11:19', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:16:34', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:17:13', 'dd-mm-yyyy hh24:mi:ss'), 467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:20:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:22:02', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:32:02', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:34:05', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:40:30', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:40:56', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:41:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:41:14', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:41:16', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:41:21', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:42:06', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:50:43', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:50:49', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:50:51', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:50:53', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:51:37', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:52:55', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:53:02', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:53:04', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 15:56:56', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:06:56', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:09:00', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:34:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:58:34', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:58:41', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:58:43', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:59:23', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 16:59:45', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:03:00', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:13:00', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:15:04', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:37:07', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:37:16', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:37:18', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:37:22', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:38:21', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:44:02', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:44:23', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:50:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:51:02', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 17:54:48', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:04:48', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:04:52', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:05:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:15:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:20:09', 'dd-mm-yyyy hh24:mi:ss'), 468);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:24:28', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:34:28', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:35:09', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:37:50', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:46:47', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:46:53', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:46:55', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:50:09', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:50:30', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:50:38', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 18:50:40', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 19:00:40', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 19:02:33', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 19:27:42', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 19:57:42', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 20:27:43', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 20:57:43', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 21:27:44', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 21:57:44', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 22:27:45', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 22:57:45', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 23:27:45', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('15-09-2021 23:57:46', 'dd-mm-yyyy hh24:mi:ss'), 469);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 00:13:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 00:43:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 01:13:13', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 01:43:13', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:00:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:00:43', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:00:45', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:03:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:13:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:15:15', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 02:40:25', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 03:10:25', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 03:40:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 04:10:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 04:40:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 05:10:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 05:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 06:10:28', 'dd-mm-yyyy hh24:mi:ss'), 3115);
commit;
prompt 3300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 06:40:28', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:10:29', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:16:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:17:38', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:18:00', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:18:05', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:18:07', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:21:50', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:30:40', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:02', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:36', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:31:38', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:33:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:33:12', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:33:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:33:38', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:35:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:35:34', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:35:37', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:39:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:49:14', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 07:51:16', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 08:16:25', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 08:46:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:16:26', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:24:36', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:24:49', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:35:44', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:35:46', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:37:08', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:38:04', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:38:50', 'dd-mm-yyyy hh24:mi:ss'), 3115);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:39:07', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:42:54', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:47:25', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:49:20', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:49:31', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:51:02', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:52:45', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:55:40', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:59:32', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 09:59:41', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:00:14', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:00:50', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:02:08', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:02:47', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:03:57', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:11:22', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:12:26', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:12:56', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:16:41', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:17:35', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:20:46', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:21:18', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:23:17', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:23:42', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:26:28', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:29:29', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:32:51', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:34:24', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:35:09', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:35:20', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:36:40', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:37:24', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:38:19', 'dd-mm-yyyy hh24:mi:ss'), 3116);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:39:45', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:40:15', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:40:59', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:44:03', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:48:19', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:51:28', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 10:52:12', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 11:02:12', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 11:04:13', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 11:29:22', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 11:59:23', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:03:08', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:03:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:03:20', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:03:37', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:04:06', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:09:22', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:12:39', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:12:47', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:13:00', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:13:07', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:14:18', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:14:37', 'dd-mm-yyyy hh24:mi:ss'), 3117);
commit;
prompt 3400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:18:56', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:28:09', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:29:46', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:33:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:34:22', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:41:19', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:43:12', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:45:19', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:47:51', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3117);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:50:55', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:51:14', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:52:42', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:53:16', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:56:15', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:56:53', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:58:05', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:58:27', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:58:57', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 12:59:00', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:09:00', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:11:02', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:36:11', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:59:46', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:59:56', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 13:59:58', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:01:57', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:08:07', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:14:01', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:18:23', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:19:39', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:22:20', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:26:12', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:27:51', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:29:00', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:29:36', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:30:01', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:33:13', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:34:31', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:35:06', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:40:43', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:46:09', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3118);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:53:26', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:56:44', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:57:56', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:58:14', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:59:44', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 14:59:59', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:01:22', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:01:51', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:02:52', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:04:05', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:05:31', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:06:17', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:07:00', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:08:19', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:08:35', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:09:57', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:14:11', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:15:27', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:20:49', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:24:12', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:25:27', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:27:40', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:27:56', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:30:43', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:30:55', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:31:15', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:32:04', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:32:37', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:33:48', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:34:24', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:35:07', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:35:25', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:35:39', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:36:59', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:37:34', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:37:43', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:38:23', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:38:38', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:40:01', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:45:50', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3119);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:50:23', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:52:12', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:52:36', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:53:18', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:56:29', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 15:56:56', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:01:07', 'dd-mm-yyyy hh24:mi:ss'), 3120);
commit;
prompt 3500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:01:22', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:02:00', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:02:35', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:03:56', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:04:26', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:04:41', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:05:15', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:05:46', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:06:12', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:06:55', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:07:39', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:08:44', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:10:21', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:10:43', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:14:10', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:15:06', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:20:21', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:22:29', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:23:04', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:24:19', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:24:36', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:27:51', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:37:51', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 16:39:52', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:00:45', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:01:26', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:01:47', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:01:51', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:01:53', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:05:19', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:07:52', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:15', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:17', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:36', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:38', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:45', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:08:47', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:09:54', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:09:57', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:09:59', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:10:38', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:10:51', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:11:00', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:11:02', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:16:21', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:26:21', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:28:22', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:42:28', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:42:40', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:42:42', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:44:50', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:48:08', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:49:24', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:49:43', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:50:41', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 17:51:57', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:01:46', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:11:46', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:13:27', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:13:36', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:13:38', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:14:52', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:24:52', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:26:15', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:26:23', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:26:25', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:30:45', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:31:09', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:32:43', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:32:53', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:33:13', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:33:27', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:33:37', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:34:20', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:35:25', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:36:12', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:36:44', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:37:29', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:37:59', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:39:24', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:40:17', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:41:38', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:42:37', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:43:33', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:44:24', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:45:30', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:46:30', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:47:28', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:48:16', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:49:17', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:50:07', 'dd-mm-yyyy hh24:mi:ss'), 3121);
commit;
prompt 3600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:51:05', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:52:48', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:53:42', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:54:39', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:56:06', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:57:32', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 18:58:43', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:01:25', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:02:49', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:05:23', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:10:05', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:10:25', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:10:27', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:14:40', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:18:00', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:19:40', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:16:37', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:16:39', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:21:51', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:27:05', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:33:02', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:42:05', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:42:55', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:42:58', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:46:19', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:47:46', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:49:34', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:50:46', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:58:14', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 14:59:07', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:00:31', 'dd-mm-yyyy hh24:mi:ss'), 3120);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:02:36', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:04:03', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:06:22', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:09:49', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:12:05', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:18:36', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:20:13', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:20:44', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:21:12', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:22:33', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:23:19', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:25:07', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:27:05', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:28:45', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:29:52', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:30:51', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:31:25', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:33:18', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:34:47', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:35:23', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:35:44', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:38:13', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:39:18', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:42:09', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:43:27', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:43:43', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:45:23', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:46:23', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:49:15', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:50:55', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:52:14', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:57:04', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 15:57:49', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:00:20', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:00:45', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:01:15', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:01:37', 'dd-mm-yyyy hh24:mi:ss'), 3121);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:05:20', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:06:35', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:08:37', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:08:51', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:09:25', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:09:51', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:10:25', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:10:38', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:11:16', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:12:00', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:12:04', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:12:28', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:13:11', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:13:20', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:14:04', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:14:55', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:16:40', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:17:12', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:17:22', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:17:45', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:18:19', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:28:19', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:30:20', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 16:55:29', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:07:19', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:07:36', 'dd-mm-yyyy hh24:mi:ss'), 3122);
commit;
prompt 3700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:07:41', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:07:43', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:12:04', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:14:21', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:15:05', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:15:07', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:16:18', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:16:21', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:16:23', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:16:49', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:19:37', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:19:47', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:19:49', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:27:04', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:27:35', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:15', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:35', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:36', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:39', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:46', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:31:48', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:35:36', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:36:24', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:38:25', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:39:47', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:42:54', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:43:25', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:46:13', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:46:54', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:48:24', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:49:00', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:49:34', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:50:31', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:50:58', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:51:09', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:51:37', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:52:03', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:52:23', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:53:26', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:55:34', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:57:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 17:58:15', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:01:11', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:01:43', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:04:44', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:05:14', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:07:02', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:07:27', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:08:13', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:09:27', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:09:55', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:10:56', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:11:28', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:12:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:12:52', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:13:03', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:13:35', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:14:25', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:14:56', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:15:31', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:16:10', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:16:36', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:18:19', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:21:52', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:22:05', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:23:00', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:27:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:30:10', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:30:42', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:31:46', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:41:46', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 18:43:48', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:08:58', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:29:37', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:30:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:30:18', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:30:22', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:30:24', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:40:24', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:41:38', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:42:44', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:43:04', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:43:20', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:43:27', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:44:06', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:45:43', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:46:20', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:46:39', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:47:14', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:47:35', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:48:22', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:48:51', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:49:49', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:51:26', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:51:46', 'dd-mm-yyyy hh24:mi:ss'), 3124);
commit;
prompt 3800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:53:14', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:54:38', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:55:29', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:56:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:57:12', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:57:37', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:58:10', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:59:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:59:38', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 19:59:50', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:00:27', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:01:06', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:01:13', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:02:01', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:03:14', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:03:44', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:03:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:05:04', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:05:51', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:07:48', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:08:16', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:08:52', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:10:15', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:10:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:20:57', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:22:59', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 20:48:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 21:18:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 21:48:09', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:18:10', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:26:44', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:26:53', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:26:55', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:27:04', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:31:01', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:31:14', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:32:03', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:32:51', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:33:37', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:35:19', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:35:40', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:36:15', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:36:23', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:39:08', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:49:08', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 22:51:10', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 23:16:20', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('15-09-2021 23:46:20', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:23:45', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:25:40', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:29:24', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:31:44', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:35:55', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:37:48', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:42:03', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:43:10', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:44:08', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:48:33', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:50:53', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:52:47', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:55:41', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:56:11', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 19:56:31', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:02:16', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:03:21', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:03:31', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:05:17', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:06:33', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:07:02', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:08:11', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:08:49', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:09:00', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:10:14', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:10:24', 'dd-mm-yyyy hh24:mi:ss'), 3122);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:24:12', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:25:05', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:25:51', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:35:51', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:37:53', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:55:50', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:55:56', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:55:58', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:56:44', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 20:57:34', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 21:07:34', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 21:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 21:34:45', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:04:45', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:29:38', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:29:46', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:29:48', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:31:20', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:32:15', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:33:11', 'dd-mm-yyyy hh24:mi:ss'), 3123);
commit;
prompt 3900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:35:36', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:36:18', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:36:56', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:37:46', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:38:59', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:39:28', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:39:50', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:39:57', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:40:18', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:40:55', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:42:00', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:43:19', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:44:53', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:46:47', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:47:08', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:47:35', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:48:34', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:49:30', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:49:50', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:50:55', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:52:10', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:53:26', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:54:38', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:54:53', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:56:01', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 22:59:27', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:01:01', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:02:40', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:04:30', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:05:46', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:08:02', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:08:58', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:10:40', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:11:15', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:11:44', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:12:09', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:12:49', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:13:36', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:14:43', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:15:42', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:16:18', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:17:01', 'dd-mm-yyyy hh24:mi:ss'), 3123);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:18:06', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:18:34', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:19:13', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:19:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:19:43', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:20:10', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:22:12', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:22:37', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:23:19', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:24:21', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:25:01', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:28:33', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:34:30', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:38:05', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:38:47', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:48:47', 'dd-mm-yyyy hh24:mi:ss'), 3124);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('15-09-2021 23:50:49', 'dd-mm-yyyy hh24:mi:ss'), 3124);
commit;
prompt 3961 records loaded
set feedback on
set define on
prompt Done.
