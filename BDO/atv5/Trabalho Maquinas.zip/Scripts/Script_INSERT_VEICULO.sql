﻿prompt PL/SQL Developer import file
prompt Created on segunda-feira, 20 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading VEICULO...
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (20, 'TMHM-1476', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (23, 'TMHM-1475', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (24, 'TMHM-1492', '8FGC70U');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (29, 'TMHM-1478', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (30, 'TMHM-1479', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (31, 'TMHM-1484', '8FG30B');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (32, 'TMHM-1489', '8FGJ35');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (33, 'TMHM-1483', '8FG30B');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (34, 'TMHM-1477', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (35, 'TMHM-1480', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (36, 'TMHM-1481', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (37, 'TMHM-1482', '8FG25');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (38, 'TMHM-1486', '8FGJ35');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (39, 'TMHM-1485', '8FGJ35');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (45, 'TMHM-1402', '8FG30B');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (46, 'TMHM-954', '8FG30B');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (47, 'TMHM-1490', '8FG45N');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (48, 'TMHM-1491', '8FG45N');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (49, 'TMHM-1487', '8FG30');
insert into VEICULO (ID_VEICULO, NUMERO_FROTA, MODELO)
values (50, 'TMHM-1488', '8FG30');
commit;
prompt 20 records loaded
set feedback on
set define on
prompt Done.
