﻿prompt PL/SQL Developer import file
prompt Created on quarta-feira, 22 de setembro de 2021 by Luciano Calderoni
set feedback off
set define off
prompt Loading DADOS_RASTREADOR...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 00:28:16', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 00:58:16', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 01:28:17', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 01:58:17', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 02:28:18', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 02:58:18', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 03:28:19', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 03:58:19', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 04:28:19', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 04:58:20', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 05:28:20', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 05:58:21', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 06:28:21', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 06:58:22', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:06:26', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:07:08', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:07:28', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:07:33', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:07:35', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:09:38', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:19:38', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:21:42', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 07:46:51', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:01:13', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:01:23', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:01:25', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:01:31', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:02:36', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:12:36', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:14:38', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 08:39:48', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 09:09:48', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 09:39:49', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 10:09:49', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 10:39:49', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:09:50', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:27:43', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:27:54', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:27:56', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:31:31', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:41:31', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:42:52', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:52:52', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 11:54:56', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 12:20:05', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 12:50:06', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 13:20:06', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 13:50:06', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 14:20:07', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 14:50:07', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:14:41', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:14:56', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:14:58', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:16:30', 'dd-mm-yyyy hh24:mi:ss'), 1466);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:17:16', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:27:16', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:28:04', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:28:11', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:28:13', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:31:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:41:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:44:52', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:46:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 15:56:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:01:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:11:30', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:22:39', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:24:43', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 16:49:53', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 17:19:53', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 17:49:54', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 18:19:54', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 18:49:55', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 19:19:55', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 19:49:56', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 20:19:56', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 20:49:56', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 21:19:57', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 21:49:57', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 22:19:58', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 22:49:58', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 23:19:59', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (24, to_date('13-09-2021 23:49:59', 'dd-mm-yyyy hh24:mi:ss'), 1467);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 00:21:23', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 00:51:23', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 01:21:23', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 01:51:24', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 02:21:24', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 02:51:25', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 03:21:25', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 03:51:26', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 04:21:26', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 04:51:27', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 05:21:27', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 05:51:27', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 06:21:28', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 06:51:28', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 07:21:29', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 07:51:29', 'dd-mm-yyyy hh24:mi:ss'), 251);
commit;
prompt 100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 08:21:30', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 08:51:30', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 09:21:31', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 09:51:31', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:21:31', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:24:42', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:26:56', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:27:09', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:27:14', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:27:16', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:28:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:29:48', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:39:04', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:39:07', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:40:48', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:40:50', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:42:13', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:43:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:53:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:58:11', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 10:59:45', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:00:05', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:05:56', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:06:20', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:16:20', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:18:22', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 11:43:31', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 12:13:31', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 12:43:32', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 13:13:32', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 13:43:33', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 14:13:33', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 14:43:34', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 15:13:34', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 15:43:35', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 16:13:35', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 16:43:35', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 17:13:36', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 17:43:36', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 18:13:37', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 18:43:37', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 19:13:38', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 19:43:38', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 20:13:39', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 20:43:39', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 21:13:40', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 21:43:40', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 22:13:40', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 22:43:41', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 23:13:41', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (20, to_date('13-09-2021 23:43:42', 'dd-mm-yyyy hh24:mi:ss'), 251);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 00:27:02', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 00:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 01:27:02', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 01:57:03', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 02:27:03', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 02:57:04', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 03:27:04', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 03:57:05', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 04:27:05', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 04:57:06', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 05:27:06', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 05:57:06', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 06:27:07', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 06:57:07', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:27:08', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:42:30', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:43:19', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:43:58', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:44:03', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:44:05', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:46:26', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1302);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:49:53', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 07:59:53', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:02:39', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:06:13', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:16:13', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:17:44', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:17:51', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:17:53', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:17:55', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:20:22', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:23:39', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:37:28', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:43:23', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 08:51:20', 'dd-mm-yyyy hh24:mi:ss'), 1303);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:01:20', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:02:39', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:12:39', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:14:13', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:17:04', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:19:36', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:19:44', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:19:46', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:22:16', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:29:13', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:30:13', 'dd-mm-yyyy hh24:mi:ss'), 1304);
commit;
prompt 200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:30:15', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:30:22', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:31:49', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:32:06', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:32:08', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:35:38', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:39:56', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:40:18', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:40:20', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:41:03', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:51:03', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 09:53:05', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:10:11', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:10:20', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:10:23', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:13:34', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:18:43', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:18:57', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:18:59', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:20:41', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:30:41', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:32:43', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 10:57:52', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 11:27:53', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 11:57:53', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 12:27:54', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 12:52:58', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 12:53:23', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 12:53:25', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 12:57:12', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:07:12', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:09:14', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:30:03', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:30:12', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:30:14', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:33:14', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:34:05', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:34:13', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:34:15', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:35:22', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:38:41', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:38:57', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:38:59', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:40:02', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:41:37', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:44:17', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:44:23', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:44:25', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:46:10', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:48:24', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:48:33', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:48:35', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:48:36', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 13:57:14', 'dd-mm-yyyy hh24:mi:ss'), 1304);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:02:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:12:14', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:17:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:20:30', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:27:06', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:27:37', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:42:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 14:53:25', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:02:22', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:02:30', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:02:32', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:02:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:06:32', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:06:43', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:16:43', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:18:45', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:32:05', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:32:11', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:32:13', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:32:39', 'dd-mm-yyyy hh24:mi:ss'), 1305);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:42:56', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:46:55', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:47:39', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:55:37', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 15:56:11', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 16:06:11', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 16:08:13', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 16:33:23', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 17:03:23', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 17:33:24', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 18:03:24', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 18:33:24', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 19:03:25', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 19:33:25', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 20:03:26', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 20:33:26', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 21:03:27', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 21:33:27', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 22:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 22:33:28', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 23:03:28', 'dd-mm-yyyy hh24:mi:ss'), 1306);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (23, to_date('13-09-2021 23:33:29', 'dd-mm-yyyy hh24:mi:ss'), 1306);
commit;
prompt 300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 00:13:43', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 00:43:44', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 01:13:44', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 01:43:44', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 02:13:45', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 02:43:45', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 03:13:46', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 03:43:46', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 04:13:47', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 04:43:47', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 05:13:47', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 05:43:48', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 06:13:48', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 06:43:49', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:13:49', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:14:06', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:14:42', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:15:07', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:15:12', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:15:14', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:16:33', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:19:08', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:26:45', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:07', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:09', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:26', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:29', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:44', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:27:46', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:29:00', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:29:04', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:29:06', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:29:32', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:30:21', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:30:35', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:30:37', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:31:48', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:33:17', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:33:23', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:33:25', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:43:25', 'dd-mm-yyyy hh24:mi:ss'), 4982);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:46:33', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:46:48', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 07:56:48', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:10:54', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:14:18', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:14:26', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:14:28', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:43:11', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4983);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 08:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:05:07', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:13:46', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:13:53', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:13:55', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:30:08', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:30:40', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:37:14', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:37:21', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:37:23', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 09:50:43', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:00:43', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4984);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:04:13', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:14:15', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:14:23', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:14:25', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:16:33', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:23:10', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:46:11', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:46:33', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 10:54:49', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:04:49', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:06:51', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:07:34', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:07:41', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:07:43', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:18:15', 'dd-mm-yyyy hh24:mi:ss'), 4985);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:28:15', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:37:15', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:46:33', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:49:08', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:51:04', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:51:50', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 11:51:52', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4986);
commit;
prompt 400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:09:39', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:10:17', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:10:23', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:10:25', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:18:55', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:28:55', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:30:55', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:36:50', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:37:00', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:37:02', 'dd-mm-yyyy hh24:mi:ss'), 4986);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:49:24', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:49:44', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:49:51', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:49:53', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 12:56:11', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 13:06:11', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 13:08:13', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 13:33:23', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:03:23', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:05:23', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:05:30', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:05:32', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:15:33', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:53:39', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:56:06', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:56:14', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:56:16', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 14:57:43', 'dd-mm-yyyy hh24:mi:ss'), 4987);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:00:33', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:00:39', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:00:41', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:13:57', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:18:32', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:18:40', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:18:42', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:21:52', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:22:08', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:22:15', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:22:17', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:36:11', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:36:25', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:44:54', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:45:00', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:45:02', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 15:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:12:35', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:22:35', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:24:36', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:49:46', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:56:15', 'dd-mm-yyyy hh24:mi:ss'), 4988);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:56:50', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:57:07', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 16:57:09', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:04:26', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:12:29', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:12:52', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:12:54', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:13:15', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:13:16', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:13:24', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:13:26', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:14:41', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:14:45', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:14:47', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:15:11', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:15:53', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:16:10', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:16:12', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:32:12', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:41:18', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:51:18', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 17:53:20', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:14:24', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:14:31', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:14:33', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:17:43', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:22:30', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:22:37', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:22:39', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4989);
commit;
prompt 500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:44:26', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:47:09', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:47:17', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:47:19', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:47:21', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 18:55:09', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:11:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:13:50', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:13:59', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:14:36', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:14:50', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:14:54', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:14:56', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4990);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 19:58:18', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:11:10', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4991);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 20:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:01:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:11:14', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:23:07', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:42:29', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:52:29', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 21:54:31', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:19:41', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:34:41', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:35:49', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:36:01', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:36:05', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:36:07', 'dd-mm-yyyy hh24:mi:ss'), 4992);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:44:49', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 22:56:34', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:01:35', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:06:10', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:16:10', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:16:34', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:26:34', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:31:34', 'dd-mm-yyyy hh24:mi:ss'), 4993);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:41:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:46:11', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:46:34', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:49:40', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (31, to_date('13-09-2021 23:59:40', 'dd-mm-yyyy hh24:mi:ss'), 4994);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 00:24:19', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 00:54:19', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 01:24:20', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 01:54:20', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 02:24:21', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 02:54:21', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 03:24:22', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 03:54:22', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 04:24:22', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 04:54:23', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 05:24:23', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 05:54:24', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 06:24:24', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 06:54:25', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:21:50', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:23:34', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:23:35', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:26:35', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:27:47', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:28:02', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 07:38:02', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:03:12', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:10:41', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:10:49', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:10:53', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:11:42', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:11:45', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:11:47', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:11:55', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:17:01', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:18:18', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:19:11', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:20:09', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:21:06', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:21:40', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:21:44', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:21:46', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:28:26', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:38:26', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:43:23', 'dd-mm-yyyy hh24:mi:ss'), 931);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:53:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:54:32', 'dd-mm-yyyy hh24:mi:ss'), 932);
commit;
prompt 600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 08:58:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 09:00:08', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 09:10:08', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 09:12:10', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 09:37:19', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:02:28', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:02:35', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:02:37', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:05:15', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:08:22', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:08:41', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:08:43', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:13:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:13:38', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:23:38', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:25:39', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:35:55', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:36:03', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:36:05', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:43:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 10:50:50', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:00:50', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:02:52', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:04:39', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:04:49', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:04:51', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:13:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:16:37', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:18:25', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:18:32', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:18:34', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:28:23', 'dd-mm-yyyy hh24:mi:ss'), 932);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:38:23', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:43:23', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:45:38', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:51:37', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:59:04', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:59:33', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 11:59:35', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:09:35', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:13:23', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:23:23', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:27:00', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:37:00', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 12:39:02', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 13:04:11', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 13:34:12', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:04:12', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:21:31', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:21:39', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:21:41', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:28:23', 'dd-mm-yyyy hh24:mi:ss'), 933);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:32:44', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:42:44', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 14:44:46', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:07:41', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:07:48', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:07:50', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:13:23', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:18:22', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:26:05', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:36:05', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 15:38:08', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 16:03:17', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 16:33:17', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 17:03:18', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 17:33:18', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 18:03:19', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 18:33:19', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 19:03:20', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 19:33:20', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 20:03:21', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 20:33:21', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 21:03:21', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 21:33:22', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 22:03:22', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 22:33:23', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 23:03:23', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (29, to_date('13-09-2021 23:33:24', 'dd-mm-yyyy hh24:mi:ss'), 934);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 00:23:54', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 00:53:54', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 01:23:55', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 01:53:55', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 02:23:56', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 02:53:56', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 03:23:57', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 03:53:57', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 04:23:58', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 04:53:58', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 05:23:59', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 05:53:59', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 06:23:59', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 06:54:00', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:24:00', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:35:27', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:36:25', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:36:55', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:36:59', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:37:01', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:40:24', 'dd-mm-yyyy hh24:mi:ss'), 2030);
commit;
prompt 700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:41:16', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:41:39', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:41:41', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:42:05', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:42:06', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:42:14', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:42:16', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:43:40', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:43:44', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:43:46', 'dd-mm-yyyy hh24:mi:ss'), 2030);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:44:23', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:45:49', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:45:56', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:45:58', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:48:36', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:57:55', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:58:02', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 07:58:04', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:02:03', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:12:03', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:14:05', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:39:14', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:39:54', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:40:00', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:40:02', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:50:04', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 08:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:00:10', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:11:13', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:13:42', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:13:48', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:13:50', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:22:49', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:32:49', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 09:34:51', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 10:00:00', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 10:30:01', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 11:00:01', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 11:30:02', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 12:00:02', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 12:30:03', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:00:03', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:30:04', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:52:19', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:52:35', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:52:37', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 13:59:41', 'dd-mm-yyyy hh24:mi:ss'), 2031);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:05:47', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:11:04', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:11:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:11:12', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:20:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:30:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:33:04', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:45:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:47:50', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:57:50', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:58:09', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:58:16', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 14:58:18', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:02:23', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:03:54', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:04:00', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:04:02', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:05:10', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:05:53', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:13:30', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:13:36', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:13:38', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:18:42', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:22:51', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:22:58', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:23:00', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:24:58', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:27:24', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:30:16', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:30:26', 'dd-mm-yyyy hh24:mi:ss'), 2032);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:35:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:45:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:50:10', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 15:50:44', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:00:44', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:02:46', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:12:56', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:13:03', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:13:05', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:18:03', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:28:03', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:30:05', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 16:55:15', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 17:25:15', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 17:55:16', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 18:25:16', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 18:55:17', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 19:25:17', 'dd-mm-yyyy hh24:mi:ss'), 2033);
commit;
prompt 800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 19:55:18', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 20:25:18', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 20:55:19', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 21:25:19', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 21:55:20', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 22:25:20', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 22:55:21', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 23:25:21', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (30, to_date('13-09-2021 23:55:21', 'dd-mm-yyyy hh24:mi:ss'), 2033);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 00:03:38', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 00:33:39', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 01:03:39', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 01:33:39', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 02:03:40', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 02:33:40', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 03:03:41', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 03:33:41', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 04:03:42', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 04:33:42', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 05:03:43', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 05:33:43', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 06:03:43', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 06:33:44', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 07:03:44', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 07:33:45', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:03:45', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:08:50', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:09:43', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:10:27', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:10:31', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:10:33', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:22:03', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:28:07', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:33:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:43:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:43:21', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 08:52:59', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 09:02:59', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 09:05:01', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 09:30:10', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 10:00:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 10:30:11', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 11:00:12', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 11:30:12', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 12:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 12:30:13', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 13:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 13:30:14', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 14:00:14', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 15:00:16', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 15:30:16', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 16:00:16', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 16:30:17', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:00:17', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:08:29', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:09:05', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:09:20', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:09:24', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:09:26', 'dd-mm-yyyy hh24:mi:ss'), 1422);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:15:19', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:20:54', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:30:54', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:32:56', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 17:58:05', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:24:33', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:24:51', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:24:53', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:27:34', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:27:36', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:27:46', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:27:48', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:33:11', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:37:33', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:43:40', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:50:20', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 18:57:50', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:02:04', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:12:04', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:14:05', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:15:16', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:15:24', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:15:26', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:18:11', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:20:31', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:30:31', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:32:33', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 19:57:43', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 20:27:43', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 20:57:44', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 21:27:44', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 21:57:45', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 22:27:45', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 22:57:46', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:27:46', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:34:21', 'dd-mm-yyyy hh24:mi:ss'), 1423);
commit;
prompt 900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:34:30', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:34:32', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:38:27', 'dd-mm-yyyy hh24:mi:ss'), 1423);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:46:36', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:48:11', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (32, to_date('13-09-2021 23:53:29', 'dd-mm-yyyy hh24:mi:ss'), 1424);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 00:03:26', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 00:33:27', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 01:03:27', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 01:33:28', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 02:03:28', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 02:33:28', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 03:03:29', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 03:33:29', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 04:03:30', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 04:33:30', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 05:03:31', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 05:33:31', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 06:03:32', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 06:33:32', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:03:32', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:25:01', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:25:25', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:31:24', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:32:34', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:32:47', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:32:51', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:32:53', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:35:44', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:37:17', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:37:41', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:37:43', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:38:23', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:38:25', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:39:46', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:39:50', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:39:52', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:40:54', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:46:47', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:47:01', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:47:03', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:57:03', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 07:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:01:53', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:11:53', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:13:56', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:23:27', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:23:44', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:23:46', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:27:06', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:37:06', 'dd-mm-yyyy hh24:mi:ss'), 4846);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:42:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:52:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:53:43', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 08:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:01:04', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:03:09', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:12:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:22:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:27:06', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:34:14', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:34:20', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:36:42', 'dd-mm-yyyy hh24:mi:ss'), 4847);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:42:06', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:46:30', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:51:23', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:55:20', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 09:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:01:24', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:04:00', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:10:36', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:20:36', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:22:38', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:28:01', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:28:09', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:28:11', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:29:35', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:39:06', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:42:06', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:47:26', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:50:15', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:50:24', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:50:26', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:57:06', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 10:57:23', 'dd-mm-yyyy hh24:mi:ss'), 4848);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:07:23', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:12:06', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:22:06', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:22:30', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:24:31', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:33:43', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:33:49', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:36:13', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:46:13', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:48:12', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:54:12', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:54:23', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:54:25', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 11:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4849);
commit;
prompt 1000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:03:12', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:11:14', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:11:15', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:11:26', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:12:05', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:16:55', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:28:57', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 12:54:07', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:24:07', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:24:59', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:25:09', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:25:11', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4849);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:36:44', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:52:05', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:53:18', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 13:57:11', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:07:11', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:12:05', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:19:13', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4850);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:36:10', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:42:26', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:43:01', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:50:32', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 14:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:00:34', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:06:54', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:10:07', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:10:10', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:17:31', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:17:45', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:17:47', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:18:29', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:21:00', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:21:09', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:21:11', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:26:13', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:29:11', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:32:05', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:33:18', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:33:27', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:33:29', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:35:11', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4851);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:52:05', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:53:33', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 15:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:00:11', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:06:32', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:06:41', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:06:43', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:06:54', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:08:46', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:18:46', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:20:48', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:45:58', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:46:21', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:47:58', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:48:17', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:48:21', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:48:23', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:49:24', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 16:56:26', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:02:59', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:25', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:27', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:38', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:39', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:47', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:03:49', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:05:06', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:05:10', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:05:12', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:05:28', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:14:33', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:14:48', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:14:50', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:27:05', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:37:05', 'dd-mm-yyyy hh24:mi:ss'), 4852);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:52:05', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:57:05', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:57:16', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 17:58:57', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:08:57', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:09:33', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:12:05', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:13:11', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:23:11', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:37:04', 'dd-mm-yyyy hh24:mi:ss'), 4853);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:42:05', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:43:02', 'dd-mm-yyyy hh24:mi:ss'), 4854);
commit;
prompt 1100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:51:36', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:53:45', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 18:57:57', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:07:57', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:10:17', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:13:05', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:21:12', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:24:25', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:26:38', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:32:11', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:33:32', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:35:28', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:35:33', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:37:10', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:41:17', 'dd-mm-yyyy hh24:mi:ss'), 4854);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:42:35', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:45:50', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:47:46', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 19:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:07:04', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:11:27', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:13:48', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:14:48', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:21:23', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:21:50', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:24:33', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:24:35', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:26:55', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:35:50', 'dd-mm-yyyy hh24:mi:ss'), 4855);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:52:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:55:24', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 20:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:06:34', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:10:34', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:10:41', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:10:43', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:11:42', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:20:07', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:20:38', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:22:49', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:23:26', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:24:18', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:26:12', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:33:13', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:38:19', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:40:19', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:45:47', 'dd-mm-yyyy hh24:mi:ss'), 4856);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:48:38', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:51:03', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:52:41', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 21:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:00:31', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:09:33', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:12:13', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:13:58', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:17:09', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:22:13', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:24:33', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:36:36', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:44:13', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:45:10', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:45:39', 'dd-mm-yyyy hh24:mi:ss'), 4857);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:49:56', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:50:49', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:51:43', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:52:43', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:53:53', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:54:48', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 22:57:04', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:04:47', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:12:04', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:22:04', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:27:04', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:34:08', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:39:02', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:42:04', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:45:40', 'dd-mm-yyyy hh24:mi:ss'), 4858);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (33, to_date('13-09-2021 23:52:02', 'dd-mm-yyyy hh24:mi:ss'), 4859);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 00:17:29', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 00:47:29', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 01:17:29', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 01:47:30', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 02:17:30', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 02:47:31', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 03:17:31', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 03:47:32', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 04:17:32', 'dd-mm-yyyy hh24:mi:ss'), 2069);
commit;
prompt 1200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 04:47:33', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 05:17:33', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 05:47:33', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 06:17:34', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 06:47:34', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 06:58:57', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 06:59:08', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:09:06', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:11:08', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:24:58', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:25:32', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:25:44', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:25:49', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:25:51', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:26:46', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:33:36', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:34:21', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:34:22', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:34:30', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:34:32', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:35:26', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:36:04', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:36:08', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:36:10', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:36:35', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:37:12', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:37:23', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:37:25', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:40:42', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:42:45', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:42:53', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:42:55', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2069);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:57:52', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:59:11', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:59:20', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 07:59:22', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:02:23', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:12:23', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:14:25', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:38:41', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:38:48', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:38:50', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:43:40', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:46:34', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:46:55', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:46:57', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:49:42', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 08:59:42', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:01:44', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:26:53', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:42:56', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:43:06', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:43:08', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 09:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:10:29', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:14:41', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:14:49', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:14:51', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:26:51', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:30:40', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:30:47', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:30:49', 'dd-mm-yyyy hh24:mi:ss'), 2070);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 10:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:02:11', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:03:22', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:03:29', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:03:31', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:26:18', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:31:51', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:31:59', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:32:01', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:33:49', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:43:49', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:45:51', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:54:09', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:54:18', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 11:54:20', 'dd-mm-yyyy hh24:mi:ss'), 2071);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:04:20', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:05:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:15:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:20:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:30:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:36:00', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:46:00', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 12:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2072);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:05:12', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:11:01', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:11:09', 'dd-mm-yyyy hh24:mi:ss'), 2073);
commit;
prompt 1300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:11:11', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:13:41', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:18:46', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:22:02', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:23:00', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:23:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:23:28', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:23:30', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:33:30', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 13:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:03:21', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:13:21', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:15:23', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:33:16', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:33:57', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:34:26', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:34:31', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:34:33', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2073);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:45:24', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 14:50:24', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:00:24', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:04:39', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:14:39', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:16:42', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:29:01', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:29:09', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:29:11', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:35:24', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:36:44', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:46:44', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:48:46', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:51:14', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:51:21', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:51:23', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 15:52:21', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:02:21', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:04:23', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:29:32', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:40:48', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:40:59', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 16:50:59', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 17:16:08', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 17:46:08', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 18:16:09', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 18:46:09', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 19:16:10', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 19:46:10', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 20:16:11', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 20:46:11', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 21:16:11', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 21:46:12', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 22:16:12', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 22:46:13', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 23:16:13', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (34, to_date('13-09-2021 23:46:14', 'dd-mm-yyyy hh24:mi:ss'), 2074);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 00:08:15', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 00:38:16', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 01:08:16', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 01:38:16', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 02:08:17', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 02:38:17', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 03:08:18', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 03:38:18', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 04:08:19', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 04:38:19', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 05:08:19', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 05:38:20', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 06:08:20', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 06:38:21', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:08:21', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:18:53', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:20:19', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:20:41', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:20:46', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:20:48', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:22:03', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3804);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:40:13', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:50:13', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:50:17', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:50:29', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:50:31', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 07:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:21:18', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3805);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 08:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:08:33', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:17:41', 'dd-mm-yyyy hh24:mi:ss'), 3806);
commit;
prompt 1400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:24:36', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:24:47', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:24:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3806);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 09:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:34:42', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:39:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:40:06', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:40:08', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:44:44', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:54:44', 'dd-mm-yyyy hh24:mi:ss'), 3807);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 10:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3808);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 11:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:34:07', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:44:28', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:54:28', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 12:56:30', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 13:21:40', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 13:51:40', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:02:24', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:05:27', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:05:29', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:05:36', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3809);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 14:57:06', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:07:06', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3810);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:51:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 16:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 16:10:37', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 16:20:37', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 16:22:38', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 16:47:47', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:01:30', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:02:09', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:02:48', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:02:52', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:02:54', 'dd-mm-yyyy hh24:mi:ss'), 3811);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:05:36', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:09:25', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:09:32', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:09:34', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:11:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:21:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:37:37', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:47:37', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:47:42', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:47:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:47:51', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:47:58', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:49:48', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:49:56', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:49:58', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 17:54:43', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:04:43', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:06:42', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:15:01', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:16:10', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:17:15', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:17:51', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:17:55', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:17:57', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3812);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:41:49', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:49:13', 'dd-mm-yyyy hh24:mi:ss'), 3813);
commit;
prompt 1500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 18:59:13', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 19:01:16', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 19:26:26', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 19:56:26', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 20:26:27', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 20:57:39', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 21:27:40', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 21:57:40', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 22:27:41', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 22:57:41', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 23:27:42', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (35, to_date('13-09-2021 23:57:42', 'dd-mm-yyyy hh24:mi:ss'), 3813);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:15:18', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:15:25', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:15:29', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:16:21', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:16:26', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:17:05', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:17:19', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:18:04', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:18:25', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:18:30', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:18:32', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:20:17', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:30:17', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:35:17', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:45:17', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:00:16', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:03:42', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:03:50', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:05:08', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:14:55', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:15:01', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:15:03', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:18:55', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:19:15', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:20:17', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:22:14', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:24:54', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:25:20', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:30:06', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:35:17', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:37:24', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:37:56', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:38:57', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:48:57', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:52:19', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:54:00', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:54:21', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:54:37', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:56:40', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:57:47', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:58:15', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 19:58:38', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:01:08', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:01:14', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:05:17', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:05:25', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:07:22', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:10:16', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:10:42', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:11:07', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:11:34', 'dd-mm-yyyy hh24:mi:ss'), 2957);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:15:34', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:17:23', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:18:29', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:19:49', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:25:03', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:27:03', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:40:53', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:48:01', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 20:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:00:16', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:00:35', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:02:43', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:04:23', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:14:23', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:16:24', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:17:48', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:18:01', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:18:03', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:18:39', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:20:17', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:20:43', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:24:55', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:25:19', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:27:10', 'dd-mm-yyyy hh24:mi:ss'), 2958);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:27:41', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:28:11', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:31:21', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:32:13', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:33:01', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:38:04', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:38:45', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:40:25', 'dd-mm-yyyy hh24:mi:ss'), 2959);
commit;
prompt 1600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:40:41', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:41:17', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:41:49', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:42:32', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:42:49', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:43:39', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:49:37', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:50:34', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 21:50:49', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:00:49', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:01:14', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:06:23', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:10:06', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:10:25', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:11:30', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:18:39', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:18:49', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2959);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:30:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:45:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 22:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:00:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:05:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:15:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:20:16', 'dd-mm-yyyy hh24:mi:ss'), 2960);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:30:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:35:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:45:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:50:16', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:50:43', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:52:36', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:52:59', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 23:53:01', 'dd-mm-yyyy hh24:mi:ss'), 2961);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 00:23:53', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 00:53:53', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 01:23:54', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 01:53:54', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 02:23:55', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 02:53:55', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 03:23:55', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 03:53:56', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 04:23:56', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 04:53:57', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 05:23:57', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 05:53:58', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 06:23:58', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 06:53:58', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:23:59', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:43:19', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:43:46', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:43:48', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:44:14', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:54:14', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 07:56:16', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 08:21:25', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 08:51:26', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 09:21:26', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 09:51:27', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 10:21:27', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 10:51:28', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 11:21:28', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 11:51:28', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 12:21:29', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 12:51:29', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 13:21:30', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 13:51:30', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 14:21:31', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 14:51:31', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 15:21:31', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 15:51:32', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 16:21:32', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 16:51:33', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:21:33', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:38:30', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:41:02', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:51:02', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:55:27', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:57:31', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:59:12', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 17:59:36', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:09:36', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (37, to_date('13-09-2021 18:11:38', 'dd-mm-yyyy hh24:mi:ss'), 2956);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 00:17:43', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 00:47:44', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 01:17:44', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 01:47:45', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 02:17:45', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 02:47:45', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 03:17:46', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 03:47:46', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 04:17:47', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 04:47:47', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 05:17:48', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 05:47:48', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 06:17:49', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 06:47:49', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:17:06', 'dd-mm-yyyy hh24:mi:ss'), 4015);
commit;
prompt 1700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:18:04', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:18:24', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:18:28', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:18:30', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:20:02', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:24:09', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:29:52', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:17', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:19', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:43', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:45', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:53', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:30:56', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:32:36', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:32:40', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:32:42', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:33:10', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:36:24', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:36:25', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:36:33', 'dd-mm-yyyy hh24:mi:ss'), 4015);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:45:40', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 07:53:03', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:03:03', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:05:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:15:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:20:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:30:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:35:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:42:18', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:49:10', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:49:22', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:49:24', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 08:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4016);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:05:04', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:15:04', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:18:46', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:28:46', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:30:49', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:40:46', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:40:58', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:41:00', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 09:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:00:04', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:02:38', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:04:42', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:04:53', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:04:55', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4017);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:20:04', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:30:04', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:35:04', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:35:14', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:40:14', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:40:21', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:40:23', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 10:50:04', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:00:04', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4018);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:30:03', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:35:04', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:43:11', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:53:11', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 11:55:13', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 12:20:22', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 12:50:23', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 12:50:50', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 12:56:04', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 12:56:06', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:08:12', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:17:35', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:17:44', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:17:46', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:29:12', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:33:10', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:35:04', 'dd-mm-yyyy hh24:mi:ss'), 4019);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:45:04', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 13:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:09:30', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:19:30', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4020);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:45:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 14:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:00:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:15:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:27:44', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4021);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:36:10', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:44:56', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:45:05', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:45:07', 'dd-mm-yyyy hh24:mi:ss'), 4022);
commit;
prompt 1800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 15:55:59', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:07:11', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:17:11', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:19:12', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:44:22', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:46:15', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:46:56', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:47:20', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:47:25', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:47:27', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:49:55', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 16:59:55', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:01:54', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:02:27', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:02:41', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:02:46', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:02:48', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:11:59', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), 4022);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:35:23', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:45:23', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:47:37', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 17:50:03', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:00:03', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:00:20', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:05:03', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:12:14', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:20:03', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:26:14', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:34:00', 'dd-mm-yyyy hh24:mi:ss'), 4023);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:35:03', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:42:34', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:52:34', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 18:54:37', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 19:19:47', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 19:49:47', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 20:19:47', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 20:49:48', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 21:19:48', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 21:49:49', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 22:19:49', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 22:49:50', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 23:19:50', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (36, to_date('13-09-2021 23:49:51', 'dd-mm-yyyy hh24:mi:ss'), 4024);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 00:14:27', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 00:44:27', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 01:14:27', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 01:44:28', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 02:14:28', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 02:44:29', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 03:14:29', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 03:44:30', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 04:14:30', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 04:44:30', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 05:14:31', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 05:44:31', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 06:14:32', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 06:44:32', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:07:51', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:08:58', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:09:34', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:09:36', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:09:51', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:17:26', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:18:38', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:20:14', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:21:20', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:22:22', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:23:02', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:23:09', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:23:55', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:24:20', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:24:51', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:26:08', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:29:05', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:29:53', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:39:51', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:40:51', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:44:44', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:45:26', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:46:25', 'dd-mm-yyyy hh24:mi:ss'), 5085);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:53:22', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:54:26', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:54:51', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:54:57', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:57:06', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 07:57:27', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:03:40', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:05:25', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:09:51', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:18:15', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:19:15', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:20:23', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:21:31', 'dd-mm-yyyy hh24:mi:ss'), 5086);
commit;
prompt 1900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:24:03', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:24:51', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:26:40', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:27:10', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:28:01', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:28:52', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:31:20', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:32:44', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:33:41', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:34:09', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:39:51', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:40:11', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:40:40', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:42:44', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:45:18', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:45:35', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:48:04', 'dd-mm-yyyy hh24:mi:ss'), 5086);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:48:37', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:51:26', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:52:48', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:54:08', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:54:51', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:59:09', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:59:18', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 08:59:38', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:00:25', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:05:49', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:06:40', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:07:13', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:09:18', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:09:51', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:10:31', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:11:59', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:12:12', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:13:24', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:13:59', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:21:11', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:21:18', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:21:20', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:24:51', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:24:53', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:25:22', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:25:50', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:30:08', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:39:51', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:42:43', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:43:30', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:43:35', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:44:43', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:46:02', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:49:46', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:54:51', 'dd-mm-yyyy hh24:mi:ss'), 5087);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 09:58:08', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:02:32', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:05:35', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:05:41', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:05:43', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:06:36', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:06:48', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:08:13', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:08:50', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:09:01', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:19:19', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:19:31', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:19:33', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:19:50', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:23:25', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:24:51', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:26:01', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:29:11', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:33:21', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:38:17', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:38:46', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:39:11', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:39:51', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:41:45', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:43:59', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:49:03', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:56:51', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:57:25', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 10:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:03:20', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:07:06', 'dd-mm-yyyy hh24:mi:ss'), 5088);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:10:17', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:13:01', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:13:04', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:15:33', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:17:42', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:18:03', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:23:37', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:24:09', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:25:52', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:27:36', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:28:16', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:28:29', 'dd-mm-yyyy hh24:mi:ss'), 5089);
commit;
prompt 2000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:29:05', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:39:05', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:40:23', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:42:29', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:48:18', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:49:35', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:50:17', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:50:27', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:50:36', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:51:27', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:53:02', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:54:39', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:55:43', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:56:00', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:56:38', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:57:17', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:58:15', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:58:31', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:58:51', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 11:59:11', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:00:10', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:00:43', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:00:52', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:05:27', 'dd-mm-yyyy hh24:mi:ss'), 5089);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:12:27', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:13:37', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:13:47', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:14:28', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:17:20', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:17:38', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:17:49', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:18:22', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:20:03', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:20:46', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:21:23', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:22:59', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:27:03', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:31:16', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:31:37', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:37:46', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:37:54', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:37:56', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:37:58', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:38:35', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:38:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:40:34', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:41:58', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:42:05', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:42:07', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:43:38', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:44:29', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:54:29', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 12:56:31', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 13:21:41', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 13:51:41', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:02:21', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:02:35', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:02:37', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:05:13', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:05:39', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:06:23', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:07:31', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:08:14', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:12:45', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:14:13', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:14:34', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:19:49', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:19:53', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:24:53', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:26:04', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:26:31', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:26:58', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:27:40', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:28:03', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:30:12', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:30:15', 'dd-mm-yyyy hh24:mi:ss'), 5090);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:35:23', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:35:34', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:37:28', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:38:35', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:39:57', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:40:01', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:41:26', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:47:32', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:53:48', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:54:01', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:56:08', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:57:21', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 14:59:13', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:00:39', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:02:42', 'dd-mm-yyyy hh24:mi:ss'), 5091);
commit;
prompt 2100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:05:58', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:10:41', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:12:34', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:12:45', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:16:59', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:23:28', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:23:57', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:30:51', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:31:21', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:31:23', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:32:27', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:35:54', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:38:03', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:39:42', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5091);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:41:40', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:41:59', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:42:08', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:42:15', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:43:17', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:43:33', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:43:36', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:47:05', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:49:22', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:55:08', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:55:15', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:55:17', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:55:19', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:59:27', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 15:59:41', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:01:07', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:06:20', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:08:45', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:10:37', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:15:05', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:17:12', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:18:23', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:20:29', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:21:07', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:31:07', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:33:09', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:45:24', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:45:51', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:46:05', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:46:10', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:46:12', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:46:39', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:46:46', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:48:07', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:48:28', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:49:30', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:49:58', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:50:54', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:51:00', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:57:55', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:58:02', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:58:04', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 16:58:50', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:01:16', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:01:30', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:01:32', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:03:05', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:03:10', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:03:12', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:08:53', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:09:17', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:09:19', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:09:56', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:10:01', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:11:31', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:11:35', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:11:37', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:12:08', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:17:17', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:17:25', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:17:27', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:17:45', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:19:43', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:26:26', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:26:31', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:26:57', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:28:03', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:28:10', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:28:23', 'dd-mm-yyyy hh24:mi:ss'), 5092);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:31:44', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:33:04', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:34:51', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:36:41', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:37:54', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:39:59', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:40:28', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:40:58', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:41:09', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:41:48', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:43:22', 'dd-mm-yyyy hh24:mi:ss'), 5093);
commit;
prompt 2200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:44:23', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:49:06', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:49:29', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:50:38', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:51:32', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:51:37', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:52:16', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:52:38', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:52:49', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:53:28', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:53:34', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:53:55', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:54:01', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:55:01', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:55:53', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:56:14', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:58:25', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:59:11', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:59:16', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 17:59:47', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:00:27', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:01:42', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:01:48', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:02:43', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:11:02', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:12:34', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:14:19', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:14:34', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:23:23', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:26:11', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:26:19', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:26:42', 'dd-mm-yyyy hh24:mi:ss'), 5093);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:30:05', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:30:15', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:33:54', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:38:22', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:43:27', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:51:42', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:52:14', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:55:42', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 18:56:40', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:04:14', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:07:19', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:08:53', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:17:36', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:18:27', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5094);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:34:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:35:41', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:40:07', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:41:21', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:42:38', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:46:04', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:46:33', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:46:46', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:47:00', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:47:37', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:48:22', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:49:57', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:50:24', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:53:31', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 19:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:04:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:06:52', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:19:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:21:01', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:21:24', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:22:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:23:04', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:23:17', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:23:26', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:24:50', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:24:53', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:26:43', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:26:47', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:28:12', 'dd-mm-yyyy hh24:mi:ss'), 5095);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:31:27', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:31:40', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:32:53', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:33:46', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:34:41', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:35:18', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:37:09', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:38:55', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:39:48', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:45:40', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:49:12', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5096);
commit;
prompt 2300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 20:59:58', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:00:17', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:02:06', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:06:37', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:16:08', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:17:40', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:27:40', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:29:42', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:34:25', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:34:32', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:34:34', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:35:59', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:36:44', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:39:04', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:40:26', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:40:58', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:43:18', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:43:36', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:44:14', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:44:47', 'dd-mm-yyyy hh24:mi:ss'), 5096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:45:42', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:47:54', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:48:12', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:48:16', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:49:03', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:49:45', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:49:47', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 21:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:05:24', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:06:44', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:08:32', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:09:27', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:09:50', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:10:48', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:12:41', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:22:41', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:24:42', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 22:49:51', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:19:52', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:32:53', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:33:01', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:33:03', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:34:21', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:39:17', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:39:50', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:41:50', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:42:51', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:43:03', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:44:13', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:44:24', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:45:07', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:45:20', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:46:20', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:46:36', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:47:43', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:47:56', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:48:10', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:48:18', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:48:49', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:49:05', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:49:48', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:50:04', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:50:28', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:50:31', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:50:40', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:11', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:15', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:22', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:26', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:52', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:51:58', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:52:16', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:52:58', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:54:31', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:54:50', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:55:40', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:57:23', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:58:19', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:58:36', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:58:57', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (38, to_date('13-09-2021 23:59:05', 'dd-mm-yyyy hh24:mi:ss'), 5097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 00:03:27', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 00:33:27', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 01:03:28', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 01:33:28', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 02:03:29', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 02:33:29', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 03:03:29', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 03:33:30', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 04:03:30', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 04:33:31', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 05:03:31', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 05:33:32', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 06:03:32', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 06:33:33', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:03:33', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:11:17', 'dd-mm-yyyy hh24:mi:ss'), 5910);
commit;
prompt 2400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:11:52', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:12:08', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:12:12', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:12:14', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:22:14', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:22:31', 'dd-mm-yyyy hh24:mi:ss'), 5910);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:29:07', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:37:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:47:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 07:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:07:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:17:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:22:31', 'dd-mm-yyyy hh24:mi:ss'), 5911);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:32:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:37:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:47:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 08:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:07:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:17:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:22:31', 'dd-mm-yyyy hh24:mi:ss'), 5912);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:32:31', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:37:31', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:47:31', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 09:52:31', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:02:31', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:07:01', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:10:39', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:10:45', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:10:47', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:20:47', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5913);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 10:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:00:22', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:08:03', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:18:03', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5914);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:51:49', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 11:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:00:08', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5915);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 12:53:59', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 13:03:59', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 13:06:01', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 13:31:10', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:01:11', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:01:14', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:01:25', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:01:27', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:27:05', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:37:05', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5916);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:39:33', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:49:33', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 14:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5917);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 15:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:08:25', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:10:38', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:20:38', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:25:37', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:35:37', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:37:39', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:53:46', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:54:27', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:54:45', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:54:49', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:54:51', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 16:59:43', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:05:46', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:06:10', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:06:12', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:06:34', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:06:36', 'dd-mm-yyyy hh24:mi:ss'), 5918);
commit;
prompt 2500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:07:31', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:08:03', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:08:07', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:08:09', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:08:28', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:14:31', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:14:49', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:14:51', 'dd-mm-yyyy hh24:mi:ss'), 5918);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:45:16', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 17:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5919);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:34:51', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:45:58', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 18:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:12:01', 'dd-mm-yyyy hh24:mi:ss'), 5920);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:22:01', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:33:22', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:43:22', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:43:39', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:43:46', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:43:48', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 19:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5921);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 20:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:02:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:17:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5922);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:47:04', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:57:04', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 21:59:06', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 22:24:15', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 22:54:16', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:01:27', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:02:00', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:02:02', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:07:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:08:22', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:18:22', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:22:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:32:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:37:30', 'dd-mm-yyyy hh24:mi:ss'), 5923);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:47:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (39, to_date('13-09-2021 23:52:30', 'dd-mm-yyyy hh24:mi:ss'), 5924);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:56:09', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:57:05', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:57:09', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:59:26', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:00:37', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:01:10', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:02:08', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:02:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:03:07', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:03:36', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:07:26', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:07:44', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:08:00', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:09:35', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:10:49', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:11:22', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:11:41', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:12:08', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:12:18', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:13:08', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:13:40', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:14:50', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:17:26', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:18:12', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:19:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:22:09', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:22:58', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:23:06', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:23:33', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:24:11', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:24:28', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:24:52', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:25:15', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:25:45', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:26:14', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:26:25', 'dd-mm-yyyy hh24:mi:ss'), 3107);
commit;
prompt 2600 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:26:40', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:26:50', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:27:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:27:10', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:28:36', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:28:47', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:29:19', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:30:03', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:30:51', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:31:19', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:32:07', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:32:37', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:33:10', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:33:19', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:34:09', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:37:29', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:38:23', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:39:14', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:40:51', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:41:23', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:42:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:42:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:45:26', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:55:26', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 18:57:27', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:22:36', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:24:06', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:25:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:25:46', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:25:50', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:25:52', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:27:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:28:06', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:28:45', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:29:59', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:30:50', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:31:43', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:32:45', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:34:07', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:35:09', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:35:55', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:36:39', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:37:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:38:14', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:38:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:38:49', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:39:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:42:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:42:44', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:43:30', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:43:49', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:44:32', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:44:45', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:44:57', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:47:18', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:48:57', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:51:08', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 19:56:04', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 20:06:04', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 20:08:06', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 20:33:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 21:03:16', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 21:33:17', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:03:17', 'dd-mm-yyyy hh24:mi:ss'), 3107);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:29:08', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:29:32', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:29:34', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:30:42', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:40:42', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 22:42:43', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 23:07:53', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 23:37:53', 'dd-mm-yyyy hh24:mi:ss'), 3108);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 00:23:24', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 00:53:25', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 01:23:25', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 01:53:26', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 02:23:26', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 02:53:27', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 03:23:27', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 03:53:28', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 04:23:28', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 04:53:28', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 05:23:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 05:53:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 06:23:30', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 06:53:30', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 07:23:31', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 07:53:31', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 08:23:32', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 08:53:32', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 09:23:33', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 09:53:33', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 10:23:34', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 10:53:34', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 11:23:35', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 11:53:35', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 12:23:35', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 12:53:36', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 13:23:36', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 13:53:37', 'dd-mm-yyyy hh24:mi:ss'), 1786);
commit;
prompt 2700 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 14:11:29', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 14:11:33', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 14:21:26', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 14:46:35', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 15:16:36', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 15:46:36', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 16:16:37', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 16:46:37', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 17:16:38', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 17:46:38', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 18:16:39', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 18:46:39', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 19:16:40', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 19:46:40', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 20:16:40', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 20:46:41', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 21:16:41', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 21:46:42', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 22:16:42', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 22:46:43', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 23:16:43', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (47, to_date('13-09-2021 23:46:43', 'dd-mm-yyyy hh24:mi:ss'), 1786);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 00:00:59', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 00:31:00', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 01:01:00', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 01:31:01', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 02:01:01', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 02:31:01', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 03:01:02', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 03:31:02', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 04:01:03', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 04:31:03', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 05:01:04', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 05:31:04', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 06:01:05', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 06:31:05', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:01:05', 'dd-mm-yyyy hh24:mi:ss'), 452);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:11:48', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:12:46', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:12:47', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:13:42', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:14:04', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:14:08', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:14:10', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:15:49', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:15:51', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:25:51', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:27:55', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:44:57', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:22', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:24', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:38', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:39', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:47', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:45:49', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:47:41', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:47:45', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:47:47', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:47:58', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:48:16', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 07:58:16', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:00:19', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:03:53', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:04:00', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:04:02', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:05:11', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:10:05', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:20:05', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:20:10', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:27:26', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:34:12', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:35:11', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:45:11', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:50:10', 'dd-mm-yyyy hh24:mi:ss'), 453);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 08:56:07', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:05:10', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:16:43', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:18:03', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:20:10', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:30:10', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:35:10', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:41:29', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:43:14', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:46:14', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:46:21', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:46:23', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:50:11', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 09:55:04', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:00:22', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:00:29', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:00:31', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:00:44', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:01:23', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:07:41', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:07:47', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:07:49', 'dd-mm-yyyy hh24:mi:ss'), 454);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:09:20', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:09:31', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:19:05', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:19:13', 'dd-mm-yyyy hh24:mi:ss'), 455);
commit;
prompt 2800 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:19:15', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:20:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:30:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:35:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:37:41', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:47:41', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 10:49:44', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:14:53', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:43:40', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:43:47', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:43:49', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:50:11', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 11:50:55', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:00:55', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:05:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:15:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:15:19', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:20:10', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:21:45', 'dd-mm-yyyy hh24:mi:ss'), 455);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:31:45', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:35:11', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:41:42', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:45:36', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:49:49', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:50:11', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 12:53:12', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 13:03:12', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 13:05:15', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 13:30:24', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:00:25', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:05:25', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:05:31', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:05:33', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:05:35', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:15:37', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:20:11', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:21:54', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:31:54', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:35:11', 'dd-mm-yyyy hh24:mi:ss'), 456);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:37:34', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:38:35', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:39:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:49:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 14:50:11', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:00:11', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:04:08', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:05:10', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:05:27', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:10:42', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:14:02', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:24:02', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:26:06', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 15:51:16', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:15:26', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:15:58', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:16:12', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:16:16', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:16:18', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:20:11', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:20:36', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:26:46', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:36:46', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 16:38:49', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 17:03:58', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 17:33:59', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 18:03:59', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 18:34:00', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 19:04:00', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 19:34:00', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 20:04:01', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 20:34:01', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 21:04:02', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 21:34:02', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 22:04:03', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 22:34:03', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 23:04:03', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (48, to_date('13-09-2021 23:34:04', 'dd-mm-yyyy hh24:mi:ss'), 457);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 00:08:59', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 00:39:00', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 01:09:00', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 01:39:01', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 02:09:01', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 02:39:02', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 03:09:02', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 03:39:02', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 04:09:03', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 04:39:03', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 05:09:04', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 05:39:04', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:09:05', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:36:27', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:36:38', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:36:40', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:37:31', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:37:51', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:37:56', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:37:58', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:39:44', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:49:44', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 06:51:46', 'dd-mm-yyyy hh24:mi:ss'), 3103);
commit;
prompt 2900 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:12:37', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:12:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:12:47', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:12:49', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:14:53', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:15:37', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:15:54', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:24:08', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:24:46', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:24:48', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:25:57', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:26:01', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:26:03', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:26:25', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:27:54', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:28:07', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:28:09', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:36:00', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:42:09', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:44:56', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:45:21', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:45:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:45:47', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:48:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 07:58:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 08:00:48', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 08:25:58', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 08:55:58', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:08:20', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:18:20', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:43:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:12', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:14', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:26', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:37', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:44', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:49', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:44:57', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 09:54:57', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:20:07', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:50:07', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:58:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:58:51', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:58:53', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:59:02', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:59:07', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:59:40', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 10:59:42', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:00:42', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:10:42', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:12:45', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:16:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:26:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:51:41', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 11:53:11', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:01:16', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:02:38', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:02:40', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:03:16', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:08:56', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:12:14', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:15:04', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:19:52', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:21:37', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:21:39', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:36:42', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:37:02', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:40:49', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:41:01', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:41:03', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:41:27', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:51:27', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 12:53:30', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:15:35', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:15:48', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:15:52', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:15:54', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:19:13', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:29:13', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:31:15', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 13:56:24', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:03:25', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:06:27', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:06:44', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:06:49', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:06:51', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:07:16', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:17:16', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:19:18', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:19:55', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:20:05', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:20:07', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:22:12', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:23:30', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:24:56', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:26:45', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3104);
commit;
prompt 3000 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:27:27', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:27:48', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:29:13', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:30:51', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:32:27', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:33:44', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:36:42', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:37:56', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:38:18', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:39:20', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:40:43', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:50:43', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 14:52:47', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:17:03', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:17:18', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:17:21', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:23:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:28:52', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:36:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:36:44', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:39:40', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:39:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:40:01', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:42:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:43:07', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:45:17', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:55:17', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:56:38', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:56:49', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:56:51', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:57:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:58:53', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 15:59:41', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:00:23', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:00:51', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:01:20', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:01:52', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:04:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:04:49', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:08:38', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:10:13', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:10:39', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:11:24', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:12:00', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:12:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:14:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:14:48', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:15:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:16:23', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:16:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:17:11', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:19:25', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:20:31', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:20:50', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:23:13', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:23:37', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:25:31', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:26:37', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:26:59', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:28:12', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:28:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:28:48', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:29:03', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:29:26', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:30:02', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:40:02', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 16:42:04', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:07:14', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:08:07', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:08:18', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:08:20', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:08:52', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:12:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:12:46', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:13:52', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:14:06', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:16:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:17:11', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:18:47', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:19:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:20:00', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:22:02', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:23:25', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:24:04', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:24:58', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:26:49', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:27:09', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:29:56', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:31:30', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:32:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:33:29', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:35:22', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:39:39', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:40:03', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:40:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:40:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:40:40', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:40:57', 'dd-mm-yyyy hh24:mi:ss'), 3106);
commit;
prompt 3100 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:41:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:42:09', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:42:26', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:47:58', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:48:07', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:48:16', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:48:27', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:49:48', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:51:08', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (49, to_date('13-09-2021 17:52:37', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 00:09:37', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 00:39:38', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 01:09:38', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 01:39:39', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 02:09:39', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 02:39:40', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 03:09:40', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 03:39:40', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 04:09:41', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 04:39:41', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 05:09:42', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 05:39:42', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 06:09:43', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 06:39:43', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:08:53', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:09:50', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:10:13', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:10:17', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:10:19', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:14:35', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:14:44', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:21:47', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:22:11', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:22:13', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:23:27', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:23:30', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:23:32', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:23:48', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:26:32', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:26:41', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:26:43', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:30:52', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:40:52', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:42:53', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:49:48', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:49:57', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:49:59', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:50:00', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:51:26', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:52:08', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:52:40', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 07:53:35', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:03:35', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:04:17', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:04:25', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:04:27', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:06:06', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:15:42', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:15:50', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:15:52', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3096);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:24:09', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:25:54', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:27:10', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:27:33', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:30:04', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:34:06', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:41:33', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:45:05', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:45:52', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:45:59', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:46:01', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:53:14', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:55:26', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:56:18', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 08:58:02', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:08:02', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:10:04', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:30:12', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:30:20', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:30:22', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:31:00', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:32:17', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:36:11', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:38:13', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:41:14', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:43:46', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:45:38', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:47:54', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3097);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:55:22', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:57:11', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:57:20', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 09:57:22', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:13:05', 'dd-mm-yyyy hh24:mi:ss'), 3098);
commit;
prompt 3200 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:25:07', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:31:15', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:31:26', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:31:28', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:32:24', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:33:11', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:34:04', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:36:49', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:42:22', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:42:58', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:45:44', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:49:33', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:50:28', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:50:42', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:51:25', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:52:23', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 10:59:46', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:08:46', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:10:40', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:11:09', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:12:39', 'dd-mm-yyyy hh24:mi:ss'), 3098);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:14:40', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:14:50', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:15:28', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:16:35', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:18:05', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:18:38', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:20:35', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:21:57', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:24:57', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:26:46', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:34:16', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:36:01', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:36:54', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:39:04', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:41:53', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:43:02', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:44:05', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:44:21', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:44:25', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:44:27', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:45:49', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:53:19', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 11:56:16', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:01:14', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:02:20', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:03:07', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:05:46', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:08:15', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:10:48', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:13:18', 'dd-mm-yyyy hh24:mi:ss'), 3099);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:23:40', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:24:36', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:25:23', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:26:15', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:27:15', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:28:13', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:29:26', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:30:09', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:30:43', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:32:24', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:33:54', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:34:45', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:35:30', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:35:53', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:39:06', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:40:31', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:41:43', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:44:04', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:45:18', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:55:18', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 12:57:19', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:22:29', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:30:15', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:31:04', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:31:23', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:31:27', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:31:29', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:33:13', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:38:14', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:41:43', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:43:21', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:45:12', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:45:33', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:46:06', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:47:57', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:48:18', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 13:51:54', 'dd-mm-yyyy hh24:mi:ss'), 3100);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:01:54', 'dd-mm-yyyy hh24:mi:ss'), 3101);
commit;
prompt 3300 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:07:17', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:11:32', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:16:19', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:19:53', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:24:46', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:26:17', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:31:45', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:31:51', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:31:53', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:37:37', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:47:37', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:49:40', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:51:33', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:55:27', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 14:55:55', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:00:34', 'dd-mm-yyyy hh24:mi:ss'), 3101);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:06:31', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:14:42', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:22:06', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:25:54', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:26:23', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:28:18', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:30:37', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:32:53', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:37:26', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:37:46', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:45:28', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:47:17', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:48:07', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:49:26', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:49:55', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:51:16', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:52:00', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:52:30', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:53:43', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:54:13', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:54:48', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:56:16', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 15:59:07', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:01:13', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:02:51', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:03:29', 'dd-mm-yyyy hh24:mi:ss'), 3102);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:04:12', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:05:25', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:06:05', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:06:42', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:09:39', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:10:37', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:11:04', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:11:29', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:12:27', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:13:03', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:15:53', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:16:27', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:18:52', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:19:50', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:22:23', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:32:23', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:34:24', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 16:59:33', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:08:21', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:09:46', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:10:02', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:10:07', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:10:09', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:18:01', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:18:03', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:19:28', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:19:31', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:19:33', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:19:35', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:20:04', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:20:23', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:20:29', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:20:31', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:23:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:33:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 17:35:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:00:39', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:18:10', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:18:26', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:18:28', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:29:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:35:35', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:36:30', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:37:05', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:37:52', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:39:09', 'dd-mm-yyyy hh24:mi:ss'), 3103);
commit;
prompt 3400 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:40:20', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:50:20', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:52:21', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:58:16', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:58:23', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 18:58:25', 'dd-mm-yyyy hh24:mi:ss'), 3103);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:02:53', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:05:43', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:11:09', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:12:28', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:14:01', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:14:44', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:15:37', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:16:12', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:16:53', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:17:41', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:18:13', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:19:46', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:20:29', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:23:05', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:23:47', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:24:41', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:25:22', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:26:07', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:27:22', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:28:18', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:29:24', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:30:16', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:31:41', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:33:33', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:34:54', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:35:28', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:36:43', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:39:02', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:42:32', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:45:38', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:47:44', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:49:36', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:51:26', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:53:47', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:56:48', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 19:57:34', 'dd-mm-yyyy hh24:mi:ss'), 3104);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:03:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:05:20', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:15:20', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:17:22', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:42:31', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:48:12', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:48:19', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:48:21', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:48:53', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:49:51', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:52:01', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:53:11', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:55:00', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:56:11', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:57:35', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 20:58:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:01:03', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:02:13', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:02:56', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:12:56', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:14:58', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 21:40:07', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:10:08', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:26:21', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:26:28', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:26:30', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:29:42', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:30:43', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:31:48', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:33:15', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:33:51', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:34:34', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:35:34', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:36:33', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:37:08', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:38:37', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:39:19', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:39:44', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:40:55', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:42:13', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:43:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:44:54', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:46:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:47:56', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:49:20', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:50:25', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:50:50', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:50:57', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:51:36', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:52:01', 'dd-mm-yyyy hh24:mi:ss'), 3105);
commit;
prompt 3500 records committed...
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:52:47', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:54:27', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:55:44', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:57:00', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:58:16', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 22:59:47', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:01:28', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:03:09', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:04:32', 'dd-mm-yyyy hh24:mi:ss'), 3105);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:06:13', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:08:52', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:10:30', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:11:25', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:12:56', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:13:31', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:14:14', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:14:42', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:17:28', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:18:35', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:18:59', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:19:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:19:42', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:19:51', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:20:47', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:21:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:22:09', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:22:31', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:24:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:26:40', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:27:08', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:27:41', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:28:53', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:29:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:29:43', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:30:21', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:30:54', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:31:18', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:31:55', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:32:31', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:32:56', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:33:56', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:34:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:35:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:36:30', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:37:43', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:38:44', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:39:42', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:40:47', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:41:56', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:43:24', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:44:38', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:45:47', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:46:48', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:48:00', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:49:02', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:49:32', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:50:23', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:51:25', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:52:29', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:54:29', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:55:39', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:56:53', 'dd-mm-yyyy hh24:mi:ss'), 3106);
insert into DADOS_RASTREADOR (ID_VEICULO, DATA, HORIMETRO)
values (50, to_date('13-09-2021 23:58:15', 'dd-mm-yyyy hh24:mi:ss'), 3106);
commit;
prompt 3563 records loaded
set feedback on
set define on
prompt Done.
